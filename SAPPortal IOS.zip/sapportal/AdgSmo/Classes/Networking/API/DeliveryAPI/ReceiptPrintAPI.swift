//
//  ReceiptPrintAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/22/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class ReceiptPrintAPI: APIOperation<ReceiptPrintResponse> {
    
    
    init(idOrder: String) {
        
        var params: Parameters = [:]
        params["so"] = idOrder
        params["from"] = "20200601"
        params["to"] = "20200630"
        
        super.init(request: APIRequest(name: "PDF JSON",
                                       path: "khgh",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
}


struct ReceiptPrintResponse: APIResponseProtocol {
    
    var rawData: String = ""
    
    init(json: JSON) {
        
        rawData = json["ZRAWDATA"].string ?? ""
    }
}
