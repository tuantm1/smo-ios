//
//  DeliveryAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/21/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class DeliveryAPI: APIOperation<DeliveryResponse> {
    
    init(maVT: String, ngayGiao: String, maChuyen: String, ttGH: String) {
        
        var params: Parameters = [:]
        
        params["I_MACVT"] = maVT
        params["I_NGAYGIAO"] = ngayGiao
        params["I_MACHUYEN"] = maChuyen
        params["I_TT_GH"] = ttGH
        
        super.init(request: APIRequest(name: "GET LIST DELIVERY JSON: ",
                                       path: "SD_TTCVT_1",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
    
    // --> Update state delivery
    init(ngayGiao: String,
         maChuyen: String,
         ttGH: String,
         feeType: String,
         feeTypeDesc: String,
         price: String,
         reason: String,
         lat: String,
         long: String,
         kmStart: String,
         kmEnd: String,
         items: [DeliveryItemModel]) {
        
        
        let itemRaw = items.map { DeliveryUpdateModel(spvc: $0.belnrPVC,
                                                      item: $0.buzei,
                                                      ttGH: "3",
                                                      chiphi: price,
                                                      lydo: reason,
                                                      feeType: feeType,
                                                      feeTypeDesc: feeTypeDesc,
                                                      lat: lat,
                                                      long: long,
                                                      kmStart: kmStart,
                                                      kmEnd: kmEnd).convertRawString() }
            .joined(separator: ",")
        
        
        let updateTBRaw: String = "[\(itemRaw)]"
        
        
        let resultRaw = "{\"I_NGAYGIAO\":\"\(ngayGiao)\", \"I_MACHUYEN\":\"\(maChuyen)\", \"I_TT_GH\":\"\(ttGH)\", \"TB_UPDATE\":\(updateTBRaw)}"
        
        print(resultRaw)
        super.init(request: APIRequest(name: "UPDATE LIST ITEM DELIVERY JSON: ",
                                       path: "SD_TTCVT_1",
                                       method: .post,
                                       expandedHeaders: APIConfiguration.httpHeaderRawText,
                                       parameters: .raw(resultRaw)))
    }
}


struct DeliveryResponse: APIResponseProtocol {
    
    var model: DeliveryModel?
    
    
    init(json: JSON) {
        print(json)
        model = DeliveryModel(json: json)
    }
    
}
