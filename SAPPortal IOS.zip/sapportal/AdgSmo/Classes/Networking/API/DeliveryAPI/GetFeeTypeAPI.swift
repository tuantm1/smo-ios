//
//  GetFeeTypeAPI.swift
//  AdgSmo
//
//  Created by Vũ The Anh on 1/20/21.
//  Copyright © 2021 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetFeeTypeAPI: APIOperation<GetFeeTypeResponse> {
    
    
    init() {
        super.init(request: APIRequest(name: "GET LIST FEE TYPE JSON: ",
                                       path: "GET_LOAIPHI",
                                       method: .post,
                                       parameters: .rawBody([:])))
    }
    
}


struct GetFeeTypeResponse: APIResponseProtocol {
    var feeTypes: [FeeType] = []
    
    init(json: JSON) {
        feeTypes = json["ET_DATA"].arrayValue.map { FeeType(json: $0) }
    }
}


struct FeeType {
    var description: String = ""
    var value: String = ""
    
    init() {}
    
    init(json: JSON) {
        description = json["DESCRIPTION"].string ?? ""
        value = json["VALUE"].string ?? ""
    }
}
