//
//  DeliveryGetImageAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 6/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class DeliveryGetImageAPI: APIOperation<DeliveryGetImageResponse> {
    
    
    init(saleOrder: String) {
        
        var params: Parameters = [:]
        params["so_number"] = saleOrder
        
        super.init(request: APIRequest(name: "GET IMAGE JSON",
                                       path: "get_image",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
}


struct DeliveryGetImageResponse: APIResponseProtocol {
    
    var model: DeliveryGetImageModel = DeliveryGetImageModel()
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        model = DeliveryGetImageModel(json: json["RESPONSE"])
    }
}

