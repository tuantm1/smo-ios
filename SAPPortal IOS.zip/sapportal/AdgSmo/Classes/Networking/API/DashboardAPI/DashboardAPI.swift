//
//  DashboardAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 6/14/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class DashboardAPI: APIOperation<DashboardResponse> {
    
    
    init(idUser: String) {
        
        var params: Parameters = [:]
        params["ID_USER"] = idUser
        
        super.init(request: APIRequest(name: "GET DASHBOARD JSON:",
                                       path: "GET_DASHBOARD",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
    
}


struct DashboardResponse: APIResponseProtocol {
    
    var listDashboard: [DashboardModel] = []
    
    init(json: JSON) {
        
        listDashboard = json["GT_DASHBOARD"].arrayValue.map { DashboardModel(json: $0) }
    }
    
}
