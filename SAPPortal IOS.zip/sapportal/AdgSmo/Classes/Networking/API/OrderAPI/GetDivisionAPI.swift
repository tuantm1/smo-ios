//
//  GetDivisionAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetDivisionAPI: APIOperation<GetDivisionResponse> {
    
    init() {
        
        super.init(request: APIRequest(name: "GET DIVISION JSON : ",
                                       path: "GET_DIVISION",
                                       method: .post,
                                       parameters: .rawBody([:])))
    }
    
}


struct GetDivisionResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var divisions: [DivisionModel] = []
    
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        divisions = json["GT_DIVISION"].arrayValue.map { DivisionModel(json: $0) }
        
    }
    
}

