//
//  GetRouteAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetRouteAPI: APIOperation<GetRouteResponse> {
    
    
    init() {
        super.init(request: APIRequest(name: "GET ROUTE JSON: ",
                                       path: "GET_ROUTE",
                                       method: .post,
                                       parameters: .rawBody([:])))
    }
}


struct GetRouteResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var routeModel: RouteModel = RouteModel()
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        routeModel = RouteModel(json: json)
    }
    
}
