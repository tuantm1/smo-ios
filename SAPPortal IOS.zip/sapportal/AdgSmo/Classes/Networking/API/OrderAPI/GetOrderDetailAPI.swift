//
//  GetOrderDetailAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/7/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetOrderDetailAPI: APIOperation<GetOrderDetailResponse> {
    
    
    init(userID: String) {
        
        var params: Parameters = [:]
        params["ID_ORDER"] = userID
        
        super.init(request: APIRequest(name: "GET ORDER DETAIL JSON: ",
                                       path: "GET_DETAIL_ORDER",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
}


struct GetOrderDetailResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var orderDetail: OrderDetailModel = OrderDetailModel()
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        orderDetail = OrderDetailModel(json: json["RESPONSE"])
    }
}
