//
//  GetOrderAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 4/21/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetOrderAPI: APIOperation<GetOrderResponse> {
    
    init(userID: String) {
        
        var params: Parameters = [:]
        params["ID_USER"] = userID
        
        super.init(request: APIRequest(name: "GET ORDER JSON: ",
                                       path: "get_order",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
}


struct GetOrderResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var order: [OrderModel] = []
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        order = json["RES"].arrayValue.map { OrderModel(json: $0) }
        
    }
}
