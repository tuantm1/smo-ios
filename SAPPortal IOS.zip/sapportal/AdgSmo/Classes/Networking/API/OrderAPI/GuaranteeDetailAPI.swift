//
//  GuaranteeDetailAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 6/21/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GuaranteeDetailAPI: APIOperation<GuaranteeDetailResponse> {
    
    init(creditID: String) {
        
        var params: Parameters = [:]
        params["ID_CREDIT"] = creditID
        
        super.init(request: APIRequest(name: "GET GUARANTEE DETAIL JSON:",
                                       path: "get_detail_bl",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
}


struct GuaranteeDetailResponse: APIResponseProtocol {
    
    var model: GuaranteeDetailModel = GuaranteeDetailModel()
    
    
    init(json: JSON) {
        model = GuaranteeDetailModel(json: json["GT_CREDIT"])
    }
    
}
