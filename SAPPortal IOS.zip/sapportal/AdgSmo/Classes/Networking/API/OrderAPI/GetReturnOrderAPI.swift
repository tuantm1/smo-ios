//
//  GetReturnOrderAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 4/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetReturnOrderAPI: APIOperation<GetReturnOrderResponse> {
    
    
    init(userID: String) {
        
        var params: Parameters = [:]
        params["id_user"] = userID
        
        super.init(request: APIRequest(name: "GET RETURN ORDER JSON: ",
                                       path: "get_order",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
}


struct GetReturnOrderResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var returnOrder: [ReturnOrderModel] = []
    
    
    init(json: JSON) {
           
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        let allOrder = json["RES"].arrayValue.map { ReturnOrderModel(json: $0) }
           
        returnOrder = allOrder.filter { !$0.items.filter { $0.zReturn == "1" }.isEmpty }.sorted(by: { (model1, model2) -> Bool in
               return model1.idOrder > model2.idOrder
           })
    
       }
    
}
