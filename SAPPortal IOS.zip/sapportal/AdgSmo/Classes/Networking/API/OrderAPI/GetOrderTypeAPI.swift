//
//  GetOrderTypeAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetOrderTypeAPI: APIOperation<GetOrderTypeResponse> {
    
    
    init() {
        super.init(request: APIRequest(name: "GET ORDER TYPE JSON: ",
                                       path: "GET_ORDER_TYPE",
                                       method: .post,
                                       parameters: .rawBody([:])))
    }
    
}

struct GetOrderTypeResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var orderTypeModel: [OrderTypeModel] = []
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        orderTypeModel = json["GT_ORDER_TYPE"].arrayValue.map { OrderTypeModel(json: $0) }
    }
}
