//
//  GetDCAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetDCAPI: APIOperation<GetDCResponse> {
    
    init() {
        
        super.init(request: APIRequest(name: "GET DC JSON: ",
                                       path: "GET_DC",
                                       method: .post,
                                       parameters: .rawBody([:])))
    }
    
    
    init(kunnr: String) {
        
        var params: Parameters = [:]
        params["KUNNR"] = kunnr
        
        super.init(request: APIRequest(name: "GET DC JSON: ",
                                       path: "GET_DC",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
}


struct GetDCResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var dcModel: [DCModel] = []
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        dcModel = json["GT_DC"].arrayValue.map { DCModel(json: $0) }
    }
}
