//
//  GetMarasAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetMarasAPI: APIOperation<GetMarasResponse> {
    
    init(userID: String, division: String, matnr: String, zType: String) {
        
        var params: Parameters = [:]
        params["ID_USER"] = userID
        params["division"] = division
        
        var listITMaras: [Parameters] = [[:]]
        
        var itMaras: Parameters = [:]
        itMaras["MATNR"] = matnr
        
        listITMaras.append(itMaras)
        
        params["IT_MARAS"] = listITMaras
        
        if zType != "" {
            params["ztype"] = zType
        }
        
        super.init(request: APIRequest(name: "GET MARAS JSON: ",
                                       path: "GET_MARA",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
    
    init(orderModel: OrderModel) {
        
        var params: Parameters = [:]

        var listITMaras: [Parameters] = [[:]]
        
        orderModel.items.forEach { (item) in
            
            let matnrKey: Parameters = ["MATNR": item.matnr]
            
            listITMaras.append(matnrKey)
            
        }
        
        params["IT_MARAS"] = listITMaras
        params["ID_USER"] = orderModel.idUser
        params["division"] = orderModel.division
        
        super.init(request: APIRequest(name: "GET MARAS JSON: ",
                                       path: "GET_MARA",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
    
    init(model: GetDetailTempModel) {
        
        var params: Parameters = [:]

        var listITMaras: [Parameters] = [[:]]
        
        model.items.forEach { (item) in
            
            let matnrKey: Parameters = ["MATNR": item.matnr]
            
            listITMaras.append(matnrKey)
            
        }
        
        params["IT_MARAS"] = listITMaras
        params["ID_USER"] = model.idUser
        params["division"] = model.division
        
        super.init(request: APIRequest(name: "GET MARAS JSON: ",
                                       path: "GET_MARA",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
    
    init(userID: String = AppDataShare.shared.userDetail.user.userID, zType: String) {
        
        var params: Parameters = [:]
        
        params["ID_USER"] = userID
        params["ztype"] = zType
        
        super.init(request: APIRequest(name: "GET MARAS JSON: ",
                                       path: "GET_MARA",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
}

struct GetMarasResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var marasModel: [MarasModel] = []
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        marasModel = json["MARAS"].arrayValue.map { MarasModel(json: $0) }
    }
    
}
