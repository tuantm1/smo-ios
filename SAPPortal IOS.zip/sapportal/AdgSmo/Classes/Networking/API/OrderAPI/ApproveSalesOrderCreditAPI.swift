//
//  ApproveSalesOrderCreditAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/31/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class ApproveSalesOrderCreditAPI: APIOperation<ApproveSalesOrderCreditResponse> {
    
    
    init(userID: String) {
        
        var params: Parameters = [:]
        params["id_user"] = userID
        
        super.init(request: APIRequest(name: "GET APPROVE CREDIT JSON: ",
                                       path: "APPROVE_CREDIT_LIST",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
}


struct ApproveSalesOrderCreditResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var gtCredit: [ApproveSalesOrderCreditModel] = []
    
    var res: [GuaranteeListOrderModel] = []
    
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        gtCredit = json["GT_CREDIT"].arrayValue.map {ApproveSalesOrderCreditModel(json: $0) }
    }
    
}
