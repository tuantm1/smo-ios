//
//  GetApproveOrder.swift
//  SapPortal
//
//  Created by LuongTiem on 4/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetApproveOrderAPI: APIOperation<GetApproveOrderResponse> {
    
    init(userID: String) {
        
        var params: Parameters = [:]
        params["id_user"] = userID
        
        super.init(request: APIRequest(name: "GET APPROVE ORDER JSON: ",
                                       path: "get_order",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
}


struct GetApproveOrderResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var approveOrder: [ApproveOrderModel] = []
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        let allOrder = json["RES"].arrayValue.map { ApproveOrderModel(json: $0) }
        
        /*  filter status pending value = "P" */
        approveOrder = allOrder.filter { $0.status == "P" }.sorted(by: { (model1, model2) -> Bool in
            return model1.idOrder > model2.idOrder
        })
 
    }
}
