//
//  GetApproveCredit.swift
//  SapPortal
//
//  Created by LuongTiem on 4/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GuaranteeListOrderAPI: APIOperation<GuaranteeListOrderResponse> {
    
    
    init(userID: String) {
        
        var params: Parameters = [:]
        params["id_user"] = userID
        
        super.init(request: APIRequest(name: "GET LIST CREDIT JSON: ",
                                       path: "credit",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
    
}


struct GuaranteeListOrderResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var guaranteeListOrder: [GuaranteeListOrderModel] = []
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        guaranteeListOrder = json["RES"].arrayValue.map { GuaranteeListOrderModel(json: $0) }
        
    }
    
}
