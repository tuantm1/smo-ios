//
//  UserGuaranteeDetailAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 6/20/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class UserGuaranteeDetailAPI: APIOperation<UserGuaranteeDetailResponse> {
    
    init(idUser: String, idOrder: String) {
        
        var params: Parameters = [:]
        params["ID_USER"] = idUser
        params["ID_ORDER"] = idOrder
        
        super.init(request: APIRequest(name: "GET USER GUARANTEE DETAIL JSON:",
                                       path: "GET_DETAIL_USER_BL",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
}


struct UserGuaranteeDetailResponse: APIResponseProtocol {
    
    
    var model: UserGuaranteeDetailModel = UserGuaranteeDetailModel()
    
    init(json: JSON) {
        
        model = UserGuaranteeDetailModel(json: json)
    }
}
