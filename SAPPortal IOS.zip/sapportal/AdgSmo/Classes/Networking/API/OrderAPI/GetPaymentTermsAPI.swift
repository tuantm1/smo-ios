//
//  GetPaymentTermsAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetPaymentTermsAPI: APIOperation<GetPaymentTermsResponse> {
    
    init() {
        super.init(request: APIRequest(name: "GET PAYMENT TERM JSON: ",
                                       path: "GET_PAYMENT_TERMS",
                                       method: .post,
                                       parameters: .rawBody([:])))
    }
}


struct GetPaymentTermsResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var paymentTermModel: [PaymentTermsModel] = []
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        paymentTermModel = json["GT_PAYMENT_TERM"].arrayValue.map { PaymentTermsModel(json: $0) }
    }
    
}
