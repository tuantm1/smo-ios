//
//  ApproveOrderAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/9/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

// MARK: Action approve order
class ApproveOrderActionAPI: APIOperation<ApproveOrderActionResponse> {
    
    
    init(userID: String, orderID: String, checkCredit: String? = nil) {
        
        var params: Parameters = [:]
        params["ID_USER"] = userID
        params["ID_ORDER"] = orderID
        params["CHECK_CREDIT"] = "X"
//        if let checkCreditParams = checkCredit {
//            params["CHECK_CREDIT"] = checkCreditParams
//        }
        
        super.init(request: APIRequest(name: "APPROVE ACTION JSON: ",
                                       path: "approve_order",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
}


struct ApproveOrderActionResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var response: [ApproveOrderActionModel] = []
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        response = json["ZRETURN"].arrayValue.map { ApproveOrderActionModel(json: $0) }
    }
}





// MARK: Action Reject Order
class RejectOrderActionAPI: APIOperation<RejectOrderActionResponse> {
    
    init(userID: String, orderID: String, reasonReject: String = "") {
        
        var params: Parameters = [:]
        params["ID_USER"] = userID
        params["ID_ORDER"] = orderID
        params["REJECT_REASON"] = reasonReject
//        params["is_mobile"] = true
        
        super.init(request: APIRequest(name: "REJECT ACTION",
                                       path: "REJECT_ORDER",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
    
}


struct RejectOrderActionResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse
    
    init(json: JSON) {
        returnResponse = ReturnResponse(json: json["RETURN"])
    }
    
}


// MARK: Action Reject Credit

class RejectCreditActionAPI: APIOperation<RejectCreditActionResponse> {
    
    init(creditID: String, orderID: String, userID: String, reasonReject: String = "") {
        
        var params: Parameters = [:]
        params["ID_CREDIT"] = creditID
        params["ID_ORDER"] = orderID
        params["ID_USER"] = userID
        params["REJECT_REASON"] = reasonReject
        
        super.init(request: APIRequest(name: "REJECT CREDIT ACTION",
                                       path: "reject_credit",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
    
}


struct RejectCreditActionResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse
    
    init(json: JSON) {
        returnResponse = ReturnResponse(json: json["RETURN"])
    }
    
}

