//
//  GetListAccountAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 4/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class GetListAccountAPI: APIOperation<GetListAccountResponse> {
    
    init(userID: String, pages: Int = 1) {
        
        var params: Parameters = [:]
        params["ID_USER"] = userID
        params["is_mobile"] = true
        params["pages"] = pages
        
        super.init(request: APIRequest(name: "GET LIST ACCOUNT JSON: ",
                                       path: "GET_USER",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
}

struct GetListAccountResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse
    
    var listAccount: [ListAccountModel] = []
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        listAccount = json["GT_USER"].arrayValue.map { ListAccountModel(json: $0) }
    }
}
