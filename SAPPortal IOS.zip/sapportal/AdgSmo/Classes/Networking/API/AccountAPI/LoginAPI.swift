//
//  Login.swift
//  SapPortal
//
//  Created by LuongTiem on 4/18/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class LoginAPI: APIOperation<LoginResponse> {
    
    init(model: LoginModel) {
        
        var parameters: Parameters = [:]
        parameters["username"] = model.username
        parameters["password"] = model.password
        parameters["IV_MOBILE"] = "I"
        
        super.init(request: APIRequest(name: "LOGIN USER",
                                       path: "login",
                                       method: .post,
                                       expandedHeaders: APIConfiguration.httpHeaderRawText,
                                       parameters: .rawBody(parameters)))
    }
}


struct LoginResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse
    
    var authenticMenu: AuthenticMenuModel
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        authenticMenu = AuthenticMenuModel(json: json["GS_AUTHEN"])
    }
}

