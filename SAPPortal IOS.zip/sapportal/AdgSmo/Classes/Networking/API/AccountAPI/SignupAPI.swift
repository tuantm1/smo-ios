//
//  SignupAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 7/7/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class SignupAPI: APIOperation<SignupResponse> {
    
    init(model: SignupModel) {
        
        var signupParam: Parameters = [:]
        signupParam["USERNAME"] = model.userName
        signupParam["PASSWORD"] = model.password
        signupParam["SHIPTOS"] = []
        signupParam["DESCRIPTION"] = model.descriptions
        
        
        var parameters: Parameters = [:]
        
        parameters["iv_mobile"] = "I"
        parameters["REQUEST"] = signupParam
        
        super.init(request: APIRequest(name: "CREATE USER JSON",
                                       path: "CREATE_USER",
                                       method: .post,
                                       expandedHeaders: APIConfiguration.httpHeaderRawText,
                                       parameters: .rawBody(parameters)))
    }
}


struct SignupResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse
    
    init(json: JSON) {
        returnResponse = ReturnResponse(json: json["RETURN"])
    }
}
