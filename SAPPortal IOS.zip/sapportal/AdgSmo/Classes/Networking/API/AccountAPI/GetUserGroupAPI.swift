//
//  GetUserGroupAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/5/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetUserGroupAPI: APIOperation<GetUserGroupResponse> {
    
    init() {
        var params: Parameters = [:]
        params["is_mobile"] = true
        
        super.init(request: APIRequest(name: "GET LIST USER GROUP JSON",
                                       path: "GET_USGR",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
}


struct GetUserGroupResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse
    
    var listUserGroup: [UserGroupModel] = []
    
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        listUserGroup = json["GT_USGR"].arrayValue.map { UserGroupModel(json: $0) }
        
    }
    
}
