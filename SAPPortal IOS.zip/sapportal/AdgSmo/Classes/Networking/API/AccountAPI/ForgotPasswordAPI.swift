//
//  ForgotPasswordAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class ForgotPasswordAPI: APIOperation<ForgotPasswordResponse> {
    
    init(model: ForgotPasswordModel) {
        
        super.init(request: APIRequest(name: "FORGOTPASSWORD JSON: ",
                                       path: "CHANGEPASSWORD",
                                       method: .post,
                                       expandedHeaders: APIConfiguration.httpHeaderRawText,
                                       parameters: .raw(model.rawText())))
    }
    
    
}


struct ForgotPasswordResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse
    
    init(json: JSON) {
        returnResponse = ReturnResponse(json: json["RETURN"])
    }
    
}
