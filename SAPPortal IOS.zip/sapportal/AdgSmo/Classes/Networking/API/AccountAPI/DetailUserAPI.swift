//
//  DetailUserModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/4/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class DetailUserAPI: APIOperation<DetailUserResponse> {
    
    
    init(userID: String) {
        
        var params: Parameters = [:]
        params["ID_USER"] = userID
        params["is_mobile"] = true
        
        super.init(request: APIRequest(name: "DETAIL USER JSON",
                                       path: "DETAIL_USER",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
}

struct DetailUserResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse
    
    var user: UserModel = UserModel()
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        user = UserModel(json: json["USER"])
    }
}
