//
//  APIGetUserDetail.swift
//  SapPortal
//
//  Created by LuongTiem on 4/22/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetUserDetailAPI: APIOperation<GetUserDetailResponse> {
    
    
    init(userID: String) {
        
        var params: Parameters = [:]
        params["ID_USER"] = userID
        
        super.init(request: APIRequest(name: "GET USER DETAIL",
                                       path: "GET_DETAIL_USER", method: .post,
                                       parameters: .rawBody(params)))
    }
    
}


struct GetUserDetailResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var user: UserDetailModel = UserDetailModel()
    
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        user = UserDetailModel(json: json)
        
    }
    
}
