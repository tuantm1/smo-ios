//
//  CreateCreditAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 8/12/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import Foundation
import SwiftyJSON
import Alamofire


class CreateCreditAPI: APIOperation<CreateCreditResponse> {
    
    init(model: TotalApproveSaleCreditDetailModel) {
        
        var params: Parameters = [:]
        params["zstatus"] = 1
        
        
        var theCreditParam: Parameters = [:]
        
        var parentParams: [Parameters] = []
        
        model.guardian.parents.forEach { (model) in
            parentParams.append(model.convertRawString())
        }
        
        theCreditParam["PARENTS"] = parentParams
        theCreditParam["id_request"] = model.guardian.user.userID
        theCreditParam["name_requester"] = model.guardian.user.description
        theCreditParam["hmcl"] = model.guardian.hmcl
        theCreditParam["zdate"] = Date().convertString(formatter: "dd/MM/yyyy")
        theCreditParam["id_order"] = model.orderDetailModel.idOrder
        theCreditParam["id_parent"] = model.guardian.parents[model.indexGuaranteeSelected].userID
        theCreditParam["stbl"] = model.orderDetailModel.stbl
        theCreditParam["zprice"] = model.orderDetailModel.price
        theCreditParam["grade"] = model.guardian.grade
        theCreditParam["id_approve"] = model.guardian.parents[model.indexGuaranteeSelected].userID
         
        params["theCredit"] = theCreditParam
    
        
        super.init(request: APIRequest(name: "CREATE CREDIT JSON:",
                                       path: "CREATE_CREDIT",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
    
}


struct CreateCreditResponse: APIResponseProtocol {
    
    
    init(json: JSON) {
        
    
    }
    
}
