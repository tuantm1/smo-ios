//
//  GetMappingBoToiAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 8/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class GetMappingBoToiAPI: APIOperation<GetMappingBoToiResponse> {
    
    init(idItem: String) {
        
        var params: Parameters = [:]
        params["ID_ITEM_MASTER"] = idItem
        
        super.init(request: APIRequest(name: "GET MAPPING BO TOI JSON:",
                                       path: "GET_MAPPING_BOTOI",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
    
}


struct GetMappingBoToiResponse: APIResponseProtocol {
    
    var model: [GetMappingBoToiModel] = []
    
    init(json: JSON) {
        
        model = json["GT_BOTOI"].arrayValue.map { GetMappingBoToiModel(json: $0) }
    }
    
}


