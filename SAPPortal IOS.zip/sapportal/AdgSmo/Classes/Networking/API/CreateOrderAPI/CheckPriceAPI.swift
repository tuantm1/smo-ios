//
//  CheckPriceAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 8/8/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class CheckPriceAPI: APIOperation<CheckPriceResponse> {
    
    init(model: GetDetailTempModel) {
        
        var params: Parameters = [:]
        params["ID_USER"] = model.idUser
        
        
        var request: Parameters = [:]
        request["DC"] = model.dc
        request["DIVISION"] = model.division
        request["DIVISION_NAME"] = model.divisionName
        request["ID_ITEM"] = model.idItem
        request["ID_TEMPLATE"] = model.idTemplate
        request["ID_TEMP_CLONE"] = model.idTempClone
        request["NAME"] = model.name
        request["NAME_SHIPTO"] = model.nameShipTo
        request["NOTE"] = model.note
        request["ORDER_TYPE"] = model.orderType
        request["ZTERM"] = model.zTerm
        request["Z_RETURN"] = model.zReturn
        request["ID_USER"] = model.idUser
        
        
        var itemsParams: [Parameters] = []

        model.items.forEach { (model) in
            itemsParams.append(model.convertRawString())
        }
        
        request["ITEMS"] = itemsParams
        
        
        params["request"] = request
        super.init(request: APIRequest(name: "CHECK PRICE JSON:",
                                       path: "check_price",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
    
}


struct CheckPriceResponse: APIResponseProtocol {
    
    var model: CheckPriceModel = CheckPriceModel()
    
    init(json: JSON) {
        
        model = CheckPriceModel(json: json)
    }
    
}
