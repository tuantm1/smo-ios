//
//  CheckPriceAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 8/8/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class MappingMaraAPI: APIOperation<MappingMaraResponse> {
    
    init(model: GetDetailTempModel) {
        
        var params: Parameters = [:]
        
        if !model.items.isEmpty {
            
            params["MATNR"] = model.items[0].matnr
            
            var itemsParams: [Parameters] = []
            
            model.items[0].characteristics.forEach { (model) in
                itemsParams.append(model.convertRawString())
            }
            
            params["GT_CHARACTER"] = itemsParams
        }
        
        
        super.init(request: APIRequest(name: "MAPPING MARA JSON:",
                                       path: "mapping_mara",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
    
}


struct MappingMaraResponse: APIResponseProtocol {
    
    var model: MappingMaraModel = MappingMaraModel()
    
    init(json: JSON) {
        
        model = MappingMaraModel(json: json)
    }
    
}
