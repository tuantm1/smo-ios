//
//  GetMappingThanhRayAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 8/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class GetMappingThanhRayAPI: APIOperation<GetMappingThanhRayResponse> {
    
    init() {
        
        super.init(request: APIRequest(name: "GET MAPPING BO TOI JSON:",
                                       path: "GET_MAPPING_THANHRAY",
                                       method: .post,
                                       parameters: .rawBody([:])))
        
    }
    
}


struct GetMappingThanhRayResponse: APIResponseProtocol {
    
    var model: [GetMappingThanhRayModel] = []
    
    init(json: JSON) {
        
        model = json["GT_THANHRAY"].arrayValue.map { GetMappingThanhRayModel(json: $0) }
    }
    
}
