//
//  CreateOrderAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 8/9/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//


import Foundation
import SwiftyJSON
import Alamofire


class CreateOrderAPI: APIOperation<CreateOrderResponse> {
    
    init(tempModel: GetDetailTempModel, checkPriceModel: CheckPriceModel, customer: CustomerDetailModel, mapping: MappingCreateOrder) {
        
        var params: Parameters = [:]
        params["CHECK_ROUTE"] = ""
        
        
        var request: Parameters = [:]
        request["DC"] = tempModel.dc
        request["DIVISION"] = tempModel.division
        request["DIVISION_NAME"] = tempModel.divisionName
        request["ID_ITEM"] = tempModel.idItem
        request["ID_TEMPLATE"] = tempModel.idTemplate
        request["ID_TEMP_CLONE"] = tempModel.idTempClone
        request["NAME"] = tempModel.name
        request["NAME_SHIPTO"] = customer.kunnr + " - " + customer.customerName + " - " + customer.city
        request["NOTE"] = tempModel.note
        request["ORDER_TYPE"] = tempModel.orderType
        request["ZTERM"] = tempModel.zTerm
        request["Z_RETURN"] = tempModel.zReturn
        request["ID_USER"] = tempModel.idUser
        
        
        request["STATUS"] = "P"
        request["TODAY"] = Date().convertString(formatter: "dd/MM/yyyy")
        request["TG_DH"] = mapping.time
        
        let price = (checkPriceModel.tgtdh - checkPriceModel.ck) + checkPriceModel.tax
        
        request["Z_DATE"] = mapping.chonNgayGiaoHang
        request["ZPRICE"] = price
        request["TOTAL_PRICE"] = checkPriceModel.tgtdh
        request["CK"] = checkPriceModel.ck
        request["TAX"] = checkPriceModel.tax
        request["TOTAL_INQUIRY"] = checkPriceModel.totalInquiry
        request["address"] = mapping.addresses
        request["vsart"] = mapping.vsart
        request["route"] = mapping.route
        request["ztc"] = mapping.chonLoaiTieuChuan
        request["NOTE"] = mapping.note
        
        request["TEN_NNH"] = mapping.name
        request["PHONE_NUMBER"] = mapping.phone
        request["Ten_KHC"] = mapping.nameEndUser
        request["SDT_KHC"] = mapping.phoneEndUser
        request["DC_KHC"] = mapping.addressEndUser
        if (!mapping.zType.isEmpty) {
            request["ZPK"] = "X"
        }
        
        var itemsParams: [Parameters] = []

        tempModel.items.forEach { (model) in
            itemsParams.append(model.convertRawString())
        }
        
        request["ITEMS"] = itemsParams
        params["request"] = request
        
        
        super.init(request: APIRequest(name: "CREATE ORDER JSON:",
                                       path: "CREATE_ORDER",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
    
}


struct CreateOrderResponse: APIResponseProtocol {
    
    var model: CreateOrderConfirmModel = CreateOrderConfirmModel()
    
    init(json: JSON) {
        
        model = CreateOrderConfirmModel(json: json)
    }
    
}

