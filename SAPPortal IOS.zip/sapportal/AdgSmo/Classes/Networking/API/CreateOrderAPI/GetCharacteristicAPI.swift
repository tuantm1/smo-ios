//
//  GetCharacteristicAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 8/1/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class GetCharacteristicAPI: APIOperation<GetCharacteristicResponse> {
    
    init(matnr: String) {
        var params: Parameters = [:]
        params["OBJEK"] = matnr
        
        super.init(request: APIRequest(name: "GET CHARACTERISTIC JSON:",
                                       path: "GET_CHARACTERISTIC",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
    
}


struct GetCharacteristicResponse: APIResponseProtocol {
    
    var model: [GetCharacteristicModel] = []
    
    init(json: JSON) {
        
        model = json["DATA"].arrayValue.map { GetCharacteristicModel(json: $0) }
    }
    
}


// MARK: GET CHARACTIST DEFAULT
class GetCharacteristicDefaultAPI: APIOperation<GetCharacteristicDefaultResponse> {
    
    init(matnr: String) {
        var params: Parameters = [:]
        params["MATNR"] = matnr
        
        super.init(request: APIRequest(name: "GET CHARACTERISTIC JSON:",
                                       path: "GET_CHARACTERISTIC_DEFAULT",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
}


struct GetCharacteristicDefaultResponse: APIResponseProtocol {
    
    var gtCharacter: [GTCharacter] = []
    
    var matnrRefer: String = ""
    
    init(json: JSON) {
        
        self.matnrRefer = json["MATNR_REFER"].string ?? ""
        
        self.gtCharacter = json["GT_CHARACTER"].arrayValue.map { GTCharacter(json: $0) }
    }
}
