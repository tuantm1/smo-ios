//
//  GetDetailTempAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 8/1/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class GetDetailTempAPI: APIOperation<GetDetailTempResponse> {
    
    init(idTemp: String) {
        
        var params: Parameters = [:]
        params["ID_TEMP"] = idTemp
        
        super.init(request: APIRequest(name: "GET DETAIL TEMP JSON:",
                                       path: "GET_DETAIL_TEMP",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
    
}


struct GetDetailTempResponse: APIResponseProtocol {
    
    var model: GetDetailTempModel = GetDetailTempModel()
    
    init(json: JSON) {
        
        model = GetDetailTempModel(json: json["RESPONSE"])
    }
    
}
