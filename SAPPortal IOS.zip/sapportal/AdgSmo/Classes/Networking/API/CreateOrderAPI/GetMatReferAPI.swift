//
//  GetMatReferAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 8/8/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class GetMatReferAPI: APIOperation<GetMatReferResponse> {
    
    init(matnr: String) {
        
        var params: Parameters = [:]
        params["MATNR"] = matnr
        
        super.init(request: APIRequest(name: "GET MAT REFER JSON:",
                                       path: "GET_MAT_REFER",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
    
}


struct GetMatReferResponse: APIResponseProtocol {
    
    var model: [GetMatReferModel] = []
    
    init(json: JSON) {
        
        model = json["GT_DATA"].arrayValue.map { GetMatReferModel(json: $0) }
    }
    
}

