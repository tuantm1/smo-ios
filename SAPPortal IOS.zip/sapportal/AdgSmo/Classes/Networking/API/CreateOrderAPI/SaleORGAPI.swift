//
//  SaleORGAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 7/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class SaleORGAPI: APIOperation<SaleORGResponse> {
    
    init(kunnr: String) {
        
        var params: Parameters = [:]
        params["KUNNR"] = kunnr
        
        super.init(request: APIRequest(name: "GET SALE ORG JSON:",
                                       path: "GET_SALE_ORG",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
    
}


struct SaleORGResponse: APIResponseProtocol {
    
    var listSaleORG: [SaleORGModel] = []
    
    init(json: JSON) {
        
        listSaleORG = json["GT_SALEORG"].arrayValue.map { SaleORGModel(json: $0) }
    }
    
}
