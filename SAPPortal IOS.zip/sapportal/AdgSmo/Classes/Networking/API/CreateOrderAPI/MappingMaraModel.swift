//
//  MappingMaraModel.swift
//  SapPortal
//
//  Created by LuongTiem on 8/8/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

struct MappingMaraModel {
    
    var gtCharacter: [GTCharacter] = []
    
    var matnrRefer: String = ""
    
    var eFlag: String = ""
    
    var eMessage: String = ""
    
    
    init() {
        
    }
    
    
    init(json: JSON) {
        
        self.matnrRefer = json["MATNR_REFER"].string ?? ""
        
        self.gtCharacter = json["GT_CHARACTER"].arrayValue.map { GTCharacter(json: $0) }
        
        self.eFlag = json["E_FLAG"].string ?? ""
        
        self.eMessage = json["E_MESSAGE"].string ?? ""
    }
}


struct GTCharacter {
    
    var matnr: String = ""
    
    var atnam: String = ""
    
    var smbez: String = ""
    
    var zDefault: String = ""
    
    var zgroup: String = ""
    
    var zValue: String = ""
    
    var zSort: String = ""
    
    init(json: JSON) {
        
        matnr = json["MATNR"].string ?? ""
        atnam = json["ATNAM"].string ?? ""
        smbez = json["SMBEZ"].string ?? ""
        zDefault = json["ZDEFAULT"].string ?? ""
        zgroup = json["ZGROUP"].string ?? ""
        zValue = json["ZVALUE"].string ?? ""
        zSort = json["ZSORT"].string ?? ""
    }
}
