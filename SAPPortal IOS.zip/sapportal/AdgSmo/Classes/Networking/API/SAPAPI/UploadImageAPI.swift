//
//  UploadImageAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 5/9/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class UploadImageAPI: APIOperation<UploadImageResponse> {
    
    init(orderID: String, image: UIImage) {
        
        let rawText = "{\"id_order\":\"\(orderID)\",\"xstring\":\"\(image.resizeImage1024x1024())\"}"
        
        super.init(request: APIRequest(name: "UP LOAD IMAGE",
                                       path: "upload",
                                       method: .post,
                                       expandedHeaders: APIConfiguration.httpHeaderRawText,
                                       parameters: .raw(rawText)))
    }
    
}

struct UploadImageResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    
    init(json: JSON) {
        returnResponse = ReturnResponse(json: json["RETURN"])
    }
}
