//
//  GetItemsSapAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 4/24/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class GetItemsSapAPI: APIOperation<GetItemsSapResponse> {
    
    
    init(userID: String) {
        
        var params: Parameters = [:]
        params["ID_USER"] = userID
        
        super.init(request: APIRequest(name: "GET LIST ITEM SAP",
                                       path: "GET_MARA", method: .post,
                                       parameters: .rawBody(params)))
    }
    
}


struct GetItemsSapResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var maras: [ItemSapModel] = []
    
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        maras = json["MARAS"].arrayValue.map { ItemSapModel(json: $0) }
    }
}
