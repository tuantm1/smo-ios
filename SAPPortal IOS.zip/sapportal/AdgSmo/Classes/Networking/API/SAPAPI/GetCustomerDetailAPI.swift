//
//  GetCustomerDetailAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 6/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class GetCustomerDetailAPI: APIOperation<GetCustomerDetailResponse> {
    
    init(kunnr: String) {
        
        var params: Parameters = [:]
        params["KUNNR"] = kunnr
        
        super.init(request: APIRequest(name: "GET DETAIL CUSTOMER",
                                       path: "GET_DETAIL_CUSTOMER",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
}


struct GetCustomerDetailResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var customerDetailModel: CustomerDetailModel = CustomerDetailModel()
    
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        customerDetailModel = CustomerDetailModel(json: json["CUSTOMER"])
        
    }
    
}
