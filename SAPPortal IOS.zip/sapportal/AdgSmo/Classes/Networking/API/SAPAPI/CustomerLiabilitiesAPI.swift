//
//  CustomerLiabilitiesAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 6/2/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class CustomerLiabilitiesAPI: APIOperation<CustomerLiabilitiesResponse> {
    
    
    init(userID: String) {
        
        var params: Parameters = [:]
        params["id_user"] = userID
        
        super.init(request: APIRequest(name: "GET LIST Customer Liabilities",
                                       path: "GET_CUSTOMER",
                                       method: .post,
                                       parameters: .rawBody(params)))
    }
    
}

struct CustomerLiabilitiesResponse: APIResponseProtocol {
    
    var returnResponse: ReturnResponse = ReturnResponse()
    
    var customers: [CustomerLiabilitiesModel] = []
    
    init(json: JSON) {
        
        returnResponse = ReturnResponse(json: json["RETURN"])
        
        customers = json["CUSTOMERS"].arrayValue.map { CustomerLiabilitiesModel(json: $0) }
        
    }
}
