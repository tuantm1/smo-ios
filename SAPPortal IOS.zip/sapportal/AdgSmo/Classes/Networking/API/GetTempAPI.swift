//
//  GetTempAPI.swift
//  SapPortal
//
//  Created by LuongTiem on 7/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire


class GetTempAPI: APIOperation<GetTempResponse> {
    
    init(idUser: String) {
        
        var params: Parameters = [:]
        params["id_user"] = idUser
        
        super.init(request: APIRequest(name: "GET TEMP JSON:",
                                       path: "GET_TEMP",
                                       method: .post,
                                       parameters: .rawBody(params)))
        
    }
    
}


struct GetTempResponse: APIResponseProtocol {
    
    var listTemplate: [GetTempModel] = []
    
    init(json: JSON) {
        
        listTemplate = json["RES"].arrayValue.map { GetTempModel(json: $0) }
    }
    
}
