
import Foundation
import SwiftyJSON
import Alamofire

class APIConfiguration {
    
    
    static var baseURL: String {
        let result = SwitchDomainConfig.domainName.trimmingCharacters(in: .whitespacesAndNewlines) + "/" + SwitchDomainConfig.severName.trimmingCharacters(in: .whitespacesAndNewlines)
        return result
    }
    
    
    static var deliveryBaseURL: String {
        let result = SwitchDomainConfig.domainName.trimmingCharacters(in: .whitespacesAndNewlines) + "/" + SwitchDomainConfig.severName.trimmingCharacters(in: .whitespacesAndNewlines)
        return result
    }
    

    
    static var httpHeaders: HTTPHeaders {
        
        return ["Content-Type": "application/json; charset=UTF-8",
                "Connection": "Keep-Alive",
                "Accept": "application/json; charset=UTF-8"]
    }
    
    
    static var timeout: TimeInterval = 30
    
    
    static var encoding: ParameterEncoding = URLEncoding.default
    
    
    /*  Verify Return Response */
    enum ConfirmRequestResponse: String {
        
        case success = "S"
        
        case error = "E"
        
    }
    
    
    static func verifyResponse(model: ReturnResponse) -> Bool {
        
        return model.type == ConfirmRequestResponse.success.rawValue 
    }
    
    
    static func reloadAllCacheCookie() {
        
        let cookieStorage = HTTPCookieStorage.shared
        
        if let cookie = cookieStorage.cookies {
            cookie.forEach { cookieStorage.deleteCookie($0) }
        }
        
        URLCache.shared.removeAllCachedResponses()
    }
}


extension APIConfiguration {
    
    
    static var httpHeaderRawText: HTTPHeaders {
        
        return ["Content-Type": "application/json; charset=utf-8",
                "Accept": "application/json; charset=utf-8"]
    }
    
    
    static var headerDelivery: HTTPHeaders {
        
        return ["Cookie": "ap-usercontext=sap-client=300"]
    }
}
