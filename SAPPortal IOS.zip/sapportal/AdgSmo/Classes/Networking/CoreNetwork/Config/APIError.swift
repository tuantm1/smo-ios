
import Foundation

enum APIError: Error {
    
    case api(statusCode: Int?, apiCode: Int?, message: String?)
    case request(statusCode: Int?, error: Error?)
    case unknown
    
    
    var apiCode: Int? {
        switch self {
        case .api(_, let apiCode, _):
            return apiCode
        default:
            return nil
        }
    }
    
    
    var statusCode: Int? {
        switch self {
        case .api(let statusCode, _, _):
            return statusCode
        case .request(let statusCode, _):
            return statusCode
        case .unknown:
            return nil
        }
    }
    
    
    var message: String? {
        switch self {
        case .api(_, _, let message):
            return message
        case .request(_, let error):
            guard let error = error else {
                return "Lỗi không xác định"
            }
            if error.isInternetOffline || error.isNetworkConnectionLost || error.isHostConnectFailed {
                return "Không có kết nối Internet"
            } else if error.isTimeout {
                return "Quá thời gian kết nối tới máy chủ"
            } else if error.isBadServerResponse {
                return "Không có dữ liệu từ máy chủ"
            } else {
                return "Không thể kết nối đến máy chủ"
            }
        case .unknown:
            return nil
        }
    }
}
