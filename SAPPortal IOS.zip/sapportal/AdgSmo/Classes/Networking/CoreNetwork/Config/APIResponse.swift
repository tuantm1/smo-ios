
import Foundation
import SwiftyJSON
import Alamofire


// Model repsonse protocol based on JSON data (View Controller's layers are able to view this protocol as response data)
public protocol APIResponseProtocol {
    
    // Set json as input variable
    init(json: JSON)
    
}


enum APIResponse {
    
    case success(JSON)
    case error(APIError)
    
    init(_ response: AFDataResponse<Any>, fromRequest request: APIRequest) {
        
        // Get status code
        let statusCode = response.response?.statusCode
        
        // check if request error exists
        if let error = response.error {
            self = .error(APIError.request(statusCode: statusCode, error: error))
            return
        }
        
        // check authorization
        if let authorization = response.response?.allHeaderFields["Authorization"] as? String {
            /// -- store access token user
        }
        
        // check response data
        guard let jsonData = response.value else {
            self = .error(APIError.request(statusCode: statusCode, error: response.error))
            return
        }
        
        // parser json data
        let json: JSON = JSON(jsonData)
        
        // -- parser json check response fail params, syntax ...
//        if let errorJson = request.environment.parserJsonError(json, statusCode: statusCode) {
//            self = .error(errorJson)
//            return
//        }
        
        self = APIResponse.success(json)
    }
}
