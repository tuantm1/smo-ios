
import Foundation
import Alamofire
import SwiftyJSON


public enum APIParameterType {
    
    case body(_ parameters: Parameters)
    case raw(_ text: String)
    case multipart(data: [Data?], parameters: Parameters, name: String, filename: String, mimeType: String)
    case upload( parameters: [[String:Any]])
    
    case rawBody(_ parameters: Parameters)
}

public struct APIRequest {
    
    var environment: APIEnvironment
    
    var name: String
    
    var path: String
    
    var method: HTTPMethod
    
    var expandedHeaders: HTTPHeaders
    
    var parameters: APIParameterType
    
    
    var url: String {
        return environment.baseURL + (path.isEmpty ? "" : "/") + path
    }
    
    var httpFullHeaders: HTTPHeaders {
        var fullHeader: HTTPHeaders = [:]
        environment.headers.forEach {
            fullHeader[$0.name] = $0.value
        }
        
        expandedHeaders.forEach {
            fullHeader[$0.name] = $0.value
        }
        
        return fullHeader
    }
    
    
    init(name: String,
         path: String,
         method: HTTPMethod,
         expandedHeaders: HTTPHeaders = [:],
         parameters: APIParameterType,
         environment: APIEnvironment = APIEnvironment.default) {
        
        self.name = name
        self.path = path
        self.method = method
        self.expandedHeaders = expandedHeaders
        self.parameters = parameters
        self.environment = environment
    }
}


extension APIRequest {
    
    func logAPI() {
        print("\n[Request API] ▶︎ [\(name)]")
        print("▶︎ Full url: \(url)")
        print("▶︎ Method: \(method.rawValue)")
        print("▶︎ HTTP Headers:\n\(JSON(httpFullHeaders))")
        
        switch parameters {
        case .body(let params):
            print("▶︎ Parameters:\n\(JSON(params))")
        case .raw(let raw):
            print("▶︎ Raw text:\n\(raw)")
        case .multipart(let datas, let params, let name, let filename,let mimeType):
            print("▶︎ Data length: \(datas.count)\n")
        case .upload:
            break
        case .rawBody(let params):
            print("▶︎ Parameters:\n\(JSON(params))")
        }
    }
    
}
