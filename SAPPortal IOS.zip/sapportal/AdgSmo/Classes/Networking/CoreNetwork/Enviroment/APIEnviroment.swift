
import UIKit
import Alamofire
import SwiftyJSON


// MARK: -- Protocol
protocol APIEnvironmentProtocol {
    
    var baseURL: String { get }
    var headers: HTTPHeaders { get }
    var encoding: ParameterEncoding { get }
    var timeout: TimeInterval { get }
    
    
    // -- handler failed params, syntax, ... when post sever
    func parserJsonError(_ json: JSON, statusCode: Int?) -> APIError?
}




// MARK: Define Environment
extension APIEnvironment {
    
    class var main: APIEnvironment {
        return APIEnvironment(baseURL: APIConfiguration.baseURL,
                              headers: APIConfiguration.httpHeaders,
                              encoding: APIConfiguration.encoding,
                              timeout: APIConfiguration.timeout)
    }
    
    
    
    class var delivery: APIEnvironment {
        return APIEnvironment(baseURL: APIConfiguration.deliveryBaseURL,
                              headers: APIConfiguration.httpHeaders,
                              encoding: APIConfiguration.encoding,
                              timeout: APIConfiguration.timeout)
    }
    
    
    
}




// MARK: -- Environment
public class APIEnvironment: APIEnvironmentProtocol {
    
    // Base URL of the environment (default is base url of current scheme)
    public var baseURL: String
    
    // HTTP headers of the environment (default is headers of current scheme)
    public var headers: HTTPHeaders
    
    // URL encoding of the environment (default is Encoding Default type)
    public var encoding: ParameterEncoding
    
    // Request timeout for request
    public var timeout: TimeInterval
    
    
    init(baseURL: String, headers: HTTPHeaders, encoding: ParameterEncoding, timeout: TimeInterval) {
        self.baseURL = baseURL
        self.headers = headers
        self.encoding = encoding
        self.timeout = timeout
    }
}

extension APIEnvironment {
    
    // -- parser input json to define error params, syntax ....
    func parserJsonError(_ json: JSON, statusCode: Int?) -> APIError? {
        
        let model = ReturnResponse(json: json["RETURN"])
        
        if model.hasResponse, model.type == APIConfiguration.ConfirmRequestResponse.success.rawValue {
            
            return nil
            
        } else {
            
            let errorMessage: String = "Lỗi sever"
            
            return APIError.api(statusCode: nil, apiCode: nil, message: errorMessage)
        }
    }
}

extension APIEnvironment {
    
    @discardableResult
    func set(baseURL: String) -> APIEnvironment {
        self.baseURL = baseURL
        return self
    }

    @discardableResult
    func set(headers: HTTPHeaders) -> APIEnvironment {
        self.headers = headers
        return self
    }

    @discardableResult
    func set(encoding: ParameterEncoding) -> APIEnvironment {
        self.encoding = encoding
        return self
    }

    @discardableResult
    func set(timeout: TimeInterval) -> APIEnvironment {
        self.timeout = timeout
        return self
    }
}


extension APIEnvironment {
    
    class var `default`: APIEnvironment {
        
        return APIEnvironment(baseURL: APIConfiguration.baseURL,
                             headers: APIConfiguration.httpHeaders,
                             encoding: APIConfiguration.encoding,
                             timeout: APIConfiguration.timeout)
    }
}
