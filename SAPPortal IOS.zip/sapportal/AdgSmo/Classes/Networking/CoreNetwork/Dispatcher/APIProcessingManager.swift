
import Foundation
import Alamofire

class APIProcessingManager {
    
    static let instance = APIProcessingManager()
    
    private var processingDispatcherList: [APIDispatcher] = []
    
    init() { }
    
    
}


// MARK: - Builder
extension APIProcessingManager {
    
    func add(_ dispatcher: APIDispatcher) {
        
        processingDispatcherList.append(dispatcher)
        
        print("▶︎ [API Processing Manager] Added new request !")
    }
    
    
    func cancel(_ dispatcher: APIDispatcher) {
        
        dispatcher.cancel()
        
        print("▶︎ [API Processing Manager] Cancelled request for screen: [\(dispatcher.target?.name ?? "none 🥶") !")
    }
    
    
    // -- cancel all dispatch
    func cancelAllDispatchers() {
        
        processingDispatcherList.forEach {
            $0.cancel()
        }
        
        processingDispatcherList.removeAll()
    }
    
    
    // -- cancel all request when view controller killed
    func cancelAllDispatchersFor(viewcontroller: UIViewController) {
        
        let filterDispatcherList = processingDispatcherList.filter { $0.target == viewcontroller}
        
        for dispatcher in filterDispatcherList {
            dispatcher.cancel()
        }
    }
    
    
    // -- remove dispatch from list
    func removeDispatcherFromList(dispatcher: APIDispatcher) {
        
        if let index = processingDispatcherList.firstIndex(where: { $0 === dispatcher }) {
            processingDispatcherList.remove(at: index)
        }
    }
}


// MARK: Extension support
extension UIViewController {
    
    var name: String {
        return NSStringFromClass(type(of: self)).components(separatedBy: ".").last!
    }
    
    
    func cancelAllAPIRequests() {
        
        APIProcessingManager.instance.cancelAllDispatchersFor(viewcontroller: self)
    }
}
