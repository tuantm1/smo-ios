
import Foundation
import Alamofire
import SwiftyJSON

protocol APIDispatcherProtocol {
    
    // execute request api
    func execute(request: APIRequest, completed: @escaping ((_ json: APIResponse) -> Void))
    
    // add data raw don't use alamofire
    func prepareRawFor(request: APIRequest, rawText: String) -> URLRequest?
    
    // custom header with mutipart
    func prepareHeadersForMultipartOrBinary(request: APIRequest) -> HTTPHeaders
    
    // cancel request
    func cancel()
    
}


class APIDispatcher {
    
    weak var target: UIViewController?
    
    private var request: APIRequest?
    
    private var completionHandler: ((_ response: APIResponse) -> Void)?
    
    private var dataRequest: DataRequest?
    
    private var uploadRequest: UploadRequest?
    
    
    init() {
        APIProcessingManager.instance.add(self)
    }
    
}


extension APIDispatcher: APIDispatcherProtocol {
    
    func execute(request: APIRequest, completed: @escaping ((APIResponse) -> Void)) {
        
        self.request = request
        
        self.completionHandler = completed
        
        // -- check case of request's parameters
        switch request.parameters {
            
        case .body:
            
            let urlRequest = ConvertibleRequest(request)
            
            self.dataRequest = AF.request(urlRequest).responseJSON(completionHandler: { [weak self] data in
                
                guard let `self` = self else { return }
                
                completed(APIResponse(data, fromRequest: request))
                
                APIProcessingManager.instance.removeDispatcherFromList(dispatcher: self)
                
                print("▶︎ [API Processing Manager] Removed body request from list for screen: \(self.target?.name ?? "none 🥶") !")
                
            })
        case .raw(let text):
            
            guard let rawRequest = prepareRawFor(request: request, rawText: text) else {
                completed(APIResponse.error(APIError.unknown))
                return
            }
            
            self.dataRequest = AF.request(rawRequest).responseJSON(completionHandler: { [weak self] data in
                guard let `self` = self else { return }
                completed(APIResponse(data, fromRequest: request))
                APIProcessingManager.instance.removeDispatcherFromList(dispatcher: self)
                print("▶︎ [API Processing Manager] Removed raw request from list for screen: \(self.target?.name ?? "none 🥶") !")
            })
            
        case .multipart(let datas, let parameters, let name, let filename, let mimeType):
            
            let httpFullHeader = prepareHeadersForMultipartOrBinary(request: request)
            
            AF.upload(multipartFormData: { (multipartFormData) in
                
                // add full params
                for (key, value) in parameters {
                    if let valueData = "\(value)".data(using: String.Encoding.utf8) {
                        multipartFormData.append(valueData, withName: key as String)
                    }
                }
                
                // add data follow define key of sever
                // eg: image1, image2, image3, ......
                for (key, data) in datas.enumerated() {
                    if let data = data {
                        multipartFormData.append(data, withName: name + "_\(key + 1)", fileName: filename, mimeType: mimeType)
                    }
                }
                
            }, to: request.url, usingThreshold: UInt64(), method: request.method, headers: httpFullHeader) { (results) in
                
                
//                switch result {
//                case .success(let upload, _, _):
//
//                    self.uploadRequest = upload.responseJSON(completionHandler: { [weak self] data in
//
//                        guard let `self` = self else { return }
//
//                        completed(APIResponse(data, fromRequest: request))
//
//                        APIProcessingManager.instance.removeDispatcherFromList(dispatcher: self)
//
//                        print("▶︎ [API Processing Manager] Removed multipart request from list for screen: \(self.target?.name ?? "none 🥶") !")
//                    })
//
//                case .failure(let error):
//
//                    let errorAPI = APIError.request(statusCode: nil, error: error)
//
//                    completed(APIResponse.error(errorAPI))
//                }
            }
            
        case .upload(let parameters):
            
//            AF.upload(multipartFormData: { (multipartFormData) in
//
//                for param in parameters {
//
//
//
//                    guard let paramName = param["name"] as? String else {
//                        return
//                    }
//                }
//
//            }, usingThreshold: UInt64(), to: request.url, method: request.method, headers: request.httpFullHeaders) { (encodingResult) in
//
//            }
            break
            
        case .rawBody(let params):
            
            /*
            let urlRequest = ConvertibleRequest(request)
            
            self.dataRequest = AF.request(urlRequest).responseJSON(completionHandler: { [weak self] data in
                
                guard let `self` = self else { return }
                
                completed(APIResponse(data, fromRequest: request))
                
                APIProcessingManager.instance.removeDispatcherFromList(dispatcher: self)
                
                print("▶︎ [API Processing Manager] Removed body request from list for screen: \(self.target?.name ?? "none 🥶") !")
                
            })
 
            */
            
            guard let rawRequest = custom(request: request, params: params) else {
                completed(APIResponse.error(APIError.unknown))
                return
            }
            
            self.dataRequest = AF.request(rawRequest).responseJSON(completionHandler: { [weak self] data in
                guard let `self` = self else { return }
                completed(APIResponse(data, fromRequest: request))
                APIProcessingManager.instance.removeDispatcherFromList(dispatcher: self)
                print("▶︎ [API Processing Manager] Removed raw request from list for screen: \(self.target?.name ?? "none 🥶") !")
            })
        }
        
        
    }
    
}


// MARK: -- Custom URLRequest binding raw data
extension APIDispatcher {
    
    func prepareRawFor(request: APIRequest, rawText: String) -> URLRequest? {
        
        // request url
        let environment = request.environment
        
        guard let url = URL(string: request.url) else { return nil }
        
        var urlRequest = URLRequest(url: url)
        urlRequest.cachePolicy = .reloadIgnoringCacheData
        
        // method
        urlRequest.httpMethod = request.method.rawValue
        
        // timeout interval
        urlRequest.timeoutInterval = environment.timeout
        
        // http header
        request.httpFullHeaders.forEach {
            
            urlRequest.setValue($0.value, forHTTPHeaderField: $0.name)
        }
        
        // casting raw data
        guard let textData = rawText.data(using: .utf8, allowLossyConversion: false) else {
            return nil
        }
        
        urlRequest.httpBody = textData
        
        return urlRequest
    }
    
    
    func custom(request: APIRequest, params: Parameters) -> URLRequest? {
        
        let environment = request.environment
        
        guard let url = URL(string: request.url) else { return nil }
        
        var urlRequest = URLRequest(url: url)
        urlRequest.cachePolicy = .reloadIgnoringCacheData
        
        // method
        urlRequest.httpMethod = request.method.rawValue
        
        // timeout interval
        urlRequest.timeoutInterval = environment.timeout
        
        // http header
        request.httpFullHeaders.forEach {
            
            urlRequest.setValue($0.value, forHTTPHeaderField: $0.name)
        }
        
        guard let data = try? JSONSerialization.data(withJSONObject: params, options: [.prettyPrinted]) else { return nil }
        
        let rawString = String(data: data, encoding: String.Encoding.utf8)
        
        if let json = rawString?.data(using: .utf8, allowLossyConversion: false) {
            urlRequest.httpBody = json
        }
        
        
        return urlRequest
    }
}


// MARK: Custom HTTPHeaders follow mutipart or binary
extension APIDispatcher {
    
    func prepareHeadersForMultipartOrBinary(request: APIRequest) -> HTTPHeaders {
        
        // -- custom header ....
        return request.httpFullHeaders
    }
}


extension APIDispatcher {
    

    func cancel() {
        
        if let dataRequest = self.dataRequest {
            dataRequest.cancel()
            self.dataRequest = nil
        }
        
        if let uploadRequest = self.uploadRequest {
            uploadRequest.cancel()
            self.uploadRequest = nil
        }
        
        APIProcessingManager.instance.removeDispatcherFromList(dispatcher: self)
    }
    
    
    // -- call api again: when disconnect internet user tap action 
    func retryExecute() {
        
        guard let request = self.request, let completionHandler = self.completionHandler else {
            print("Retry action fail")
            return
        }
        
        execute(request: request, completed: completionHandler)
    }
}


extension APIDispatcher {
    
    
}
