
import Foundation
import Alamofire


// MARK: -- Custom Request Convertible Alamofire
struct ConvertibleRequest {
    
    private var request: APIRequest
    
    init(_ request: APIRequest) {
        self.request = request
    }
    
    
}


extension ConvertibleRequest: URLRequestConvertible {
    
    func asURLRequest() throws -> URLRequest {
        
        // Request url
        let environment = request.environment
        
        var urlRequest: URLRequest = URLRequest(url: URL(string: request.url)!)
        
        // ignore cache data
        urlRequest.cachePolicy = .reloadIgnoringCacheData
        
        // method
        urlRequest.httpMethod = request.method.rawValue
        
        // timeout interval
        urlRequest.timeoutInterval = environment.timeout
        
        // http headers
        request.httpFullHeaders.forEach {
            urlRequest.setValue($0.value, forHTTPHeaderField: $0.name)
        }
        
        // parameters
        var parameters: Parameters = [:]
        
        switch request.parameters {
        case .body(let params):
            parameters = params
        case .rawBody(let params):
            parameters = params

            
            let data = try JSONSerialization.data(withJSONObject: parameters, options: [.prettyPrinted])
            
            let rawString = String(data: data, encoding: String.Encoding.utf8)
            
            if let json = rawString?.data(using: .utf8, allowLossyConversion: false) {
                urlRequest.httpBody = json
            }
            
            return try environment.encoding.encode(urlRequest, with: parameters)
        default:
            break
        }
        
        return try environment.encoding.encode(urlRequest, with: parameters)
    }
    
    
}


extension ParameterEncoding {
    
//    func encode(_ urlRequest: URLRequestConvertible, with parameters: Parameters?) throws -> URLRequest {
//        
//    }
}
