//
//  APIUIAlert.swift
//  SapPortal
//
//  Created by LuongTiem on 4/22/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class APIUIAlert {
    static func apiErrorDialog(error: APIError, completion: @escaping (() -> Void)) -> UIAlertController {
        // Write your code to show your api error dialog, call completion when done
        // Example:
        let alertVC = UIAlertController(title: nil, message: error.message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in
            completion()
        }))
        return alertVC
    }
    
    static func requestErrorDialog(error: APIError, completion: @escaping (() -> Void)) -> UIAlertController {
        // Write your code to show your api error dialog, call completion when done
        // Example:
        let alertVC = UIAlertController(title: nil, message: error.message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: { _ in
            completion()
        }))
        return alertVC
    }
    
    static func offlineErrorDialog(completion: @escaping ((_ index: Int, _ tapRetry: Bool) -> Void)) -> UIAlertController {
        let title = "Lỗi kết nối"
        let message = "Không có kết nối Internet, vui lòng thử lại."
        let buttons = ["Thử lại", "Đóng"]
        let alertVC = UIAlertController(title: title, message: message, preferredStyle: .alert)
        buttons.enumerated().forEach { button in
            let action = UIAlertAction(title: button.element, style: .default, handler: { _ in
                completion(button.offset, button.offset == 0)
            })
            alertVC.addAction(action)
        }
        return alertVC
    }
}
