//
//  APIUIIndicator.swift
//  SapPortal
//
//  Created by LuongTiem on 4/20/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation

class APIUIIndicator {
    
    public static var loadingView: LoadingView?
    
    static func showIndicator() {
        
        if APIUIIndicator.loadingView == nil {
            APIUIIndicator.loadingView = LoadingView.loading()
        }
    }
    
    static func hideIndicator() {

        APIUIIndicator.loadingView?.hidden(removeFromParent: true)
        APIUIIndicator.loadingView = nil
    }
}
