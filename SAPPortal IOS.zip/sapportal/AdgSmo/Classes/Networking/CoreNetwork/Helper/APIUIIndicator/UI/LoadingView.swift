//
//  LoadingView.swift
//  SapPortal
//
//  Created by LuongTiem on 4/20/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class LoadingView: UIView {
    
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        if #available(iOS 13.0, *) {
            overrideUserInterfaceStyle = .light
        } else {
            
        }
    }
    
    class func loading(parent: UIView? = UIApplication.shared.windows.last) -> LoadingView {
        
        let loadingView: LoadingView = LoadingView.fromNib()
        loadingView.translatesAutoresizingMaskIntoConstraints = false
        
        if let parent = parent {
            parent.addSubview(loadingView)
            loadingView.leadingAnchor.constraint(equalTo: parent.leadingAnchor).isActive = true
            loadingView.trailingAnchor.constraint(equalTo: parent.trailingAnchor).isActive = true
            loadingView.topAnchor.constraint(equalTo: parent.topAnchor).isActive = true
            loadingView.bottomAnchor.constraint(equalTo: parent.bottomAnchor).isActive = true
        }

        loadingView.iconImageView.rotate(duration: 1.2)
        loadingView.show(duration: 0.5)

        return loadingView
    }
    
    
    func hidden(removeFromParent: Bool) {
        hide(animation: true, duration: 0.35) {
            self.iconImageView.layer.removeAllAnimations()
            self.removeFromSuperview()
        }
    }
    
}

private extension UIView {
    
    func rotate(duration: CFTimeInterval = 0.8, toValue: Any = Float.pi*2, repeatCount: Float = Float.infinity, removeOnCompleted: Bool = false) {
        let animation = CABasicAnimation(keyPath: "transform.rotation.z")
        animation.duration = duration
        animation.toValue = toValue
        animation.repeatCount = repeatCount
        animation.isRemovedOnCompletion = removeOnCompleted
        layer.add(animation, forKey: "rotate")
    }
    
    // Remove rotate animation
    func stopRotate() {
        layer.removeAnimation(forKey: "rotate")
    }
    
}

private extension UIView {
    
    func show(animation: Bool = true, duration: TimeInterval = 0.3, completion: (() -> ())? = nil) {
        
        DispatchQueue.main.async {
            
            if !animation || !self.isHidden {
                self.isHidden = false
                completion?()
                return
            }
            
            let currentAlpha = self.alpha
            self.alpha = 0.05
            self.isHidden = false
            
            UIView.animate(withDuration: duration, animations: {
                self.alpha = currentAlpha
            }, completion: { (success) in
                completion?()
            })
        }
    }
    
    
    func hide(animation: Bool = true, duration: TimeInterval = 0.3, completion: (() -> ())? = nil) {
        
        DispatchQueue.main.async {
            
            if !animation || self.isHidden {
                self.isHidden = true
                completion?()
                return
            }
            
            let currentAlpha = self.alpha
            
            UIView.animate(withDuration: duration, animations: {
                self.alpha = 0
            }, completion: { (success) in
                self.isHidden = true
                self.alpha = currentAlpha
                completion?()
            })
        }
    }
}
