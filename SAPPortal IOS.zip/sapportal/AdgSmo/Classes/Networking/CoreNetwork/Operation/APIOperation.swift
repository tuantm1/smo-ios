
import Foundation
import SwiftyJSON
import SwiftEntryKit


protocol APIOperationProtocol {
    
    var request: APIRequest? { get set }
}



class APIOperation<T: APIResponseProtocol>: APIOperationProtocol {
    
    
    typealias Output = T
    
    typealias DataResponseSuccess = (_ result: Output) -> Void
    
    typealias DataResponseError = (_ result: APIError) -> Void

    
    // -- handler error UI
    typealias ErrorDialogResponse = (() -> Void)
    
    typealias OfflineDialogResponse = ((_ tapRetry: Bool) -> Void)
    
    
    struct TaskData {
        
        var responseQueue: DispatchQueue = .main
        
        var showIndicator: Bool = true
        
        var autoShowApiErrorAlert: Bool = true
        
        var autoShowRequestErrorAlert: Bool = true
        
        var didCloseApiErrorDialogHandler: ErrorDialogResponse? = nil
        
        var didCloseRequestErrorDialogHandler: ErrorDialogResponse? = nil
        
        var didCloseOfflineDialogHandler: OfflineDialogResponse? = nil
        
        var successHandler: DataResponseSuccess? = nil
        
        var failureHandler: DataResponseError? = nil
        
        
        init() { }
    }
    
    
    // MARK: - Variables
    private var taskData = TaskData()
    
    private var dispatcher: APIDispatcher?
    
    var request: APIRequest?
    
    init(request: APIRequest?) {
        
        self.request = request
        
        self.dispatcher = APIDispatcher()
    }
    
    
    deinit {
        print("APIOperation Denit")
    }
    
}


// MARK: - Builder (public)
extension APIOperation {
    
    @discardableResult
    func set(responseQueue: DispatchQueue) -> APIOperation<Output> {
        
        taskData.responseQueue = responseQueue
        
        return self
    }
    
    
    // Load request without: showing indicator + showing api error alert + request error alert automatically
    @discardableResult
    func set(silentLoad: Bool) -> APIOperation<Output> {
        
        taskData.showIndicator = !silentLoad
        
        taskData.autoShowApiErrorAlert = !silentLoad
        
        taskData.autoShowRequestErrorAlert = !silentLoad
        
        return self
    }
    
    
    @discardableResult
    func showIndicator(_ show: Bool) -> APIOperation<Output> {
        
        taskData.showIndicator = show
        
        return self
    }
    
    
    @discardableResult
    func autoShowApiErrorAlert(_ show: Bool) -> APIOperation<Output> {
        
        taskData.autoShowApiErrorAlert = show
        
        return self
    }
    
    
    @discardableResult
    func autoShowRequestErrorAlert(_ show: Bool) -> APIOperation<Output> {
        
        taskData.autoShowRequestErrorAlert = show
        
        return self
    }
    
    
    @discardableResult
    func didCloseApiErrorDialog(_ handler: @escaping ErrorDialogResponse) -> APIOperation<Output> {
        taskData.didCloseApiErrorDialogHandler = handler
        return self
    }
    
    
    @discardableResult
    func didCloseRequestErrorDialog(_ handler: @escaping ErrorDialogResponse) -> APIOperation<Output> {
        taskData.didCloseRequestErrorDialogHandler = handler
        return self
    }
    
    
    @discardableResult
    func didCloseOfflineErrorDialog(_ handler: @escaping OfflineDialogResponse) -> APIOperation<Output> {
        taskData.didCloseOfflineDialogHandler = handler
        return self
    }
    
    
}


// MARK: - Executing functions (public)
extension APIOperation {
    
    @discardableResult
    func execute(target: UIViewController? = nil, success: DataResponseSuccess? = nil, failure: DataResponseError? = nil) -> APIOperation<Output> {
        
        func run(queue: DispatchQueue?, body: @escaping () -> Void) {
            
            (queue ?? .main).async {
                body()
            }
        }
        
        
        dispatcher?.target = target
        
        taskData.successHandler = success
        
        taskData.failureHandler = failure
        
        let showIndicator = taskData.showIndicator
        
        let responseQueue = taskData.responseQueue
        
        guard let request = self.request else {
            run(queue: responseQueue) {
                self.callbackError(error: APIError.unknown)
            }
            return self
        }
        
        
        if showIndicator {
            
            run(queue: .main) {
                // -- show indicator
                APIUIIndicator.showIndicator()
            }
        }
        
        
        request.logAPI()
        print("▶︎ [\(request.name)] is requesting...")
        
        
        // Execute request
        dispatcher?.execute(request: request, completed: { response in
            
            if showIndicator {
                run(queue: .main, body: {
                    // -- hidden indicator
                    APIUIIndicator.hideIndicator()
                })
            }
            
            switch response {
            case .success(let json):
                print("▶︎ [\(request.name)] succeed !")
                
                run(queue: responseQueue, body: {
                    self.callbackSuccess(output: T(json: json))
                })
                
            case .error(let error):
                print("▶︎ [\(request.name)] error message: \"\(error.message ?? "empty")\"")
                
                run(queue: responseQueue, body: {
                    self.callbackError(error: error)
                })
            }
            
        })
        
        self.request = nil
        self.dispatcher = nil
        
        return self
    }
    
}


// MARK: Handler callback with input data
extension APIOperation {
    
    private func callbackSuccess(output: T) {
        
        taskData.successHandler?(output)
    }
    
    
    private func callbackError(error: APIError) {
        
        DispatchQueue.main.async {
            
            self.showErrorAlertIfNeeded(error: error)
        }
        
        taskData.failureHandler?(error)
    }
    
    
    private func showErrorAlertIfNeeded(error: APIError) {
        
        switch error {
        case .api(_, _, message: let message):
            guard taskData.autoShowApiErrorAlert else { return }
            APIUIAlert.apiErrorDialog(error: error) {
                 self.taskData.didCloseApiErrorDialogHandler?()
            }
            
        case .request(_, error: let error):
            guard taskData.autoShowRequestErrorAlert, let requestError = error else { return }
            if requestError.isInternetOffline {
                
//                AlertHelperKit.showAlertController(title: "Thông báo", message: requestError.localizedDescription, cancel: "Đồng ý", others: []) { (_, _) in
//
//                }
                
            } else {
                
//                AlertHelperKit.showAlertController(title: "Thông báo", message: requestError.localizedDescription, cancel: "Đồng ý", others: []) { (_, _) in
//
//                }
            }
            
        case .unknown:
             break
        }
    }
    
}
