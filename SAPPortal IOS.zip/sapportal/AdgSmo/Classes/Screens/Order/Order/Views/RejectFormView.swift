//
//  RejectFormView.swift
//  SapPortal
//
//  Created by LuongTiem on 5/10/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class RejectFormView: UIView {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var notCreditLabel: PaddingLabel!
    @IBOutlet weak var exceedingThePlainLabel: PaddingLabel!
    @IBOutlet weak var productNotShipLabel: PaddingLabel!
    @IBOutlet weak var reasonOtherTextField: UITextField!
    
    @IBOutlet weak var sendButton: RoundButton!
    
    
    var reasonRejectOrder: ((String) -> Void)?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        notCreditLabel.padding(8, 8, 8, 8)
        notCreditLabel.tag = 100
        notCreditLabel.isUserInteractionEnabled = true
        notCreditLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handlerNotCredit)))
        
        exceedingThePlainLabel.padding(8, 8, 8, 8)
        exceedingThePlainLabel.tag = 101
        exceedingThePlainLabel.isUserInteractionEnabled = true
        exceedingThePlainLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handlerExceedingThePlain)))
        
        productNotShipLabel.padding(8, 8, 8, 8)
        productNotShipLabel.tag = 102
        productNotShipLabel.isUserInteractionEnabled = true
        productNotShipLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handlerProductNotShip)))

    }
    
    @IBAction func sendAction(_ sender: Any) {
        
        self.reasonRejectOrder?(reasonOtherTextField.text ?? "")
    }
    

    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        borderLabel(notCreditLabel)
        borderLabel(exceedingThePlainLabel)
        borderLabel(productNotShipLabel)
        
        reasonOtherTextField.addPadding(.left(8))
        reasonOtherTextField.placeholderColor = UIColor(white: 0.5, alpha: 1)
        reasonOtherTextField.layer.borderColor = #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
        reasonOtherTextField.layer.borderWidth = 1
        reasonOtherTextField.layer.masksToBounds = true
        reasonOtherTextField.layer.cornerRadius = 8
    }
    
}

extension RejectFormView {
    
    @objc
    private func handlerNotCredit() {
        self.reasonRejectOrder?(notCreditLabel.text ?? "")
    }
    
    
    @objc
    private func handlerExceedingThePlain() {
        self.reasonRejectOrder?(exceedingThePlainLabel.text ?? "")
    }
    
    
    @objc
    private func handlerProductNotShip() {
        self.reasonRejectOrder?(productNotShipLabel.text ?? "")
    }
}

extension RejectFormView {
    
    private func borderLabel(_ label: PaddingLabel) {
        label.layer.borderColor = #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
        label.layer.borderWidth = 1
        label.layer.masksToBounds = true
        label.layer.cornerRadius = 8
    }

}
