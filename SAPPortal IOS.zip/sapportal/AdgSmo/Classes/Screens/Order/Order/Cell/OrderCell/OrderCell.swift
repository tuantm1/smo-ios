//
//  OrderCell.swift
//  SapPortal
//
//  Created by LuongTiem on 4/23/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

protocol ActionOrderDelegate {
    
    func selectApprove(cell: UITableViewCell)
    
    func selectReject(cell: UITableViewCell)
}

class OrderCell: UITableViewCell {
    
    @IBOutlet weak var nameItemLabel: UILabel!
    
    @IBOutlet weak var numberOrderLabel: UILabel!
    @IBOutlet weak var numberOrderContentLabel: UILabel!
    
    @IBOutlet weak var dateTimeLabel: UILabel!
    @IBOutlet weak var dateTimeContentLabel: UILabel!
    
    @IBOutlet weak var createByLabel: UILabel!
    @IBOutlet weak var createByContentLabel: UILabel!
    
    @IBOutlet weak var approveByLabel: UILabel!
    @IBOutlet weak var approveByContentLabel: UILabel!
    
    @IBOutlet weak var statusItemLabel: UILabel!
    @IBOutlet weak var statusItemContentLabel: PaddingLabel!
    
    @IBOutlet weak var noteLabel: UILabel!
    @IBOutlet weak var noteContentLabel: UILabel!
    
    @IBOutlet weak var actionView: UIStackView!
    @IBOutlet weak var topActionViewConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var approveButton: RoundButton!
    @IBOutlet weak var rejectButton: RoundButton!
    
    var delegate: ActionOrderDelegate?
    
    var orderModel: OrderModel? = nil {
        
        didSet {
            if let model = orderModel {
                self.bindingData(order: model)
            }
        }
    }
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        statusItemContentLabel.padding(5, 5, 8, 8)
        statusItemContentLabel.textColor = .white
        statusItemContentLabel.layer.cornerRadius = 12
        statusItemContentLabel.layer.masksToBounds = true
        
        approveButton.addTarget(self, action: #selector(touchApproveAction), for: .touchUpInside)
        rejectButton.addTarget(self, action: #selector(touchRejectAction), for: .touchUpInside)
        
        resetAllValue()
    }
    
    
    private func bindingData(order: OrderModel) {
        nameItemLabel.text = order.name
        numberOrderContentLabel.text = order.idOrder
        dateTimeContentLabel.text = order.date
        createByContentLabel.text = order.createByName
        approveByContentLabel.text = order.nameApprove
        noteContentLabel.text = order.note
        
        statusItemContentLabel.text = OrderModel.getStatusOrder(order: order).title
        statusItemContentLabel.backgroundColor = OrderModel.getStatusOrder(order: order).color
        
    }
    
    
    func configPermissionsAction(orderModel: OrderModel) {
        
        let permissionApprove: Bool = OrderModel.showHiddenAction(order: orderModel)
        
        topActionViewConstraint.constant = permissionApprove ? 24 : -actionView.frame.height
        actionView.isHidden = !permissionApprove
        
        self.approveButton.setTitle(OrderModel.getTilteAction(orderModel: orderModel).uppercased(), for: .normal)
    }
    
    
}

// MARK: -- ACTION
extension OrderCell {
    
    @objc
    private func touchApproveAction() {
        self.delegate?.selectApprove(cell: self)
    }
    
    @objc
    private func touchRejectAction() {
        self.delegate?.selectReject(cell: self)
    }
}

extension OrderCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    
    private func resetAllValue() {
        nameItemLabel.text = ""
        numberOrderContentLabel.text = ""
        dateTimeContentLabel.text = ""
        createByContentLabel.text = ""
        approveByContentLabel.text = ""
        statusItemContentLabel.text = ""
        noteContentLabel.text = ""
    }
}
