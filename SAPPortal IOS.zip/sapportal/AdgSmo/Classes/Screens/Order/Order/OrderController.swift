//
//  OrderController.swift
//  SapPortal
//
//  Created by LuongTiem on 4/23/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import SwiftEntryKit

class OrderController: BaseViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var listOrder: [OrderModel] = []
    
    var isCreateOrder: Bool = false
    var idOrder: String = "";
    
    private var filteredResults: [OrderModel] = [] {
        didSet {
            isSearching = true
        }
    }
    
    var menuModel: MenuModel!
    
    var isSearching: Bool = false {
        
        didSet {
            if tableView == nil { return }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    
    private let searchController = UISearchController(searchResultsController: nil)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if isCreateOrder {
            navigationItem.title = "DANH SÁCH ĐƠN ĐẶT HÀNG"
        } else {
            navigationItem.title = menuModel.description.uppercased()
        }
        
        tableView.register(UINib(nibName: OrderCell.className, bundle: nil), forCellReuseIdentifier: OrderCell.className)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 240
        tableView.tableFooterView = UIView()
        tableView.keyboardDismissMode = .onDrag
        
        
        searchController.delegate = self
        searchController.searchResultsUpdater = self
        searchController.searchBar.autocapitalizationType = .none
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.delegate = self // Monitor when the search button is tapped.
        
        definesPresentationContext = true
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchAllData()
    }
    
    
    override func fetchAllData() {
        
        GetOrderAPI.init(userID: MenuManager.shared.userID).execute(target: self, success: { (response) in
            
            self.listOrder = response.order
            
            if self.idOrder != "" {
                if let modelData = self.listOrder.first(where: {self.idOrder == $0.idOrder}) {
                    ApproveOrderActionAPI.init(userID: modelData.idUser,
                                               orderID: modelData.idOrder,
                                               checkCredit: OrderModel.getCheckCredit(orderModel: modelData)).execute(target: self, success: { (response) in
                        
                        self.fetchAllData()
                        
                    }) { (error) in
                        print(error)
                    }
                }
                self.idOrder = "";
            } else {
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
            
        }) { (error) in
            
        }
    }

}


extension OrderController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let items = isSearching ? filteredResults : listOrder
        
        let model = PassOrderData(indexItem: indexPath.row, listOrderModel: items)
        
        performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushOrderDetail, sender: model)
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case SegueIdentifier.MenuOrder.pushOrderDetail:
            if let model = sender as? PassOrderData, let vc = segue.destination as? OrderDetailController {
                vc.data = model
            }
        default:
            break
        }
    }
}


extension OrderController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return isSearching ? filteredResults.count : listOrder.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: OrderCell.className, for: indexPath) as? OrderCell else {
            return UITableViewCell()
        }
        
        let items = isSearching ? filteredResults : listOrder
        let model = items[indexPath.row]
        cell.orderModel = model
        cell.configPermissionsAction(orderModel: model)
        cell.delegate = self
        
        return cell
    }
}

// MARK: -- Show Popup
extension OrderController: ActionOrderDelegate {
    
    func selectApprove(cell: UITableViewCell) {
        
        if let selectedCell = cell as? OrderCell, let modelData = selectedCell.orderModel {
            
            let message = OrderModel.getTilteAction(orderModel: modelData)
            
            let alertViewController = UIAlertController(title: "Xác nhận", message: "Bạn muốn \(message) đơn hàng \(modelData.idOrder)?", preferredStyle: .alert)
            
            let okAction = UIAlertAction(title: "Có, Xác nhận", style: .default) { _ in
                
                ApproveOrderActionAPI.init(userID: modelData.idUser,
                                           orderID: modelData.idOrder,
                                           checkCredit: OrderModel.getCheckCredit(orderModel: modelData)).execute(target: self, success: { (response) in
                    
                    self.fetchAllData()
                    
                }) { (error) in
                    print(error)
                }
            }
            
            let cancelAction = UIAlertAction(title: "Không", style: .cancel, handler: nil)
            
            alertViewController.addAction(okAction)
            alertViewController.addAction(cancelAction)
            
            present(alertViewController, animated: true, completion: nil)
            
        }
    }
    
    func selectReject(cell: UITableViewCell) {
        guard let selectedCell = cell as? OrderCell, let modelData = selectedCell.orderModel else { return }
        
        let customView: RejectFormView = RejectFormView.fromNib()
        customView.layer.cornerRadius = 10
        customView.layer.masksToBounds = true
        customView.reasonRejectOrder = { reasonReject in
            SwiftEntryKit.dismiss()
            
            if reasonReject.isEmpty {
                AlertHelperKit.showDefaultAlert(message: "Chưa có lý do từ chối đơn hàng")
                return
            }
            
            RejectOrderActionAPI.init(userID: modelData.idUser, orderID: modelData.idOrder, reasonReject: reasonReject).execute(target: self, success: { (response) in
                self.fetchAllData()
            }) { (error) in
                
            }
        }
        
        AlertHelperKit.showSwiftEntryKit(customView: customView)
    }
}


// MARK: SEARCH

extension OrderController {
    
    private func findMatches(searchString: String = "") -> NSCompoundPredicate {
        
        var searchItemsPredicate: [NSPredicate] = []
        
        let titleExpression: NSExpression = NSExpression(forKeyPath: "name")
        let searchStringExpression = NSExpression(forConstantValue: searchString)
        
        let titleSearchComparisonPredicate = NSComparisonPredicate(leftExpression: titleExpression,
                                                                   rightExpression: searchStringExpression,
                                                                   modifier: .direct,
                                                                   type: .contains,
                                                                   options: [.caseInsensitive, .diacriticInsensitive])
        
        searchItemsPredicate.append(titleSearchComparisonPredicate)
        
        
        var finalCompoundPredicate: NSCompoundPredicate!
        
        finalCompoundPredicate = NSCompoundPredicate(orPredicateWithSubpredicates: searchItemsPredicate)
        
        return finalCompoundPredicate
    }
    
}

extension OrderController: UISearchResultsUpdating {
    
    func updateSearchResults(for searchController: UISearchController) {
        
        let searchResults = listOrder
        
        let strippedString = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        
        let searchItems = strippedString.components(separatedBy: " ") as [String]
        
        // Build all the "AND" expressions for each value in searchString.
        let andMatchPredicates: [NSPredicate] = searchItems.map { searchString in
            findMatches(searchString: searchString)
        }
        
        let finalCompoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: andMatchPredicates)
        
        filteredResults = searchResults.filter { finalCompoundPredicate.evaluate(with: $0) }
    }
    
}


extension OrderController: UISearchControllerDelegate {

    func didDismissSearchController(_ searchController: UISearchController) {
        isSearching = false
    }
    
    
    func willPresentSearchController(_ searchController: UISearchController) {
        
        isSearching = true
    }
}


extension OrderController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        updateSearchResults(for: searchController)
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {

    }
}
