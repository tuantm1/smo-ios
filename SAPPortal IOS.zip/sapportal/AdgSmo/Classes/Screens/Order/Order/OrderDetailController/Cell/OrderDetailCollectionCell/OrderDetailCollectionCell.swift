//
//  OrderDetailCollectionCell.swift
//  SapPortal
//
//  Created by LuongTiem on 5/5/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class OrderDetailCollectionCell: UICollectionViewCell {

    @IBOutlet weak var borderView: UIView!
    @IBOutlet weak var tableview: UITableView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        tableview.register(UINib(nibName: OrderDetailNoteCell.className, bundle: nil), forCellReuseIdentifier: OrderDetailNoteCell.className)
        tableview.register(UINib(nibName: OrderInformationCell.className, bundle: nil), forCellReuseIdentifier: OrderInformationCell.className)
        tableview.register(UINib(nibName: ShipmentDetailAndCreditCell.className, bundle: nil), forCellReuseIdentifier: ShipmentDetailAndCreditCell.className)
        tableview.register(UINib(nibName: HeaderTitleView.className, bundle: nil), forCellReuseIdentifier: HeaderTitleView.className)
        tableview.tableFooterView = UIView()
    }
    
    
    func setDelegateDatasourceTableView<D: UITableViewDelegate & UITableViewDataSource>(_ delegateDatasource: D, forRow row: Int) {
        
        tableview.delegate = delegateDatasource
        tableview.dataSource = delegateDatasource
        tableview.tag = row
        tableview.rowHeight = UITableView.automaticDimension
        tableview.estimatedRowHeight = 150
        tableview.setContentOffset(tableview.contentOffset, animated: false)
        tableview.layer.cornerRadius = 16
        tableview.layer.masksToBounds = true
        tableview.reloadData()
    }
    
    
    var offsetTableview: CGFloat {
        
        set {
            tableview.contentOffset.y = newValue
        }
        
        get {
            tableview.contentOffset.y
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
//        borderView.layer.borderWidth = 1
//        borderView.layer.cornerRadius = 16
//        borderView.layer.masksToBounds = true
//        borderView.layer.borderColor = #colorLiteral(red: 0, green: 0.3568627451, blue: 0.5882352941, alpha: 1)
    }

}

extension OrderDetailCollectionCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
    }
}
