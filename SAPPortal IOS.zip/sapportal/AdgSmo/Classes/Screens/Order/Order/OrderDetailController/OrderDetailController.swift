//
//  OrderDetailController.swift
//  SapPortal
//
//  Created by LuongTiem on 5/5/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

struct PassOrderData {
    
    var indexItem: Int = 0
    
    var listOrderModel: [OrderModel] = []
}

class OrderDetailController: BaseViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    private var keepTableview: UITableView!
    
    var data: PassOrderData!

    private var orderDetailModel = OrderDetailModel()
    
    private var customerDetailModel = CustomerDetailModel()
    
    private var dcModel: [DCModel] = []
    
    private var divisionModel: [DivisionModel] = []
    
    private var marasModel: [MarasModel] = []
    
    private var routeModel: RouteModel = RouteModel()
    
    private var isLoadDone: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: OrderDetailCollectionCell.className, bundle: nil), forCellWithReuseIdentifier: OrderDetailCollectionCell.className)
        
//        let currentIndex: String = "\(data.indexItem + 1)/\(data.listOrderModel.count)"
//        navigationItem.setTitle("ĐƠN HÀNG", subtitle: currentIndex)
        navigationItem.title = "ĐƠN HÀNG"
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        fetchAllData(orderModel: data.listOrderModel[data.indexItem])
    }
    
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let offsetX = collectionView.contentOffset.x
        
        let checkOffsetX = CGFloat(data.indexItem) * collectionView.frame.width
        
        if offsetX != checkOffsetX {
            collectionView.scrollToItem(at: IndexPath(item: data.indexItem, section: 0), at: [.centeredVertically, .centeredHorizontally], animated: false)
        }
    }
    
    
    private func fetchAllData(orderModel: OrderModel) {
        
        let group = DispatchGroup()
        self.isLoadDone = false
        APIUIIndicator.showIndicator()
        
        // ------
        group.enter()
        GetOrderDetailAPI.init(userID: orderModel.idOrder).showIndicator(false).execute(target: self, success: { (response) in
            self.orderDetailModel = response.orderDetail
            
            group.enter()
            GetUserDetailAPI.init(userID: orderModel.idUser).showIndicator(false).execute(target: self, success: { (response) in
                
                group.enter()
                GetCustomerDetailAPI.init(kunnr: response.user.user.kunnr).showIndicator(false).execute(target: self, success: { (response) in
                    self.customerDetailModel = response.customerDetailModel
                    group.leave()
                }) { (error) in
                    group.leave()
                }
                
                group.leave()
            }) { (error) in
                group.leave()
            }
            
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        // ------
        group.enter()
        GetDCAPI.init().showIndicator(false).execute(target: self, success: { (response) in
            group.leave()
            self.dcModel = response.dcModel
        }) { (error) in
            group.leave()
        }
        
        // ------
        group.enter()
        GetDivisionAPI.init().showIndicator(false).execute(target: self, success: { (response) in
            group.leave()
            self.divisionModel = response.divisions
        }) { (error) in
            group.leave()
        }
        
        //--
        group.enter()
        GetRouteAPI.init().showIndicator(false).execute(target: self, success: { (response) in
            self.routeModel = response.routeModel
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        //--
        group.enter()
        GetMarasAPI.init(orderModel: orderModel).showIndicator(false).execute(target: self, success: { (response) in
            self.marasModel = response.marasModel
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        
        // ---> finish fetch data
        group.notify(queue: DispatchQueue.main) {
            APIUIIndicator.hideIndicator()
            
            self.orderDetailModel.item.enumerated().forEach { (index, element) in
                if let itemFilter = self.marasModel.first(where: { $0.matnr == element.matnr }) {
                    self.orderDetailModel.item[index].price = itemFilter.price
                    self.orderDetailModel.item[index].zDKGH = itemFilter.zDKGH
                }
            }
            
            self.isLoadDone = true
            if self.keepTableview != nil {
                DispatchQueue.main.async {
                    self.keepTableview.reloadData()
                }
            }
        }
        
    }


}

// MARK: Table View Delegate && Datasource

extension OrderDetailController: UITableViewDelegate {
    

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView: HeaderTitleView = HeaderTitleView.fromNib()
        
        switch section {
        case 0:
            headerView.bindingData(title: "THÔNG TIN ĐẶT HÀNG", background: #colorLiteral(red: 0, green: 0.3568627451, blue: 0.5882352941, alpha: 1), titleColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
            return headerView
        case 2:
            headerView.bindingData(title: "THÔNG TIN GIAO HÀNG VÀ CÔNG NỢ", background: #colorLiteral(red: 0, green: 0.3568627451, blue: 0.5882352941, alpha: 1), titleColor: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0))
            return headerView
        default:
            return nil
        }
    }
        
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        if section == 1 {
            return CGFloat.leastNonzeroMagnitude
        }
        
        return 44
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 0 && self.orderDetailModel.item.count > indexPath.row {
            performSegue(withIdentifier: SegueIdentifier.OrderDetail.showItemDetailController, sender: self.orderDetailModel.item[indexPath.row])
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case SegueIdentifier.OrderDetail.showItemDetailController:
            if let vc = segue.destination as? ItemDetailController, let model = sender as? ItemModelClient {
                vc.passData = model
            }
        default:
            break
        }
    }
    
}

extension OrderDetailController: UITableViewDataSource {
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return self.isLoadDone ? 3 : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch section {
        case 0:
            return self.orderDetailModel.item.count
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.section {
        case 0:
            guard let cellInfo = tableView.dequeueReusableCell(withIdentifier: OrderInformationCell.className) as? OrderInformationCell else {
                return UITableViewCell()
            }
            
            if orderDetailModel.item.isEmpty {
                return UITableViewCell()
            }
            
            cellInfo.bindingData(model: orderDetailModel.item[indexPath.row])
            
            return cellInfo
        case 1:
            guard let cellNote = tableView.dequeueReusableCell(withIdentifier: OrderDetailNoteCell.className) as? OrderDetailNoteCell else {
                return UITableViewCell()
            }
            
            cellNote.bindingData(model: orderDetailModel)
            
            return cellNote
        default:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: ShipmentDetailAndCreditCell.className) as? ShipmentDetailAndCreditCell else {
                return UITableViewCell()
            }
            
            cell.bindingData(orderDetailModel: orderDetailModel,
                             listDC: self.dcModel,
                             listDivision: self.divisionModel,
                             routeModel: self.routeModel,
                             customerDetail: self.customerDetailModel)
            return cell
        }
        
        
    }
}


// MARK: Collection View Delegate && Datasource

extension OrderDetailController: UICollectionViewDelegate {
    
    
}


extension OrderDetailController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: collectionView.bounds.width, height: collectionView.frame.height)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    
}


extension OrderDetailController: UICollectionViewDataSource {
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if data == nil {
            return 0
        }
        
        return 1//data.listOrderModel.count
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
        guard let cellData = cell as? OrderDetailCollectionCell else { return }
        keepTableview = cellData.tableview
        
//        fetchAllData(idOrder: data.listOrderModel[data.indexItem].idOrder, idUser: data.listOrderModel[data.indexItem].idUser)
        
//        let currentIndex: String = "\(indexPath.item + 1)/\(data.listOrderModel.count)"
//        navigationItem.setTitle("ĐƠN HÀNG", subtitle: currentIndex)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: OrderDetailCollectionCell.className, for: indexPath) as! OrderDetailCollectionCell
        cell.setDelegateDatasourceTableView(self, forRow: indexPath.row)
        
        return cell
    }
}
