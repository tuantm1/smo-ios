//
//  OrderDetailNoteCell.swift
//  SapPortal
//
//  Created by LuongTiem on 5/6/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class OrderDetailNoteCell: UITableViewCell {
    
    @IBOutlet weak var noteLabel: UILabel!
    @IBOutlet weak var noteTextView: UITextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        noteTextView.text = ""
        
        noteTextView.layer.cornerRadius = 8
        noteTextView.layer.masksToBounds = true
        noteTextView.layer.borderColor = UIColor.lightGray.cgColor
        noteTextView.layer.borderWidth = 0.5
    }

    
    func bindingData(model: OrderDetailModel) {
        
        noteTextView.text = model.note
    }
    
    
}
