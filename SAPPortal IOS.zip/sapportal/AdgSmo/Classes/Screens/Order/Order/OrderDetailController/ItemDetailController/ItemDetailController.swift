//
//  ItemDetailController.swift
//  SapPortal
//
//  Created by LuongTiem on 8/10/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ItemDetailController: UIViewController {
    
    @IBOutlet weak var tableview: UITableView!
    var passData: ItemModelClient = ItemModelClient() {
        didSet {
            let model: ItemModelClient = passData;
            // -- loop characteristics
            model.characteristics.forEach { (characterItem) in
                
                // -- check
                if !self.listIDGroupSection.contains(characterItem.group) {
                    
                    if let item = AppDataShare.shared.createOrderGroup.first(where: { $0.groupID == characterItem.group }) {
                        
                        var copyTemp = item // copy model
                        let copyListCharacteristics = model.characteristics.filter { $0.group == characterItem.group }
                        let sort = copyListCharacteristics.sorted { (model1, model2) -> Bool in
                            return model1.sort < model2.sort
                        }
                        
                        copyTemp.listCharacteristics = sort
                        
                        self.listIDGroupSection.append(characterItem.group)
                        self.listData.append(copyTemp)
                    }
                }
            }
            
            if self.tableview != nil {
                self.tableview.reloadData()
            }
            
        }
    }
    
    private var listIDGroupSection: [String] = [] // -- verify group ID
    
    private var listData: [CreateOrderDetailSectionHeader] = []

    @IBOutlet weak var nameHeaderLabel: UILabel!
    @IBOutlet weak var dismissButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableview.delegate = self
        tableview.dataSource = self
        tableview.register(CreateOrderDetailCell.nib, forCellReuseIdentifier: CreateOrderDetailCell.className)
        tableview.register(HeaderTitleView.nib, forHeaderFooterViewReuseIdentifier: HeaderTitleView.className)
        tableview.register(CreateOrderSizeCell.nib, forCellReuseIdentifier: CreateOrderSizeCell.className)
        tableview.tableFooterView = UIView()
        tableview.keyboardDismissMode = .onDrag
        
        nameHeaderLabel.text = passData.name
    }
    
    @IBAction func dismissAction(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
}


extension ItemDetailController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        let groupSection = listData[indexPath.section]
        
        switch groupSection.groupID {
        case "02":
            return 180
        default:
            return 60
        }
        
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        guard let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: HeaderTitleView.className) as? HeaderTitleView else {
            return nil
        }
        
        headerView.bindingData(title: listData[section].title, background: #colorLiteral(red: 0, green: 0.3568627451, blue: 0.5882352941, alpha: 1), titleColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
        
        return headerView
    }
       
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44
    }
    
}

extension ItemDetailController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
           return listData.count
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        let groupSection = listData[section]
        switch groupSection.groupID {
        case "02":
            return 1
        default:
            return listData[section].listCharacteristics.count
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let groupSection = listData[indexPath.section]
        
        switch groupSection.groupID {
        case "02":
            guard let cell = tableView.dequeueReusableCell(withIdentifier: CreateOrderSizeCell.className) as? CreateOrderSizeCell else {
                return UITableViewCell()
            }
            
            let model = groupSection.listCharacteristics
            
            // -- check value array
            if model.count != 3 {
                return cell
            }
            
            cell.bindingData(titleFirst: model[0].smbez,
                             contentFirst: model[0].value,
                             titleSecond: model[1].smbez,
                             contentSecond: model[1].value,
                             titleSize: model[2].smbez)
            cell.isUserInteractionEnabled = false
            return cell
        default:
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: CreateOrderDetailCell.className, for: indexPath) as? CreateOrderDetailCell else {
                return UITableViewCell()
            }
            
            let model = groupSection.listCharacteristics[indexPath.row]
            
            switch model.atnam {
            case AppDataShare.CreateOrderKey.chonbotoi.atnam:
                
                let content = model.filterBoToi.isEmpty ? "" : model.filterBoToi[model.selectedIndex].maktx
                cell.bindingData(title: model.smbez, content: content)
                cell.isInputEnter = false
                
            case AppDataShare.CreateOrderKey.chonthanhray.atnam:
                
                let content = model.filterThanhRay.isEmpty ? "": model.filterThanhRay[model.selectedIndex].descriptions
                cell.bindingData(title: model.smbez, content: content)
                cell.isInputEnter = false
            default:
                let content = model.filterValue.isEmpty ? model.value : model.filterValue[model.selectedIndex].valDescr
                cell.bindingData(title: model.smbez, content: content)
                cell.isInputEnter = model.filterValue.isEmpty
            }
            
            cell.isUserInteractionEnabled = false
            return cell
        }
        
    }
    
    
}
