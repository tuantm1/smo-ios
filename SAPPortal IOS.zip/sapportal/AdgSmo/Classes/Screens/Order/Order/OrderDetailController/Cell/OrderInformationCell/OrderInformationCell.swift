//
//  OrderInformationCell.swift
//  SapPortal
//
//  Created by LuongTiem on 5/5/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class OrderInformationCell: UITableViewCell {
    
    @IBOutlet weak var itemLabel: UILabel!
    @IBOutlet weak var itemContentLabel: UILabel!
    
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var amountContentLabel: UITextField!
    
    @IBOutlet weak var unitLabel: UILabel!
    @IBOutlet weak var unitContentLabel: UILabel!
    
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var priceContentLabel: UILabel!
    
    @IBOutlet weak var separatorLineView: UIView!
    
    @IBOutlet weak var borderView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }
    
    
    func bindingData(model: ItemModelClient, isAddNewItem: Bool = false) {
        itemContentLabel.text = model.name
        amountContentLabel.isEnabled = isAddNewItem
        amountContentLabel.text = isAddNewItem ? "1" : "\(model.quantity)"
        unitContentLabel.text = model.saleUnit
        priceContentLabel.text = model.price.convertToCurrency
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        borderView.layer.borderWidth = 0.5
        borderView.layer.cornerRadius = 8
        borderView.layer.masksToBounds = true
        borderView.layer.borderColor = UIColor.lightGray.cgColor
        
    }
}

extension OrderInformationCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    private func resetAllValue() {
        itemContentLabel.text = ""
        amountContentLabel.text = ""
        unitContentLabel.text = ""
    }
}
