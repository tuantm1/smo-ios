//
//  ShipmentDetailAndCreditCell.swift
//  SapPortal
//
//  Created by LuongTiem on 5/7/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ShipmentDetailAndCreditCell: UITableViewCell {
    
    @IBOutlet weak var borderView: UIView!
    
    @IBOutlet weak var dateOrderLabel: UILabel!
    @IBOutlet weak var dateOrderContentLabel: UILabel!
    
    @IBOutlet weak var timeOrderLabel: UILabel!
    @IBOutlet weak var timeOrderContentLabel: UILabel!
    
    @IBOutlet weak var dealerLabel: UILabel!
    @IBOutlet weak var dealerContentLabel: UILabel!
    
    @IBOutlet weak var ngayGiaoHangTieuChuanLabel: UILabel!
    @IBOutlet weak var ngayGiaoHangTieuChuanContendLabel: UILabel!
    
    @IBOutlet weak var ngayCTYCLabel: UILabel!
    @IBOutlet weak var ngayCTYCContentLabel: UILabel!
    
    @IBOutlet weak var ngayGiaoHangLabel: UILabel!
    @IBOutlet weak var ngayGiaoHangContentLabel: UILabel!
    
    @IBOutlet weak var nguoiGIaoHangLabel: UILabel!
    @IBOutlet weak var nguoiGiaoHangContentLabel: UILabel!
    
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var addressContentLabel: UILabel!
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var cityContentLabel: UILabel!
    
    @IBOutlet weak var districtLabel: UILabel!
    @IBOutlet weak var districtContentLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var nameContentLabel: UILabel!
    
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var phoneContentLabel: UILabel!
    
    @IBOutlet weak var nameEndUserLabel: UILabel!
    @IBOutlet weak var nameEndUserContentLabel: UILabel!
    
    @IBOutlet weak var phoneEndUserLabel: UILabel!
    @IBOutlet weak var phoneEndUserContentLabel: UILabel!
    
    @IBOutlet weak var addressEndUserLabel: UILabel!
    @IBOutlet weak var addressEndUserContentLabel: UILabel!
    
    
    @IBOutlet weak var deliveryDateLabel: UILabel!
    @IBOutlet weak var deliveryDateContentLabel: UILabel!
    
    @IBOutlet weak var totalPriceLabel: UILabel!
    @IBOutlet weak var totalPriceContentLabel: UILabel!
    
    @IBOutlet weak var discountLabel: UILabel!
    @IBOutlet weak var discountContentLabel: UILabel!
    
    @IBOutlet weak var totalDiscountLabel: UILabel!
    @IBOutlet weak var totalDiscountContentLabel: UILabel!
    
    @IBOutlet weak var vatLabel: UILabel!
    @IBOutlet weak var vatContentLabel: UILabel!
    
    @IBOutlet weak var amountPayLabel: UILabel!
    @IBOutlet weak var amountPayContentLabel: UILabel!
    
    @IBOutlet weak var amountCreditLabel: UILabel!
    @IBOutlet weak var amountCreditContentLabel: UILabel!
    
    @IBOutlet weak var moneyGuaranteeLabel: UILabel!
    @IBOutlet weak var moneyGuaranteeContentLabel: UILabel!
    
    @IBOutlet weak var currentLiabilitiesLabel: UILabel!
    @IBOutlet weak var currentLiabilitiesContentLabel: UILabel!
    
    @IBOutlet weak var creditLimitLabel: UILabel!
    @IBOutlet weak var creditLimitContentLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var statusContentLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }
    
    func bindingData(orderDetailModel: OrderDetailModel, listDC: [DCModel], listDivision: [DivisionModel], routeModel: RouteModel, customerDetail: CustomerDetailModel) {
        
        let districtModel: DistrictModel? = routeModel.route.first { $0.route == orderDetailModel.route }
        
        let cityModel: CityModel? = routeModel.t173t.first { $0.vsart == orderDetailModel.vsart }
        
        dateOrderContentLabel.text = Date().convertString(formatter: "dd/MM/yyyy")
        deliveryDateContentLabel.text = orderDetailModel.date
        timeOrderContentLabel.text = orderDetailModel.time
        
        
        ngayCTYCContentLabel.text = orderDetailModel.zntcxd
        ngayGiaoHangContentLabel.text = orderDetailModel.zngayGH
        nguoiGiaoHangContentLabel.text = orderDetailModel.znguoiGH
        
        if !orderDetailModel.item.isEmpty {
            let increase = Int(orderDetailModel.item[0].zDKGH) ?? 0
            ngayGiaoHangTieuChuanContendLabel.text = Date.updateNewDate(dateString: "dd/MM/yyyy", increase: increase)
        }
        
        dealerContentLabel.text = orderDetailModel.nameShipTo
        addressContentLabel.text = orderDetailModel.address
        cityContentLabel.text = cityModel?.bezei
        districtContentLabel.text = districtModel?.bezei
        phoneContentLabel.text = orderDetailModel.phoneNumber
        phoneEndUserContentLabel.text = orderDetailModel.phoneEndUser
        nameContentLabel.text = orderDetailModel.nameNN
        nameEndUserContentLabel.text = orderDetailModel.nameEndUser
        addressEndUserContentLabel.text = orderDetailModel.addressEndUser
        
        totalPriceContentLabel.text = orderDetailModel.totalPrice.convertToCurrency
        discountContentLabel.text = orderDetailModel.ck.convertToCurrency
        totalDiscountContentLabel.text = (orderDetailModel.totalPrice - orderDetailModel.ck).convertToCurrency
        vatContentLabel.text = orderDetailModel.tax.convertToCurrency
        amountPayContentLabel.text = orderDetailModel.price.convertToCurrency
        amountCreditContentLabel.text = orderDetailModel.stbl.convertToCurrency
//        moneyGuaranteeContentLabel.text = orderDetailModel.stdbl.convertToCurrency
//        currentLiabilitiesContentLabel.text = orderDetailModel.creditValueCustom.convertToCurrency
//        creditLimitContentLabel.text = orderDetailModel.creditValue.convertToCurrency
        currentLiabilitiesContentLabel.text = setupLimitGuaranteeTitle(division: orderDetailModel.division,
            credits: customerDetail.creditCustomModel)?.amount.convertToCurrency
        
        creditLimitContentLabel.text = setupCreditTitle(division: orderDetailModel.division,
                                                                credits: customerDetail.creditModel)?.value.convertToCurrency
        
        statusContentLabel.text = OrderDetailModel.getStatusOrder(model: orderDetailModel)

        
    }
    
    private func setupLimitGuaranteeTitle(division: String, credits: [CreditCustomerModel]) -> CreditCustomerModel? {
        
        if let result = credits.first(where: { "CS\(division)" == $0.cs }) {
            
            return result
        }
        
        return nil
    }
    
    
    private func setupCreditTitle(division: String, credits: [CreditModel]) -> CreditModel? {
        
        if let result = credits.first(where: { "CS\(division)" == $0.cs }) {
            
            return result
        }
        
        return nil
    }
}

extension ShipmentDetailAndCreditCell {
    
    func resetAllValue() {
        dateOrderContentLabel.text = ""
        dealerContentLabel.text = ""
        addressContentLabel.text = ""
        cityContentLabel.text = ""
        districtContentLabel.text = ""
        phoneContentLabel.text = ""
        deliveryDateContentLabel.text = ""
        totalPriceContentLabel.text = ""
        discountContentLabel.text = ""
        totalDiscountContentLabel.text = ""
        vatContentLabel.text = ""
        amountPayContentLabel.text = ""
        amountCreditContentLabel.text = ""
        moneyGuaranteeContentLabel.text = ""
        currentLiabilitiesContentLabel.text = ""
        creditLimitContentLabel.text = ""
        statusContentLabel.text = ""
        
        ngayCTYCContentLabel.text = ""
        ngayGiaoHangContentLabel.text = ""
        nguoiGiaoHangContentLabel.text = ""
        ngayGiaoHangTieuChuanContendLabel.text = ""
    }
}
