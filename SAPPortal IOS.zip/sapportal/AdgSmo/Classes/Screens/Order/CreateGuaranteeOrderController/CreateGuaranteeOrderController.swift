//
//  CreateGuaranteeOrderController.swift
//  SapPortal
//
//  Created by LuongTiem on 8/12/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class CreateGuaranteeOrderController: BaseViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var borderView: UIView!
    
    var modelData: OrderModel!
    
    private var resultModel: TotalApproveSaleCreditDetailModel = TotalApproveSaleCreditDetailModel()
    
    private var isLoadingDone: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "YÊU CẦU BẢO LÃNH"
        
        tableView.register(UINib(nibName: InfoOrderDetailCell.className, bundle: nil), forCellReuseIdentifier: InfoOrderDetailCell.className)
        tableView.register(UINib(nibName: CreditDetailInfoCell.className, bundle: nil), forCellReuseIdentifier: CreditDetailInfoCell.className)
        tableView.register(UINib(nibName: OrderInformationCell.className, bundle: nil), forCellReuseIdentifier: OrderInformationCell.className)
        tableView.register(UINib(nibName: HeaderTitleView.className, bundle: nil), forCellReuseIdentifier: HeaderTitleView.className)
        tableView.tableFooterView = UIView()
        
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 150
        
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Bảo Lãnh", style: .done, target: self, action: #selector(guaranteeOrderHandler))
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchAllData()
    }
    
    
    override func fetchAllData() {
        super.fetchAllData()
        
        let group = DispatchGroup()
        
        // Step 1 ------
        isLoadingDone = false
        APIUIIndicator.showIndicator()
        group.enter()
        
        print(AppDataShare.shared.userDetail.user.userID)
        
        UserGuaranteeDetailAPI.init(idUser: AppDataShare.shared.userDetail.user.userID,
                                    idOrder: modelData.idOrder)
            .showIndicator(false)
            .execute(target: self, success: { (response) in
                self.resultModel.guardian = response.model
                // Step 5 ------
                group.enter()
                GetOrderDetailAPI.init(userID: self.modelData.idOrder)
                    .showIndicator(false)
                    .execute(target: self, success: { (response) in
                        self.resultModel.orderDetailModel = response.orderDetail
                        
                        //
                        group.enter()
                        GetUserDetailAPI.init(userID: self.resultModel.orderDetailModel.idApprove).showIndicator(false).execute(target: self, success: { (response) in
                            group.enter()
                            GetCustomerDetailAPI.init(kunnr: response.user.user.kunnr)
                                .showIndicator(false)
                                .execute(target: self, success: { (response) in
                                    self.resultModel.customerDetailModel = response.customerDetailModel
                                    group.leave()
                                }) { (error) in
                                    group.leave()
                            }
                            group.leave()
                        }) { (error) in
                            group.leave()
                        }
                        group.leave()
                    }) { (error) in
                        group.leave()
                }
                
                group.leave()
            }) { (error) in
                group.leave()
        }
        
        // Step 3 ------
        group.enter()
        GetDivisionAPI.init().showIndicator(false).execute(target: self, success: { (response) in
            self.resultModel.divisionModel = response.divisions
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        group.enter()
        UserGuaranteeDetailAPI.init(idUser: modelData.idApprove,
                                    idOrder: modelData.idOrder)
            .showIndicator(false)
            .execute(target: self, success: { (response) in
            self.resultModel.saleManager = response.model
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        // ---> finish fetch data
        group.notify(queue: DispatchQueue.main) {
            APIUIIndicator.hideIndicator()
            self.isLoadingDone = true
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }
        
    }
    
    
    @objc
    private func guaranteeOrderHandler() {
        
        let alertViewController = UIAlertController(title: "Xác nhận", message: "Bạn muốn bảo lãnh đơn hàng \(modelData.idOrder)?", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Có, Xác nhận", style: .default) { _ in
            
            CreateCreditAPI.init(model: self.resultModel).execute(target: self, success: { (response) in
                self.navigationController?.popViewController(animated: true)
            }) { (error) in
                AlertHelperKit.showDefaultAlert(message: "Bão lãnh không thành công")
            }
        }
        
        let cancelAction = UIAlertAction(title: "Không", style: .cancel, handler: nil)
        
        alertViewController.addAction(okAction)
        alertViewController.addAction(cancelAction)
        
        present(alertViewController, animated: true, completion: nil)
    }
}

extension CreateGuaranteeOrderController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView: HeaderTitleView = HeaderTitleView.fromNib()
        
        switch section {
        case 0:
            headerView.bindingData(title: "THÔNG TIN BẢO LÃNH", background: #colorLiteral(red: 0, green: 0.3568627451, blue: 0.5882352941, alpha: 1), titleColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
            return headerView
        case 1:
            headerView.bindingData(title: "THÔNG TIN ĐẶT HÀNG", background: #colorLiteral(red: 0, green: 0.3568627451, blue: 0.5882352941, alpha: 1), titleColor: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0))
            return headerView
        case 2:
            headerView.bindingData(title: "DANH SÁCH MẶT HÀNG", background: #colorLiteral(red: 0, green: 0.3568627451, blue: 0.5882352941, alpha: 1), titleColor: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0))
            return headerView
        default:
            return nil
        }
    }
        
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44
    }
}


extension CreateGuaranteeOrderController: UITableViewDataSource {
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.isLoadingDone ? 3 : 0
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch section {
        case 2:
            return self.resultModel.orderDetailModel.item.count
        default:
            return 1
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.section {
        case 0 where indexPath.row == 0:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: CreditDetailInfoCell.className) as? CreditDetailInfoCell else {
                return UITableViewCell()
            }
            
            cell.isCreateGuaranteeOrder = true
            cell.bindingCreateGuaranteeData(model: self.resultModel)

            cell.updateGuarantee = {
                self.view.endEditing(true)
                let vc: ItemListController = ItemListController(nibName: "ItemListController", bundle: nil)
                vc.listItem = self.resultModel.guardian.parents.map { $0.description }
                vc.indexSelected = self.resultModel.indexGuaranteeSelected
                vc.updateSelectedIndex = { index in
                    self.resultModel.indexGuaranteeSelected = index
                    self.tableView.reloadData()
                }
                
                AlertHelperKit.showControllerEntryKit(controller: vc)
            }
            
            cell.updateExpiresDay = {
                self.view.endEditing(true)
                let vc: ItemListController = ItemListController(nibName: "ItemListController", bundle: nil)
                vc.listItem = self.resultModel.dateExpires.model.map { "\($0) ngày"}
                vc.indexSelected = self.resultModel.dateExpires.indexSelected
                vc.updateSelectedIndex = { index in
                    self.resultModel.dateExpires.indexSelected = index
                    self.tableView.reloadData()
                }
                
                AlertHelperKit.showControllerEntryKit(controller: vc)
            }
            
            return cell
            
        case 1:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: InfoOrderDetailCell.className) as? InfoOrderDetailCell else {
                return UITableViewCell()
            }
            
            cell.bindingData(model: self.resultModel)
            
            return cell
            
        default:
            guard let cellInfo = tableView.dequeueReusableCell(withIdentifier: OrderInformationCell.className) as? OrderInformationCell else {
                return UITableViewCell()
            }
            
            let model = self.resultModel.orderDetailModel.item[indexPath.row]
            cellInfo.bindingData(model: model)
            
            return cellInfo
        }
    }
}
