//
//  GuaranteeListOrderCell.swift
//  SapPortal
//
//  Created by LuongTiem on 6/1/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class GuaranteeListOrderCell: UITableViewCell {
    
    @IBOutlet weak var codeOrderLabel: UILabel!
    @IBOutlet weak var codeOrderContentLabel: UILabel!
    
    @IBOutlet weak var dateOrderLabel: UILabel!
    @IBOutlet weak var dateOrderContentLabel: UILabel!
    
    @IBOutlet weak var agencyLabel: UILabel!
    
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var priceContentLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var statusContentLabel: PaddingLabel!
    
    @IBOutlet weak var approveButton: RoundButton!
    @IBOutlet weak var rejectButton: RoundButton!
    @IBOutlet weak var actionStackView: UIStackView!
    @IBOutlet weak var topActionStackViewConstraint: NSLayoutConstraint!
    
    
    var delegate: ActionOrderDelegate?
    
    
    var orderModel: OrderModel? = nil {
        
        didSet {
            if let model = orderModel {
                self.bindingData(order: model)
            }
        }
    }
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        
        statusContentLabel.padding(5, 5, 8, 8)
        statusContentLabel.textColor = .white
        statusContentLabel.layer.cornerRadius = 12
        statusContentLabel.layer.masksToBounds = true
        resetAllValue()
    }
    
    private func bindingData(order: OrderModel) {
        codeOrderLabel.text = "Số đơn đặt hàng"
        codeOrderContentLabel.text = "\(order.idOrder)"
        
        dateOrderLabel.text = "Ngày yêu cầu"
        dateOrderContentLabel.text = "\(order.date)"
        
        agencyLabel.customFontSize(firstString: "Đại lý được bảo lãnh:  ", firstFont: UIFont.systemFont(ofSize: 15),
                                   secondString: "\(order.nameShipTo)", secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        priceLabel.text = "Số tiền bảo lãnh"
        priceContentLabel.text = order.stbl.convertToCurrency
        
        statusLabel.text = "Trạng thái"
        statusContentLabel.text = OrderModel.getStatusGuarantee(order: order).title
        statusContentLabel.backgroundColor = OrderModel.getStatusGuarantee(order: order).color
        
    }
    
    
    func configPermissionsAction(orderModel: OrderModel) {
        
        let permissionApprove: Bool = OrderModel.showHiddenGuaranteeAction(order: orderModel)
        
        topActionStackViewConstraint.constant = permissionApprove ? 24 : -actionStackView.frame.height
        actionStackView.isHidden = !permissionApprove
    }
    
    
    
    
    @IBAction func approveAction(_ sender: Any) {
        self.delegate?.selectApprove(cell: self)
    }
    
    @IBAction func rejectAction(_ sender: Any) {
        self.delegate?.selectReject(cell: self)
    }
    
    
}

extension GuaranteeListOrderCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    
    private func resetAllValue() {
        codeOrderLabel.text = ""
        codeOrderContentLabel.text = ""
        dateOrderLabel.text = ""
        dateOrderContentLabel.text = ""
        agencyLabel.text = ""
        priceLabel.text = ""
        priceContentLabel.text = ""
        statusLabel.text = ""
        statusContentLabel.text = ""
    }
}
