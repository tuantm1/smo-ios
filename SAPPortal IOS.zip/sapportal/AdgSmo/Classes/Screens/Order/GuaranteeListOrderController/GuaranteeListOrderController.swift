//
//  ApproveCreditController.swift
//  SapPortal
//
//  Created by LuongTiem on 4/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import SwiftEntryKit

class GuaranteeListOrderController: BaseViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var listApproveCredit: [GuaranteeListOrderModel] = []
    
    var menuModel: MenuModel!
    
    private var filteredResults: [GuaranteeListOrderModel] = [] {
        didSet {
            isSearching = true
        }
    }
    
    var isSearching: Bool = false {
        
        didSet {
            if tableView == nil { return }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    private let searchController = UISearchController(searchResultsController: nil)

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = menuModel.description.uppercased()

        tableView.register(UINib(nibName: GuaranteeListOrderCell.className, bundle: nil), forCellReuseIdentifier: GuaranteeListOrderCell.className)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 240
        tableView.tableFooterView = UIView()
        tableView.keyboardDismissMode = .onDrag
        
        searchController.delegate = self
        searchController.searchResultsUpdater = self
        searchController.searchBar.autocapitalizationType = .none
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.delegate = self // Monitor when the search button is tapped.
        
        definesPresentationContext = true
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
    
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        GuaranteeListOrderAPI.init(userID: MenuManager.shared.userID).execute(target: self, success: { (response) in
            
            self.listApproveCredit = response.guaranteeListOrder
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }) { (error) in
            
        }
    }

}

extension GuaranteeListOrderController: UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let items = isSearching ? filteredResults : listApproveCredit
        
        let model = PassOrderData(indexItem: indexPath.row, listOrderModel: items)
        
        performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushOrderDetail, sender: model)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case SegueIdentifier.MenuOrder.pushOrderDetail:
            if let model = sender as? PassOrderData, let vc = segue.destination as? OrderDetailController {
                vc.data = model
            }
        case SegueIdentifier.MenuOrder.pushCreateGuaranteeOrderController:
        if let model = sender as? OrderModel, let vc = segue.destination as? CreateGuaranteeOrderController {
            vc.modelData = model
        }
        default:
            break
        }
    }
}


extension GuaranteeListOrderController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return isSearching ? filteredResults.count : listApproveCredit.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: GuaranteeListOrderCell.className, for: indexPath) as? GuaranteeListOrderCell else {
            return UITableViewCell()
        }
        
        let items = isSearching ? filteredResults : listApproveCredit
        let model = items[indexPath.row]
        cell.orderModel = model
        cell.configPermissionsAction(orderModel: model)
        cell.delegate = self
        
        return cell
    }
}


extension GuaranteeListOrderController: ActionOrderDelegate {
    
    func selectApprove(cell: UITableViewCell) {
        
        guard let selectedCell = cell as? GuaranteeListOrderCell, let modelData = selectedCell.orderModel else {
            return
        }

        performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushCreateGuaranteeOrderController, sender: modelData)
        
    }
    
    
    func selectReject(cell: UITableViewCell) {
        
        guard let selectedCell = cell as? GuaranteeListOrderCell, let modelData = selectedCell.orderModel else {
            return
        }
        
        let customView: RejectSalesCreditFormView = RejectSalesCreditFormView.fromNib()
        customView.layer.cornerRadius = 10
        customView.layer.masksToBounds = true
        customView.reasonRejectOrder = { reasonReject in
            SwiftEntryKit.dismiss()
            RejectOrderActionAPI.init(userID: modelData.idUser, orderID: modelData.idOrder, reasonReject: reasonReject).execute(target: self, success: { (response) in
                self.fetchAllData()
            }) { (error) in
                
            }
        }
        
        AlertHelperKit.showSwiftEntryKit(customView: customView)
    }

}

// MARK: SEARCH

extension GuaranteeListOrderController {
    
    private func findMatches(searchString: String = "") -> NSCompoundPredicate {
        
        var searchItemsPredicate: [NSPredicate] = []
        
        let titleExpression: NSExpression = NSExpression(forKeyPath: "nameShipTo")
        let searchStringExpression = NSExpression(forConstantValue: searchString)
        
        let titleSearchComparisonPredicate = NSComparisonPredicate(leftExpression: titleExpression,
                                                                   rightExpression: searchStringExpression,
                                                                   modifier: .direct,
                                                                   type: .contains,
                                                                   options: [.caseInsensitive, .diacriticInsensitive])
        
        searchItemsPredicate.append(titleSearchComparisonPredicate)
        
        
        var finalCompoundPredicate: NSCompoundPredicate!
        
        finalCompoundPredicate = NSCompoundPredicate(orPredicateWithSubpredicates: searchItemsPredicate)
        
        return finalCompoundPredicate
    }
    
}

extension GuaranteeListOrderController: UISearchResultsUpdating {
    
    func updateSearchResults(for searchController: UISearchController) {
        
        let searchResults = listApproveCredit
        
        let strippedString = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        
        let searchItems = strippedString.components(separatedBy: " ") as [String]
        
        // Build all the "AND" expressions for each value in searchString.
        let andMatchPredicates: [NSPredicate] = searchItems.map { searchString in
            findMatches(searchString: searchString)
        }
        
        let finalCompoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: andMatchPredicates)
        
        filteredResults = searchResults.filter { finalCompoundPredicate.evaluate(with: $0) }
    }
    
}


extension GuaranteeListOrderController: UISearchControllerDelegate {

    func didDismissSearchController(_ searchController: UISearchController) {
        isSearching = false
    }
    
    
    func willPresentSearchController(_ searchController: UISearchController) {
        
        isSearching = true
    }
}


extension GuaranteeListOrderController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        updateSearchResults(for: searchController)
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
    }
}
