//
//  ReturnOrderController.swift
//  SapPortal
//
//  Created by LuongTiem on 4/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import SwiftEntryKit

class ReturnOrderController: BaseViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var listReturnOrder: [ReturnOrderModel] = []
    
    private var filteredResults: [ReturnOrderModel] = [] {
        didSet {
            isSearching = true
        }
    }
    
    var isSearching: Bool = false {
        
        didSet {
            if tableView == nil { return }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    var menuModel: MenuModel!
    
    let searchController = UISearchController(searchResultsController: nil)
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = menuModel.description.uppercased()
        
        tableView.register(UINib(nibName: OrderCell.className, bundle: nil), forCellReuseIdentifier: OrderCell.className)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 240
        tableView.tableFooterView = UIView()
        tableView.keyboardDismissMode = .onDrag
        
        searchController.delegate = self
        searchController.searchResultsUpdater = self
        searchController.searchBar.autocapitalizationType = .none
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.delegate = self // Monitor when the search button is tapped.
        
        definesPresentationContext = true
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        GetReturnOrderAPI.init(userID: MenuManager.shared.userID).execute(target: self, success: { (response) in
            
            self.listReturnOrder = response.returnOrder
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }) { (error) in
            
        }
    }
}


extension ReturnOrderController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let items = isSearching ? filteredResults : listReturnOrder
        
        let model = PassOrderData(indexItem: indexPath.row, listOrderModel: items)
        
        performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushOrderDetail, sender: model)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case SegueIdentifier.MenuOrder.pushOrderDetail:
            if let model = sender as? PassOrderData, let vc = segue.destination as? OrderDetailController {
                vc.data = model
            }
        default:
            break
        }
    }
}


extension ReturnOrderController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return isSearching ? filteredResults.count : listReturnOrder.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: OrderCell.className, for: indexPath) as? OrderCell else {
            return UITableViewCell()
        }
        
        let items = isSearching ? filteredResults : listReturnOrder
        let model = items[indexPath.row]
        cell.orderModel = model
        cell.configPermissionsAction(orderModel: model)
        cell.delegate = self
        
        return cell
    }
}

extension ReturnOrderController: ActionOrderDelegate {
    
    func selectApprove(cell: UITableViewCell) {
        
        guard let selectedCell = cell as? OrderCell, let modelData = selectedCell.orderModel else {
            return
        }
        
        AlertHelperKit.showDefaultAlert(message: "Tính năng đang được cập nhật") {
            
        }
    }
    
    func selectReject(cell: UITableViewCell) {
        
        guard let selectedCell = cell as? OrderCell, let modelData = selectedCell.orderModel else { return }
        
        let customView: RejectSalesCreditFormView = RejectSalesCreditFormView.fromNib()
        customView.layer.cornerRadius = 10
        customView.layer.masksToBounds = true
        customView.reasonRejectOrder = { reasonReject in
            SwiftEntryKit.dismiss()
            self.fetchAllData()
        }
        
        AlertHelperKit.showSwiftEntryKit(customView: customView)
    }
    
}


// MARK: SEARCH

extension ReturnOrderController {
    
    private func findMatches(searchString: String = "") -> NSCompoundPredicate {
        
        var searchItemsPredicate: [NSPredicate] = []
        
        let titleExpression: NSExpression = NSExpression(forKeyPath: "name")
        let searchStringExpression = NSExpression(forConstantValue: searchString)
        
        let titleSearchComparisonPredicate = NSComparisonPredicate(leftExpression: titleExpression,
                                                                   rightExpression: searchStringExpression,
                                                                   modifier: .direct,
                                                                   type: .contains,
                                                                   options: [.caseInsensitive, .diacriticInsensitive])
        
        searchItemsPredicate.append(titleSearchComparisonPredicate)
        
        
        var finalCompoundPredicate: NSCompoundPredicate!
        
        finalCompoundPredicate = NSCompoundPredicate(orPredicateWithSubpredicates: searchItemsPredicate)
        
        return finalCompoundPredicate
    }
    
}

extension ReturnOrderController: UISearchResultsUpdating {
    
    func updateSearchResults(for searchController: UISearchController) {
        
        let searchResults = listReturnOrder
        
        let strippedString = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        
        let searchItems = strippedString.components(separatedBy: " ") as [String]
        
        // Build all the "AND" expressions for each value in searchString.
        let andMatchPredicates: [NSPredicate] = searchItems.map { searchString in
            findMatches(searchString: searchString)
        }
        
        let finalCompoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: andMatchPredicates)
        
        filteredResults = searchResults.filter { finalCompoundPredicate.evaluate(with: $0) }
    }
    
}


extension ReturnOrderController: UISearchControllerDelegate {

    func didDismissSearchController(_ searchController: UISearchController) {
        isSearching = false
    }
    
    
    func willPresentSearchController(_ searchController: UISearchController) {
        
        isSearching = true
    }
}


extension ReturnOrderController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        updateSearchResults(for: searchController)
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {

    }
}
