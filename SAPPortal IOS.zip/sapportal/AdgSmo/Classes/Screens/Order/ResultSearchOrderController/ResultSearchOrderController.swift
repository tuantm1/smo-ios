//
//  ResultSearchOrderController.swift
//  SapPortal
//
//  Created by LuongTiem on 5/29/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ResultSearchOrderController: UITableViewController {
    
    var filteredProducts: [OrderModel] = []

    override func viewDidLoad() {
        super.viewDidLoad()


    }


}


extension ResultSearchOrderController {
    
    
}
