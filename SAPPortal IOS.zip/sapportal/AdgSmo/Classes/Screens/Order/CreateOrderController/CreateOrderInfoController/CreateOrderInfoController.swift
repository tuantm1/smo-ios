//
//  CreateOrderInfoController.swift
//  SapPortal
//
//  Created by LuongTiem on 8/4/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

struct CityMapping {
    
    var indexSelected: Int = 0
    
    var model: [CityModel] = []
}

struct DistrictMapping {
    
    var indexSelected: Int = 0
    
    var model: [DistrictModel] = []
}

struct MappingCreateOrder {
    
    var chonNgayGiaoHang: String = Date().convertString(formatter: "dd/MM/yyyy")
    
    var time: String = Date().convertString(formatter: "HH:mm")
    
    var addresses: String = ""
    
    var chonLoaiTieuChuan: String = "0"
    
    var vsart: String = ""
    
    var route: String = ""
    
    var note: String = ""
    
    var name: String = ""
    
    var phone: String = ""
    
    var nameEndUser: String = ""
    
    var phoneEndUser: String = ""
    
    var addressEndUser: String = ""
    
    var zType: String = ""
    
    init() {
        
    }
}

class CreateOrderInfoController: UIViewController {

    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var addNewItemButton: UIButton!
    
    
    var passDataModel: GetDetailTempModel!
    
    private var dcModel: [DCModel] = []
    
    private var divisionModel: [DivisionModel] = []
    
    private var marasModel: [MarasModel] = []
    
    private var routeModel: RouteModel = RouteModel() {
        didSet {
            if routeModel.route.isEmpty || self.routeModel.t173t.isEmpty {
                return
            }
            
            self.cityFilter = CityMapping(indexSelected: 0, model: routeModel.t173t)
            
            let data = self.routeModel.route.filter { $0.vsart == self.cityFilter.model[self.cityFilter.indexSelected].vsart }
            self.dictrictFilter = DistrictMapping(indexSelected: 0, model: data)
            
            self.tableview.reloadData()
        }
    }
    
    private var dictrictFilter: DistrictMapping = DistrictMapping(indexSelected: 0, model: [])
       
    private var cityFilter: CityMapping = CityMapping(indexSelected: 0, model: [])
    
    private var customerDetailModel: CustomerDetailModel = CustomerDetailModel() {
        didSet {
            let phone = displayPhoneNumber(model: customerDetailModel)
            self.mappingCreateOrder.phone = phone
        }
    }
    
    private var checkPrice: CheckPriceModel = CheckPriceModel()
    
    private var mappingCreateOrder: MappingCreateOrder = MappingCreateOrder()
    
    private var listAddItemModel: [ItemModelClient] = []
    
    var currentSelect = 0;
    
    var isPushScreen1: Bool = false
    
    var zType: String = "";
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Thông tin đặt hàng"

        tableview.register(UINib(nibName: DeliveryNoteDetailCell.className, bundle: nil), forCellReuseIdentifier: DeliveryNoteDetailCell.className)
        tableview.register(UINib(nibName: OrderInformationCell.className, bundle: nil), forCellReuseIdentifier: OrderInformationCell.className)
        tableview.register(UINib(nibName: HeaderTitleView.className, bundle: nil), forCellReuseIdentifier: HeaderTitleView.className)
        tableview.register(UINib(nibName: DeliveryLiabilitiesInfoCell.className, bundle: nil), forCellReuseIdentifier: DeliveryLiabilitiesInfoCell.className)
        tableview.tableFooterView = UIView()
        tableview.rowHeight = UITableView.automaticDimension
        tableview.separatorStyle = .none
        tableview.estimatedRowHeight = 150
        tableview.delegate = self
        tableview.dataSource = self
        
        addNewItemButton.layer.cornerRadius = 20
        addNewItemButton.layer.masksToBounds = true
        addNewItemButton.tintColor = UIColor.blue
        
        let rightBarButton = UIBarButtonItem(title: "Đặt Hàng", style: .done, target: self, action: #selector(createOrderHandler))
        navigationItem.rightBarButtonItem = rightBarButton
        
        fetchAllData()
    }
    
    @IBAction func addNewItemAction(_ sender: Any) {
        
        let vc: AddNewItemController = AddNewItemController(nibName: "AddNewItemController", bundle: nil)
        vc.listItem = listAddItemModel
        
        vc.didSelectedItem = { result in
            
            if let indexFilter = self.passDataModel.items.firstIndex(where: { $0.matnr == result.matnr }) {
                self.passDataModel.items[indexFilter].quantity = result.quantity
            } else {
                
                let copyModel = result
                copyModel.idItem = "\(self.passDataModel.items.count + 1)"
                
                self.passDataModel.items.append(copyModel)
            }
            
            // -- reload data
            CheckPriceAPI.init(model: self.passDataModel).execute(target: self, success: { (response) in
                self.checkPrice = response.model
                self.tableview.reloadData()
            }) { (error) in
                self.tableview.reloadData()
            }
            
            self.tableview.reloadData()
        }
        
        AlertHelperKit.showControllerEntryKit(controller: vc)

    }
    
    
    @objc
    private func createOrderHandler() {
        
        self.view.endEditing(true)
        
        let alert = UIAlertController(title: "Xác nhận đặt hàng", message: "", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Gửi đơn hàng", style: .default, handler: { _ in
            
            CreateOrderAPI.init(tempModel: self.passDataModel,
                                checkPriceModel: self.checkPrice,
                                customer: self.customerDetailModel,
                                mapping: self.mappingCreateOrder).execute(target: self, success: { (response) in
                
                if response.model.idOrder.isEmpty {
                    AlertHelperKit.showDefaultAlert(message: "Đặt hàng không thành công")
                    return
                } else {
                    if let vc = self.navigationController?.viewControllers[0] as? MenuOrderController {
                        vc.isGoList = true
                        vc.idOrder = response.model.idOrder
                    }
                    self.navigationController?.popToRootViewController(animated: true)
                }
                
            }) { (error) in
                
            }
        }))
        
        
        let cancelAction = UIAlertAction(title: "Hủy", style: .destructive, handler: nil)
        alert.addAction(cancelAction)
        
        self.present(alert, animated: true)
    }
    
    private func fetchAllData() {
        
        let group = DispatchGroup()
        
        // ------
        APIUIIndicator.showIndicator()
        group.enter()
        GetDCAPI.init().showIndicator(false).execute(target: self, success: { (response) in
            group.leave()
            self.dcModel = response.dcModel
        }) { (error) in
            group.leave()
        }
        
        // ------
        group.enter()
        GetDivisionAPI.init().showIndicator(false).execute(target: self, success: { (response) in
            group.leave()
            self.divisionModel = response.divisions
        }) { (error) in
            group.leave()
        }
        
        //--
        group.enter()
        GetRouteAPI.init().showIndicator(false).execute(target: self, success: { (response) in
            self.routeModel = response.routeModel
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        group.enter()
        GetCustomerDetailAPI.init(kunnr: AppDataShare.shared.userDetail.user.kunnr).showIndicator(false).execute(target: self, success: { (response) in
            self.customerDetailModel = response.customerDetailModel
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        
        group.enter()
        CheckPriceAPI.init(model: self.passDataModel).showIndicator(false).execute(target: self, success: { (response) in
            self.checkPrice = response.model
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        
        // Load add new item
        group.enter()
        var type: String = "PK"
        
        if !passDataModel.items.isEmpty {
            
            if passDataModel.items[0].extwg == "PKAD" || passDataModel.items[0].extwg == "PKDT" {
                type = passDataModel.items[0].extwg
            }
            
        }
        
        if !self.zType.isEmpty {
            type = self.zType
        }
        
        GetMarasAPI.init(zType: type).execute(target: self, success: { (response) in
            
            response.marasModel.enumerated().forEach { (index, item) in
                
                let model = ItemModelClient()
                model.quantity = 1
                model.matnr = item.matnr
                model.name = item.maktx
                model.saleUnit = item.meins
                model.price = item.price
                
                self.listAddItemModel.append(model)
            }
            group.leave()
            
        }) { (error) in
            group.leave()
        }
        
        // ---> finish fetch data
        group.notify(queue: DispatchQueue.main) {
            
            self.mappingCreateOrder.addresses = self.customerDetailModel.address
            
            if !self.routeModel.route.isEmpty && !self.routeModel.t173t.isEmpty {
                
                let citySelected = self.cityFilter.model[self.cityFilter.indexSelected]
                
                let filter = self.routeModel.route.filter { $0.vsart == citySelected.vsart }
                self.dictrictFilter.model = filter
                
                self.mappingCreateOrder.vsart = self.cityFilter.model[self.cityFilter.indexSelected].vsart
                self.mappingCreateOrder.route = self.dictrictFilter.model[self.dictrictFilter.indexSelected].route
            }
            APIUIIndicator.hideIndicator()
            self.tableview.reloadData()
        }
        self.mappingCreateOrder.zType = self.zType;
    }
    

}

extension CreateOrderInfoController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView: HeaderTitleView = HeaderTitleView.fromNib()
        
        switch section {
        case 0:
            headerView.bindingData(title: "THÔNG TIN ĐẶT HÀNG", background: #colorLiteral(red: 0, green: 0.3568627451, blue: 0.5882352941, alpha: 1), titleColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
            return headerView
        case 2:
            headerView.bindingData(title: "THÔNG TIN GIAO HÀNG VÀ CÔNG NỢ", background: #colorLiteral(red: 0, green: 0.3568627451, blue: 0.5882352941, alpha: 1), titleColor: #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0))
            return headerView
        default:
            return nil
        }
    }
        
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        if section == 1 {
            return CGFloat.leastNonzeroMagnitude
        }
        
        return 44
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 1 && indexPath.row == 0 && !isPushScreen1 {
            self.navigationController?.popViewController(animated: true)
        }
        if indexPath.section == 1 && (indexPath.row > 0 || isPushScreen1) && self.passDataModel.items.count > indexPath.row {
            currentSelect = indexPath.row;
            let imc: ItemModelClient = self.passDataModel.items[currentSelect]
            if imc.characteristics.isEmpty {
                GetCharacteristicDefaultAPI.init(matnr: imc.matnr).showIndicator(true).execute(target: self, success: { (response) in
                    response.gtCharacter.forEach{(characterItem) in
                        let char: CharacteristicModel = CharacteristicModel(atnam: characterItem.atnam, smbez: characterItem.smbez, value: characterItem.zValue, group: characterItem.zgroup, sort: characterItem.zSort);
                        imc.characteristics.append(char);
                    }
                    self.performSegue(withIdentifier: SegueIdentifier.OrderDetail.showItemDetailEdit, sender: imc)
                }) { (error) in
                    AlertHelperKit.showDefaultAlert(message: "Lỗi sever, vui lòng thử lại sau")
                }
            } else {
                self.performSegue(withIdentifier: SegueIdentifier.OrderDetail.showItemDetailEdit, sender: imc)
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case SegueIdentifier.OrderDetail.showItemDetailEdit:
            if let vc = segue.destination as? EditOrderDetailController, let model = sender as? ItemModelClient {
                vc.templateItemModelClient = model
                vc.didSendData = { [weak self] imc in
                    guard let self = self else { return }
                    self.passDataModel.items[self.currentSelect].characteristics = imc.characteristics
                    if imc.characteristics.contains(where: {"Z_RAY" == $0.atnam.uppercased()}) {
                        if let zSoThanh = imc.characteristics.first(where: {"Z_SO_THANH" == $0.atnam.uppercased()})?.value.toDouble, let zKtThanh = imc.characteristics.first(where: {"Z_KT_THANH" == $0.atnam.uppercased()})?.value.toDouble {
                            self.passDataModel.items[self.currentSelect].quantity = zSoThanh * zKtThanh / 1000
                            
                            // -- reload data
                            CheckPriceAPI.init(model: self.passDataModel).execute(target: self, success: { (response) in
                                self.checkPrice = response.model
                                self.tableview.reloadData()
                            }) { (error) in
                                self.tableview.reloadData()
                            }
                        }
                    }
                }
            }
        default:
            break
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        
        if indexPath.section == 1 {
            
            if !isPushScreen1 && indexPath.row == 0 {
                return false
                
            }
            
            return true
        }
        
        return false
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        tableview.beginUpdates()
        _ = self.passDataModel.items.remove(at: indexPath.row)
        tableview.deleteRows(at: [indexPath], with: .automatic)
        self.tableview.endUpdates()
        
        CheckPriceAPI.init(model: self.passDataModel).execute(target: self, success: { (response) in
            self.checkPrice = response.model
            self.tableview.reloadData()
        }) { (error) in
            self.tableview.reloadData()
        }
    }
}

extension CreateOrderInfoController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch section {
        case 1:
            return self.passDataModel.items.count
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.section {
        case 1 :
            guard let cellInfo = tableView.dequeueReusableCell(withIdentifier: OrderInformationCell.className) as? OrderInformationCell else {
                return UITableViewCell()
            }
            cellInfo.bindingData(model: self.passDataModel.items[indexPath.row])
            
            return cellInfo
            
        case 0:
            guard let cellNote = tableView.dequeueReusableCell(withIdentifier: DeliveryNoteDetailCell.className) as? DeliveryNoteDetailCell else {
                return UITableViewCell()
            }
            cellNote.updateRadioUI = { result in
                self.mappingCreateOrder.chonLoaiTieuChuan = result
            }
            cellNote.updateNote = { note in
                self.mappingCreateOrder.note = note
                
            }
            cellNote.bindingData(model: self.passDataModel)
            return cellNote
        default:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: DeliveryLiabilitiesInfoCell.className) as? DeliveryLiabilitiesInfoCell else {
                return UITableViewCell()
            }
            
            cell.routeModel = routeModel
            cell.templaceDetailModel = passDataModel
            cell.division = passDataModel.division
            cell.checkPrice = checkPrice
            cell.cityMapping = self.cityFilter
            cell.districtMapping = self.dictrictFilter
            cell.customerDetailModel = customerDetailModel
            
            // -- city
            cell.updateCityIndex = { indexSelected in
                
                if self.routeModel.route.isEmpty || self.routeModel.t173t.isEmpty { return }
                
                self.cityFilter.indexSelected = indexSelected
                
                let citySelected = self.cityFilter.model[self.cityFilter.indexSelected]
                
                let filter = self.routeModel.route.filter { $0.vsart == citySelected.vsart }
                self.dictrictFilter.model = filter
                
                self.dictrictFilter.indexSelected = 0
                cell.cityMapping = self.cityFilter
                cell.districtMapping = self.dictrictFilter
                
                self.mappingCreateOrder.vsart = self.cityFilter.model[self.cityFilter.indexSelected].vsart
                self.mappingCreateOrder.route = self.dictrictFilter.model[self.dictrictFilter.indexSelected].route
                
                self.tableview.reloadData()
                
            }
            
            // -- district
            cell.updateDistrictIndex = { indexSelected in
                self.dictrictFilter.indexSelected = indexSelected
                self.mappingCreateOrder.route = self.dictrictFilter.model[self.dictrictFilter.indexSelected].route
                cell.districtMapping = self.dictrictFilter
                self.tableview.reloadData()
            }
            
            cell.updateNgayGiaoHang = { result in
                self.mappingCreateOrder.chonNgayGiaoHang = result
            }
            
            cell.updateRadioUI = { result in
                if let addresses = result {
                    self.mappingCreateOrder.addresses = addresses
                }
                self.tableview.reloadData()
            }
            
            cell.updateName = { result in
                self.mappingCreateOrder.name = result
            }
            
            // -- phone
            cell.updatePhoneNumber = { result in
                self.mappingCreateOrder.phone = result
            }
            
            cell.updateNameEndUser = { result in
                self.mappingCreateOrder.nameEndUser = result
            }
            
            cell.updatePhoneEndUserNumber = { result in
                self.mappingCreateOrder.phoneEndUser = result
            }
            
            cell.updateAddressEndUser = { result in
                self.mappingCreateOrder.addressEndUser = result
            }
            
            return cell
        }
        
        
    }
}


// set default phone value when first load
extension CreateOrderInfoController {
    
    private func displayPhoneNumber(model: CustomerDetailModel) -> String {
        
        if !model.sdt.isEmpty {
            return model.sdt
        }
        
        if !model.telNumber.isEmpty {
            return model.telNumber
        }
        
        if !model.faxNumber.isEmpty {
            return model.faxNumber
        }
        
        if !model.faxNumber.isEmpty {
            return model.faxNumber
        }
        
        
        return model.mobileNumber
    }
}
