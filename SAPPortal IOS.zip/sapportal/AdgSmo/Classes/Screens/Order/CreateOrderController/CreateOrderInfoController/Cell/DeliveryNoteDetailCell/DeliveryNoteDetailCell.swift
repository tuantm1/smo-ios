//
//  DeliveryNoteDetailCell.swift
//  SapPortal
//
//  Created by LuongTiem on 8/8/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import RadioGroup

class DeliveryNoteDetailCell: UITableViewCell {
    
    @IBOutlet weak var noteTitleLabel: UILabel!
    @IBOutlet weak var noteTextView: UITextView!
    @IBOutlet var radioGroup: RadioGroup!
    
    var updateRadioUI: ((String) -> Void)?
    
    var updateNote: ((String) -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        
        noteTextView.text = ""
        
        noteTextView.layer.cornerRadius = 8
        noteTextView.layer.masksToBounds = true
        noteTextView.layer.borderColor = UIColor.lightGray.cgColor
        noteTextView.layer.borderWidth = 0.5
        
        radioGroup.titles = ["Trong tiêu chuẩn", "Ngoài tiêu chuẩn"]
        radioGroup.addTarget(self, action: #selector(didSelectOption(radioGroup:)), for: .valueChanged)
        radioGroup.titleFont = UIFont.systemFont(ofSize: 16)
        
        noteTextView.delegate = self
    }
    
    
    func bindingData(model: GetDetailTempModel) {
        
        switch model.eFlag {
        case "":
            radioGroup.isHidden = true
        case "0":
            radioGroup.selectedIndex = 0
        default:
            radioGroup.selectedIndex = 1
        }
        
        self.updateRadioUI?("\(radioGroup.selectedIndex)")
        
        self.radioGroup.isUserInteractionEnabled = false
    }
    
}


extension DeliveryNoteDetailCell {
    
    @objc private
    func didSelectOption(radioGroup: RadioGroup) {
        
        self.updateRadioUI?("\(radioGroup.selectedIndex)")
    }
}


extension DeliveryNoteDetailCell: UITextViewDelegate {
    
    func textViewDidEndEditing(_ textView: UITextView) {
        self.updateNote?(self.noteTextView.text ?? "")
    }
}
