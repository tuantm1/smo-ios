//
//  DeliveryLiabilitiesInfoCell.swift
//  SapPortal
//
//  Created by LuongTiem on 8/5/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import RadioGroup




class DeliveryLiabilitiesInfoCell: UITableViewCell {
    
    @IBOutlet var borderEditView: [UIView]!
    
    @IBOutlet weak var ngayGiaoHangLabel: UILabel!
    @IBOutlet weak var ngayGiaoHangContentView: UIView!
    @IBOutlet weak var ngayGiaoHangContentLabel: UILabel!
    @IBOutlet weak var timeTextField: UITextField!
    
    @IBOutlet weak var ngayYeuCauGiaoHangLabel: UILabel!
    @IBOutlet weak var ngayYeuCauGiaoHangContentLabel: UILabel!
    @IBOutlet weak var ngayYeuCauGiaoHangButton: UIButton!
    
    @IBOutlet weak var ngayDuKienLabel: UILabel!
    @IBOutlet weak var ngayDuKienContentLabel: UILabel!
    
    @IBOutlet weak var daiLyLabel: UILabel!
    @IBOutlet weak var dailyContentLabel: UILabel!
    
    @IBOutlet weak var addressRadioLabel: UILabel!
    @IBOutlet var radioGroup: RadioGroup!
    
    @IBOutlet weak var addressesLabel: UILabel!
    @IBOutlet weak var editAddressTextField: UITextField!
    @IBOutlet weak var addressContentLabel: UILabel!
    @IBOutlet weak var addressDropDownImage: UIImageView!
    @IBOutlet weak var addressHitTestView: TouchHitTestView!
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var cityContentLabel: UILabel!
    @IBOutlet weak var citySelectedContentLabel: UILabel!
    @IBOutlet weak var cityHitTestView: TouchHitTestView!
    
    @IBOutlet weak var districtLabel: UILabel!
    @IBOutlet weak var districtContentLabel: UILabel!
    @IBOutlet weak var districtSelectedContentLabel: UILabel!
    @IBOutlet weak var districtHitTestView: TouchHitTestView!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var phoneTextField: UITextField!
    
    @IBOutlet weak var nameEndUserLabel: UILabel!
    @IBOutlet weak var nameEndUserTextField: UITextField!
    @IBOutlet weak var phoneEndUserLabel: UILabel!
    @IBOutlet weak var phoneEndUserTextField: UITextField!
    @IBOutlet weak var addressEndUserLabel: UILabel!
    @IBOutlet weak var addressEndUserTextField: UITextField!
    
    @IBOutlet weak var tongTienLabel: UILabel!
    @IBOutlet weak var tongTienContentLabel: UILabel!
    
    @IBOutlet weak var chietKhauLabel: UILabel!
    @IBOutlet weak var chietKhauContentLabel: UILabel!
    
    @IBOutlet weak var tienSauChietKhauLabel: UILabel!
    @IBOutlet weak var tienSauChietKhauContentLabel: UILabel!
    
    @IBOutlet weak var thueGTGTLabel: UILabel!
    @IBOutlet weak var thueGTGTContentLabel: UILabel!
    
    @IBOutlet weak var tienThanhToanLabel: UILabel!
    @IBOutlet weak var tienThanhToanContentLabel: UILabel!
    
//    @IBOutlet weak var congNoLabel: UILabel!
    @IBOutlet weak var congNoTitleLabel: UILabel!
    @IBOutlet weak var conNoContentLabel: UILabel!
    
//    @IBOutlet weak var hanMucLabel: UILabel!
    @IBOutlet weak var hanMucTitleLabel: UILabel!
    @IBOutlet weak var hanMucContentLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var statusContentLabel: UILabel!
    
    
    var isInputEnter: Bool = false {
        didSet {
            addressContentLabel.isHidden = isInputEnter
            editAddressTextField.isHidden = !isInputEnter
//            addressDropDownImage.isHidden = isInputEnter
        }
    }
    
    var cityMapping: CityMapping = CityMapping(indexSelected: 0, model: []) {
        didSet {
            if cityMapping.model.isEmpty { return }
            
            let city: String = self.cityMapping.model[self.cityMapping.indexSelected].bezei
            self.citySelectedContentLabel.text = city
        }
    }
    
    var districtMapping: DistrictMapping = DistrictMapping(indexSelected: 0, model: []) {
        didSet {
            if districtMapping.model.isEmpty { return }
            
            var district: String = ""
            
            if !self.districtMapping.model.isEmpty && self.districtMapping.model.count > self.districtMapping.indexSelected {
                district = self.districtMapping.model[self.districtMapping.indexSelected].bezei
            }
            self.districtSelectedContentLabel.text = district
        }
    }
    
    // -- update index
    var updateCityIndex: ((Int) -> Void)?
    
    var updateDistrictIndex: ((Int) -> Void)?
    
    var updateRadioUI: ((String?) -> Void)?
    
    var updateNgayGiaoHang: ((String) -> Void)?
    
    var updateName: ((String) -> Void)?
    
    var updatePhoneNumber: ((String) -> Void)?
    
    var updateNameEndUser: ((String) -> Void)?
    
    var updatePhoneEndUserNumber: ((String) -> Void)?
    
    var updateAddressEndUser: ((String) -> Void)?
    
    var division: String = ""
    
    var templaceDetailModel: GetDetailTempModel? = nil {
        didSet {
            guard let model = templaceDetailModel else { return }
            
            var increase: Int = 1
            if !model.items.isEmpty {
                increase = Int(model.items[0].zDKGH) ?? 1
            }
             
            let newDate = Date.updateNewDate(dateString: "dd/MM/yyyy", increase: increase)
            ngayDuKienContentLabel.text = newDate
            yeuCauGiaoHangDate = newDate
        }
    }
    
    var customerDetailModel: CustomerDetailModel? = nil {
        didSet {
            guard let model = customerDetailModel else { return }
            
            self.setupUI(model: model, division: division)
        }
    }
    
    var checkPrice: CheckPriceModel! {
        didSet {
            self.checkPriceUI(model: checkPrice)
        }
    }
    
    var routeModel: RouteModel!
    
    private var yeuCauGiaoHangDate: String = Date().convertString(formatter: "dd/MM/yyyy") {
        didSet {
            self.ngayYeuCauGiaoHangContentLabel.text = yeuCauGiaoHangDate
            self.updateNgayGiaoHang?(yeuCauGiaoHangDate)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
        isInputEnter = false
        
        ngayYeuCauGiaoHangButton.addTarget(self, action: #selector(chonNgayGiaoHang), for: .touchUpInside)
        
        borderEditView.forEach { (item) in
            item.layer.cornerRadius = 4
            item.layer.masksToBounds = true
            item.layer.borderColor = UIColor.lightGray.cgColor
            item.layer.borderWidth = 0.8
        }
        
        radioGroup.titles = ["Showroom Đại lý", "Địa chỉ khác"]
        radioGroup.addTarget(self, action: #selector(didSelectOption(radioGroup:)), for: .valueChanged)
        radioGroup.titleFont = UIFont.systemFont(ofSize: 16)
        
        radioGroup.selectedIndex = 0
        didSelectOption(radioGroup: radioGroup)
        
        addChooseAddressesCity()
        
    }

    
    @IBAction func editingAddressesAction(_ sender: Any) {
        
        self.updateRadioUI?(self.editAddressTextField.text ?? "")
    }
    
    
    private func addChooseAddressesCity() {
        
        addressHitTestView.didSelectedView = {
            
        }
        
        //--
        cityHitTestView.didSelectedView = {
            
            let vc: ItemListController = ItemListController(nibName: "ItemListController", bundle: nil)
            vc.listItem = self.cityMapping.model.map { $0.bezei }
            vc.indexSelected = self.cityMapping.indexSelected
            vc.updateSelectedIndex = { indexSelected in
                self.updateCityIndex?(indexSelected)
            }
            
            AlertHelperKit.showControllerEntryKit(controller: vc)
            
        }
        
        //---
        districtHitTestView.didSelectedView = {
            
            let vc: ItemListController = ItemListController(nibName: "ItemListController", bundle: nil)
            vc.listItem = self.districtMapping.model.map { $0.bezei }
            vc.indexSelected = self.districtMapping.indexSelected
            vc.updateSelectedIndex = { indexSelected in
                self.updateDistrictIndex?(indexSelected)
            }
            
            AlertHelperKit.showControllerEntryKit(controller: vc)
        }
    }
    
    @IBAction func nameEdittingAction(_ sender: Any) {
        let value = nameTextField.text ?? ""
        self.updateName?(value)
    }
    
    @IBAction func phoneEdittingAction(_ sender: Any) {
        let value = phoneTextField.text ?? ""
        self.updatePhoneNumber?(value)
    }
    
    @IBAction func nameEndUserEdittingAction(_ sender: Any) {
        let value = nameEndUserTextField.text ?? ""
        self.updateNameEndUser?(value)
    }
    
    @IBAction func phoneEndUserEdittingAction(_ sender: Any) {
        let value = phoneEndUserTextField.text ?? ""
        self.updatePhoneEndUserNumber?(value)
    }
    
    @IBAction func addressEndUserEdittingAction(_ sender: Any) {
        let value = addressEndUserTextField.text ?? ""
        self.updateAddressEndUser?(value)
    }
    
    private func setupUI(model: CustomerDetailModel, division: String) {
        ngayGiaoHangContentLabel.text = Date().convertString(formatter: "dd/MM/yyyy")
        timeTextField.text = Date().convertString(formatter: "HH:mm")
        
        ngayYeuCauGiaoHangContentLabel.text = yeuCauGiaoHangDate
        
        dailyContentLabel.text = model.customerName
        
        addressContentLabel.text = model.address
        
        phoneTextField.text = displayPhoneNumber(model: model)
        
//        congNoTitleLabel.text = setupLimitGuaranteeTitle(division: division, credits: model.creditModel)?.division ?? ""
        conNoContentLabel.text = setupLimitGuaranteeTitle(division: division, credits: model.creditModel)?.value1.convertToCurrency
        
//        hanMucTitleLabel.text = setupLimitGuaranteeTitle(division: division, credits: model.creditModel)?.division ?? ""
        hanMucContentLabel.text = setupLimitGuaranteeTitle(division: division, credits: model.creditModel)?.value.convertToCurrency
        
        if !routeModel.t173t.isEmpty && !routeModel.route.isEmpty && radioGroup.selectedIndex == 0 {
            
            let districtModel: DistrictModel? = routeModel.route.first { $0.route == model.route }
            
            let cityModel: CityModel? = routeModel.t173t.first { $0.vsart == districtModel?.vsart }
            
            self.districtContentLabel.text = districtModel.value?.bezei
            self.cityContentLabel.text = cityModel.value?.bezei
        }
        
    }
    
    
    private func setupLimitGuaranteeTitle(division: String, credits: [CreditModel]) -> CreditModel? {
        
        if let result = credits.first(where: { "CS\(division)" == $0.cs }) {
            
            return result
        }
        
        return nil
    }
    
    private func checkPriceUI(model: CheckPriceModel) {
        
        tongTienContentLabel.text = model.tgtdh.convertToCurrency
        
        chietKhauContentLabel.text = model.ck.convertToCurrency
        
        let chietKhau = (model.tgtdh - model.ck)
        tienSauChietKhauContentLabel.text = chietKhau.convertToCurrency
        
        thueGTGTContentLabel.text = model.tax.convertToCurrency
        
        tienThanhToanContentLabel.text = (chietKhau + model.tax).convertToCurrency
    }
    
    private func displayPhoneNumber(model: CustomerDetailModel) -> String {
        
        if !model.sdt.isEmpty {
            return model.sdt
        }
        
        if !model.telNumber.isEmpty {
            return model.telNumber
        }
        
        if !model.faxNumber.isEmpty {
            return model.faxNumber
        }
        
        if !model.faxNumber.isEmpty {
            return model.faxNumber
        }
        
        
        return model.mobileNumber
    }
}

extension DeliveryLiabilitiesInfoCell {
    
    @objc private
    func didSelectOption(radioGroup: RadioGroup) {
        
        isInputEnter = radioGroup.selectedIndex == 1
        
        addressHitTestView.isHidden = radioGroup.selectedIndex == 0
        
        cityHitTestView.isHidden = radioGroup.selectedIndex == 0
        cityHitTestView.isUserInteractionEnabled = radioGroup.selectedIndex == 1
        cityContentLabel.isHidden = radioGroup.selectedIndex == 1
        
        districtHitTestView.isHidden = radioGroup.selectedIndex == 0
        districtHitTestView.isUserInteractionEnabled = radioGroup.selectedIndex == 1
        districtContentLabel.isHidden = radioGroup.selectedIndex == 1
        
        self.updateRadioUI?(nil)
    }
    
    @objc private
    func chonNgayGiaoHang() {
        
        let calendarView: CalendarView = CalendarView.fromNib()
        calendarView.layer.cornerRadius = 8
        calendarView.layer.masksToBounds = true
        calendarView.layer.borderColor = UIColor.red.cgColor
        calendarView.layer.borderWidth = 0.5
        calendarView.isChooseBeforeDate = false
        
        calendarView.didSelectDate = { date in
            
            AlertHelperKit.dismiss()
            
            self.yeuCauGiaoHangDate = date.convertString(formatter: "dd/MM/yyyy")
        }
        
        AlertHelperKit.showSwiftEntryKit(customView: calendarView)
    }
}

extension DeliveryLiabilitiesInfoCell {
    
    private func resetAllValue() {
        
        cityContentLabel.text = ""
        citySelectedContentLabel.text = ""
        
        districtContentLabel.text = ""
        districtSelectedContentLabel.text = ""
        
        ngayGiaoHangContentLabel.text = ""
        
        ngayYeuCauGiaoHangContentLabel.text = ""
        
        ngayDuKienContentLabel.text = ""
        
        dailyContentLabel.text = ""
        
        addressContentLabel.text = ""
        
        tongTienContentLabel.text = ""
        
        chietKhauContentLabel.text = ""
        
        tienSauChietKhauContentLabel.text = ""
        
        thueGTGTContentLabel.text = ""
        
        tienThanhToanContentLabel.text = ""
        
//        congNoTitleLabel.text = ""
        conNoContentLabel.text = ""
        
//        hanMucTitleLabel.text = ""
        hanMucContentLabel.text = ""
    }
}
