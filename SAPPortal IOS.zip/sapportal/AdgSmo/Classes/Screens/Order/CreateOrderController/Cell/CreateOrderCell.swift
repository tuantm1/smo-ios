//
//  CreateOrderCell.swift
//  SapPortal
//
//  Created by LuongTiem on 7/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class CreateOrderCell: UITableViewCell {

    @IBOutlet weak var borderView: UIView!
    @IBOutlet weak var titleItemLabel: UILabel!
    @IBOutlet weak var contentItemLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
        
        borderView.layer.cornerRadius = 8
        borderView.layer.masksToBounds = true
        borderView.layer.borderWidth = 1
        borderView.layer.borderColor = UIColor.lightGray.cgColor
    }

    
    func bindingData(title: String, content: String) {
        titleItemLabel.text = title
        contentItemLabel.text = content
    }
    
    
}

extension CreateOrderCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    
    private func resetAllValue() {
        titleItemLabel.text = ""
        contentItemLabel.text = ""
    }
}
