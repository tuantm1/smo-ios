//
//  AddNewItemController.swift
//  SapPortal
//
//  Created by LuongTiem on 8/26/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class AddNewItemController: BaseViewController {
    
    @IBOutlet weak var tableview: UITableView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    var listItem: [ItemModelClient] = [] {
        didSet {
            filteredResults = listItem
        }
    }
    
    var didSelectedItem: ((ItemModelClient) -> Void)?
    
    private var filteredResults: [ItemModelClient] = [] {
        didSet {
            isSearching = true
        }
    }
    
    var isSearching: Bool = false {
        
        didSet {
            if tableview == nil { return }
            DispatchQueue.main.async {
                self.tableview.reloadData()
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        tableview.register(UINib(nibName: OrderInformationCell.className, bundle: nil), forCellReuseIdentifier: OrderInformationCell.className)
        tableview.delegate = self
        tableview.dataSource = self
        tableview.tableFooterView = UIView()
        tableview.rowHeight = UITableView.automaticDimension
        tableview.separatorStyle = .none
        tableview.estimatedRowHeight = 150
        
        searchBar.delegate = self
        searchBar.autocapitalizationType = .none
//        searchController.delegate = self
//        searchController.searchResultsUpdater = self
//        searchController.searchBar.autocapitalizationType = .none
//        searchController.dimsBackgroundDuringPresentation = false
//        searchController.searchBar.delegate = self // Monitor when the search button is tapped.
        
        definesPresentationContext = true
    }

}

extension AddNewItemController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? OrderInformationCell {
            filteredResults[indexPath.row].quantity = cell.amountContentLabel.text?.toDouble ?? 1
            didSelectedItem?(filteredResults[indexPath.row])
        } else {
            didSelectedItem?(filteredResults[indexPath.row])
        }
        
        AlertHelperKit.dismiss()
    }
    

    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
    }
}

extension AddNewItemController: UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredResults.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: OrderInformationCell.className, for: indexPath) as? OrderInformationCell else {
            return UITableViewCell()
        }
        
        cell.bindingData(model: filteredResults[indexPath.row], isAddNewItem: true)
        
        return cell
    }
}

// MARK: SEARCH

extension AddNewItemController {
    
    private func findMatches(searchString: String = "") -> NSCompoundPredicate {
        
        var searchItemsPredicate: [NSPredicate] = []
        
        let titleExpression: NSExpression = NSExpression(forKeyPath: "name")
        let searchStringExpression = NSExpression(forConstantValue: searchString)
        
        let titleSearchComparisonPredicate = NSComparisonPredicate(leftExpression: titleExpression,
                                                                   rightExpression: searchStringExpression,
                                                                   modifier: .direct,
                                                                   type: .contains,
                                                                   options: [.caseInsensitive, .diacriticInsensitive])
        
        searchItemsPredicate.append(titleSearchComparisonPredicate)
        
        
        var finalCompoundPredicate: NSCompoundPredicate!
        
        finalCompoundPredicate = NSCompoundPredicate(orPredicateWithSubpredicates: searchItemsPredicate)
        
        return finalCompoundPredicate
    }
    
}

extension AddNewItemController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        
        let searchResults = listItem
        
        let strippedString = (searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        
        let searchItems = strippedString.components(separatedBy: " ") as [String]
        
        // Build all the "AND" expressions for each value in searchString.
        let andMatchPredicates: [NSPredicate] = searchItems.map { searchString in
            findMatches(searchString: searchString)
        }
        
        let finalCompoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: andMatchPredicates)
        
        filteredResults = searchResults.filter { finalCompoundPredicate.evaluate(with: $0) }
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if ("" == searchBar.text) {
            filteredResults = listItem
        } else {
            let searchResults = listItem
            
            let strippedString = (searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            
            let searchItems = strippedString.components(separatedBy: " ") as [String]
            
            // Build all the "AND" expressions for each value in searchString.
            let andMatchPredicates: [NSPredicate] = searchItems.map { searchString in
                findMatches(searchString: searchString)
            }
            
            let finalCompoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: andMatchPredicates)
            
            filteredResults = searchResults.filter { finalCompoundPredicate.evaluate(with: $0) }
        }
    }
}
