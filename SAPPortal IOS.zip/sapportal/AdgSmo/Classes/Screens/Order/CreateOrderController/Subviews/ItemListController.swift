//
//  ItemListController.swift
//  SapPortal
//
//  Created by LuongTiem on 7/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ItemListController: UIViewController {
    
    @IBOutlet weak var tableview: UITableView!
    
    var listItem: [String] = []
    
    var indexSelected: Int = 0 {
        didSet {
            updateSelectedIndex?(indexSelected)
        }
    }
    
    var updateSelectedIndex: ((Int) -> Void)?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableview.register(ItemListCell.nib, forCellReuseIdentifier: ItemListCell.className)
        tableview.delegate = self
        tableview.dataSource = self
        tableview.tableFooterView = UIView()
    }
    
}


extension ItemListController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        indexSelected = indexPath.row
        tableView.reloadData()
        
        AlertHelperKit.dismiss()
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.isSelected = indexPath.row == indexSelected
    }
}

extension ItemListController: UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listItem.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ItemListCell.className, for: indexPath) as? ItemListCell else {
            return UITableViewCell()
        }
        
        cell.bindingData(item: listItem[indexPath.row])
        
        return cell
    }
}
