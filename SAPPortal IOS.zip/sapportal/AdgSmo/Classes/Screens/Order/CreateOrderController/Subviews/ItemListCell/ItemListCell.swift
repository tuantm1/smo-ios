//
//  ItemListCell.swift
//  SapPortal
//
//  Created by LuongTiem on 7/29/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ItemListCell: UITableViewCell {
    
    @IBOutlet weak var itemContentLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        itemContentLabel.text = ""
    }
    
    
    func bindingData(item: String) {
        
        itemContentLabel.text = item
    }
    
    
    override var isSelected: Bool {
        didSet {
            self.accessoryType = isSelected ? .checkmark : .none
        }
    }
}

extension ItemListCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        itemContentLabel.text = ""
    }
}
