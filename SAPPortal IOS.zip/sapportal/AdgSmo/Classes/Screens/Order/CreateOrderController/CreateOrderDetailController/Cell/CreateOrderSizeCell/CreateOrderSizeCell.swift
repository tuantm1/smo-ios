//
//  CreateOrderSizeCell.swift
//  SapPortal
//
//  Created by LuongTiem on 8/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class CreateOrderSizeCell: UITableViewCell {
    
    @IBOutlet weak var titleFirstLabel: UILabel!
    @IBOutlet weak var contentFirstTextField: UITextField!
    @IBOutlet weak var borderFirstView: UIView!
    
    @IBOutlet weak var titleSecondLabel: UILabel!
    @IBOutlet weak var contentSecondTextField: UITextField!
    @IBOutlet weak var borderSecondView: UIView!
    
    @IBOutlet weak var titleSizeLabel: UILabel!
    @IBOutlet weak var contentSizeLabel: UILabel!
    @IBOutlet weak var borderSizeView: UIView!
    
    var updateValue: ((_ first: Double,_ second: Double, _ size: Double) -> Void)?
    
    private var sizeItem: Double = 0 {
        didSet {
            
            self.updateValue?(valueFirst, valueSecond, sizeItem)
            self.contentSizeLabel.text = sizeItem == 0 ? "" : sizeItem.toString
        }
    }
    
    private var valueFirst: Double = 0 {
        didSet {
            self.sizeItem = (valueFirst * valueSecond)/1000000
        }
    }
    
    private var valueSecond: Double = 0 {
        didSet {
             self.sizeItem = (valueFirst * valueSecond)/1000000
        }
    }
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        setupBorderView()
        resetAllValue()
    }

   
    private func setupBorderView() {
        borderFirstView.layer.cornerRadius = 4
        borderFirstView.layer.masksToBounds = true
        borderFirstView.layer.borderColor = UIColor.lightGray.cgColor
        borderFirstView.layer.borderWidth = 0.8
        
        borderSecondView.layer.cornerRadius = 4
        borderSecondView.layer.masksToBounds = true
        borderSecondView.layer.borderColor = UIColor.lightGray.cgColor
        borderSecondView.layer.borderWidth = 0.8
        
        borderSizeView.layer.cornerRadius = 4
        borderSizeView.layer.masksToBounds = true
        borderSizeView.layer.borderColor = UIColor.lightGray.cgColor
        borderSizeView.layer.borderWidth = 0.8
    }
    
    
    func bindingData(titleFirst: String, contentFirst: String, titleSecond: String, contentSecond: String, titleSize: String) {
        
        self.titleFirstLabel.text = titleFirst + " (mm)"
        self.titleSecondLabel.text = titleSecond + " (mm)"
        self.titleSizeLabel.text = titleSize + " (m2)"
        
        self.contentFirstTextField.text = contentFirst.toDouble == 0 ? "" : contentFirst
        self.contentSecondTextField.text = contentSecond.toDouble == 0 ? "" : contentSecond
        
        valueFirst = contentFirst.toDouble
        
        valueSecond = contentSecond.toDouble
    }
    
    
    @IBAction private func editingChangeFirstAction(_ sender: Any) {
        let result: Double = (self.contentFirstTextField.text ?? "").toDouble
        
        self.valueFirst = result
        
    }
   
    @IBAction private func editingChangeSecondAction(_ sender: Any) {
        let result: Double = (self.contentSecondTextField.text ?? "").toDouble
        
        self.valueSecond = result
    }
    
}

extension CreateOrderSizeCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
//        resetAllValue()
    }
    
    private func resetAllValue() {
        titleFirstLabel.text = ""
        contentFirstTextField.text = ""
        
        titleSecondLabel.text = ""
        contentSecondTextField.text = ""
        
        titleSizeLabel.text = ""
        contentSizeLabel.text = ""
    }
}
