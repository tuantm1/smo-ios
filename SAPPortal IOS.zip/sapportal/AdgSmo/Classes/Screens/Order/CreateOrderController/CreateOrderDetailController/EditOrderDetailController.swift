//
//  EditOrderDetailController.swift
//  SapPortal
//
//  Created by AnhVT on 20/10/20.
//  Copyright © 2020 AnhVT. All rights reserved.
//

import UIKit

class EditOrderDetailController: UIViewController {

    @IBOutlet weak var tableview: UITableView!

    var templateItemModelClient: ItemModelClient!
    
    private var constantMATNR: String = ""
    
    private var mappingBoToi: [GetMappingBoToiModel] = []
    
    private var mappingThanhRay: [GetMappingThanhRayModel] = []
    
    private var listIDGroupSection: [String] = [] // -- verify group ID
    
    private var listData: [CreateOrderDetailSectionHeader] = []
    
    private var templateMergeFilterModel: ItemModelClient? = nil
    
    private var checkDuplicateModelBoCua: [String] = [] // verfiy model bo cua
    
    private var listFilerModelBoCua: [GetMatReferModel] = []
    
    private var listModelBoCua: [GetMatReferModel] = [] {
        didSet {
            
            listFilerModelBoCua = [] // reset
            
            listModelBoCua.forEach { (model) in
                
                if !checkDuplicateModelBoCua.contains(model.value) {
                    checkDuplicateModelBoCua.append(model.value)
                    self.listFilerModelBoCua.append(model)
                }
            }
            
        }
    }
    
    private var listModelMauSac: [GetMatReferModel] = []
    
    private var listGetMatRefer: [GetMatReferModel] = [] {
        didSet {
            self.listModelBoCua = listGetMatRefer.filter { $0.zmbez == "Z_MODEL_CUA" }
//            self.listModelMauSac = listGetMatRefer.filter { $0.zmbez == "Z_MAU_SAC" }
        }
    }
    
    private var listAllCharacteristics: [GetCharacteristicModel] = []
    
    private var characteristicBoToi: MappingCharacteristic = MappingCharacteristic()
    
    private var characteristicThanhRay: MappingCharacteristic = MappingCharacteristic()
    
    private var mixFilterCharacteristic: [CharacteristicModel] = []
    
    var didSendData: ((ItemModelClient) -> Void)?
    
    lazy var titleView: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 13)
        label.numberOfLines = 2
        label.textAlignment = .center
        label.sizeToFit()
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        constantMATNR = templateItemModelClient.matnr
        
        titleView.text = templateItemModelClient.name.isEmpty ? "Thông tin đặt hàng" : templateItemModelClient.name
        
        navigationItem.titleView = titleView
        
        tableview.register(CreateOrderDetailCell.nib, forCellReuseIdentifier: CreateOrderDetailCell.className)
        tableview.register(HeaderTitleView.nib, forHeaderFooterViewReuseIdentifier: HeaderTitleView.className)
        tableview.register(CreateOrderSizeCell.nib, forCellReuseIdentifier: CreateOrderSizeCell.className)
        tableview.tableFooterView = UIView()
        tableview.keyboardDismissMode = .onDrag
        requestAPI()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.templateItemModelClient.matnr = constantMATNR
        self.templateMergeFilterModel?.matnr = constantMATNR
    }
    
    @IBAction func nextAction(_ sender: Any) {
        
        if let template = self.templateMergeFilterModel {
            mixFilterCharacteristic = self.listData.flatMap { (model) -> [CharacteristicModel] in
                return model.listCharacteristics
            }
            
            template.characteristics = mixFilterCharacteristic
            template.type = "O"
            
            didSendData?(template)
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        guard let mergeModel = sender as? GetDetailTempModel, !mergeModel.items.isEmpty else { return }
        
        switch segue.identifier {
        case SegueIdentifier.MenuOrder.pushCreateOrderInfoController:
            if let vc = segue.destination as? CreateOrderInfoController {
                vc.passDataModel = mergeModel
            }
        default:
            break
        }
    }
    
    private func requestAPI() {
        
        let group = DispatchGroup()
        
        APIUIIndicator.showIndicator()
        
        self.templateMergeFilterModel = self.templateItemModelClient
        
            
        // -- loop characteristics
        templateItemModelClient.characteristics.forEach { (characterItem) in
            
            // -- check
            if !self.listIDGroupSection.contains(characterItem.group) {
                
                if let item = AppDataShare.shared.createOrderGroup.first(where: { $0.groupID == characterItem.group }) {
                    
                    var copyTemp = item // copy model
                    let copyListCharacteristics = templateItemModelClient.characteristics.filter { $0.group == characterItem.group }
                    let sort = copyListCharacteristics.sorted { (model1, model2) -> Bool in
                        return model1.sort < model2.sort
                    }
                    
                    copyTemp.listCharacteristics = sort
                    
                    self.listIDGroupSection.append(characterItem.group)
                    self.listData.append(copyTemp)
                    
                }
                
            }
        }
        
        group.enter()
        GetCharacteristicAPI.init(matnr: templateItemModelClient.matnr).showIndicator(false).execute(target: self, success: { (response) in
            
            self.listAllCharacteristics = response.model
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        /// --  Api 4
        group.enter()
        GetMatReferAPI.init(matnr: templateItemModelClient.matnr).showIndicator(false).execute(target: self, success: { (response) in
            self.listGetMatRefer = response.model
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        
        /// -- Api 2
        group.enter()
        GetMappingBoToiAPI.init(idItem: templateItemModelClient.matnr).showIndicator(false).execute(target: self, success: { (response) in
            self.mappingBoToi = response.model
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        /// -- Api 3
        group.enter()
        GetMappingThanhRayAPI.init().showIndicator(false).execute(target: self, success: { (response) in
            self.mappingThanhRay = response.model
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        group.notify(queue: DispatchQueue.main) {
            
            self.listData.enumerated().forEach { element in
                
                self.listData[element.offset].listCharacteristics.enumerated().forEach { (characteristicsModel) in
                    
                    if characteristicsModel.element.atnam == AppDataShare.CreateOrderKey.modelCua.atnam {
                        self.listData[element.offset].listCharacteristics[characteristicsModel.offset].filterMatReferModel = self.listFilerModelBoCua
                        if !self.listFilerModelBoCua.isEmpty {
                            self.listData[element.offset].listCharacteristics[characteristicsModel.offset].value = self.listFilerModelBoCua[0].value
                        }
                        
                        return
                    }
                    
                    let filter = self.listAllCharacteristics.filter { $0.atnam == characteristicsModel.element.atnam }
                    
                    let mappingModel = filter.map { $0.value2 }
                    
                    var result: [GetCharacteristicValue2Model] = []
                    
                    result = mappingModel.isEmpty ? [] : mappingModel[0]
                    
                    if characteristicsModel.element.atnam == AppDataShare.CreateOrderKey.botoi.atnam {
                        let filterBT = self.mappingBoToi.map({ $0.value })
                        result = result.filter({ characteristic in
                            filterBT.contains(characteristic.valDescr)
                        })
                    }
                    
                    result.insert(GetCharacteristicValue2Model(), at: 0)
                    
                    self.listData[element.offset].listCharacteristics[characteristicsModel.offset].filterValue = result
                    
                    if !result.isEmpty {
//                        self.listData[element.offset].listCharacteristics[characteristicsModel.offset].value = mappingModel[0][0].valDescr
                    }
                }
            }
            
            if let indexBoToi = self.listData.firstIndex(where: { $0.groupID == AppDataShare.CreateOrderKey.chonbotoi.group }) {
                
                let filter: [GetMappingBoToiModel] = self.mappingBoToi.filter { $0.value == self.listData[indexBoToi].listCharacteristics[0].value }
                
                var fakeModel = CharacteristicModel(atnam: AppDataShare.CreateOrderKey.chonbotoi.atnam,
                                                    smbez: AppDataShare.CreateOrderKey.chonbotoi.smbez,
                                                    group: AppDataShare.CreateOrderKey.chonbotoi.group,
                                                    mappingBoToi: filter)
                
                if !filter.isEmpty {
                    fakeModel.value = filter[fakeModel.selectedIndex].matnr
                }
                
                self.listData[indexBoToi].listCharacteristics.append(fakeModel)
            }
            
            if let indexThanhRay = self.listData.firstIndex(where: { $0.groupID == AppDataShare.CreateOrderKey.chonthanhray.group }) {
                
                let filter: [GetMappingThanhRayModel] = self.mappingThanhRay.filter { $0.value == self.listData[indexThanhRay].listCharacteristics[0].value }
                
                var fakeModel = CharacteristicModel(atnam: AppDataShare.CreateOrderKey.chonthanhray.atnam,
                                                    smbez: AppDataShare.CreateOrderKey.chonthanhray.smbez,
                                                    group: AppDataShare.CreateOrderKey.chonthanhray.group,
                                                    mappingThanhRay: filter)
                if !filter.isEmpty {
                    fakeModel.value = filter[fakeModel.selectedIndex].descriptions
                }
                
                self.listData[indexThanhRay].listCharacteristics.append(fakeModel)
            }
            
            APIUIIndicator.hideIndicator()
            self.tableview.reloadData()
        }
    }
    


}

extension EditOrderDetailController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.view.endEditing(true)
        let groupSection = listData[indexPath.section]
        let vc: ItemListController = ItemListController(nibName: "ItemListController", bundle: nil)
        
        // Selected Cell
        let item = groupSection.listCharacteristics[indexPath.row]
        
        switch item.atnam {
        case AppDataShare.CreateOrderKey.chonbotoi.atnam:
            vc.listItem = item.filterBoToi.map { $0.maktx }
            vc.indexSelected = item.selectedIndex
        case AppDataShare.CreateOrderKey.chonthanhray.atnam:
            vc.listItem = item.filterThanhRay.map { $0.descriptions }
            vc.indexSelected = item.selectedIndex
        case AppDataShare.CreateOrderKey.modelCua.atnam:
            vc.listItem = item.filterMatReferModel.map { $0.value }
            vc.indexSelected = item.selectedIndex
        default:
            vc.listItem = item.filterValue.map { $0.valDescr }
            vc.indexSelected = item.selectedIndex
        }
        
        
        switch groupSection.groupID {
        case "01":
            vc.updateSelectedIndex = { indexSelected in
                
                
                switch groupSection.listCharacteristics[indexPath.row].atnam {
                case AppDataShare.CreateOrderKey.modelCua.atnam:
                    self.listData[indexPath.section].listCharacteristics[indexPath.row].selectedIndex = indexSelected
                    let value = self.listData[indexPath.section].listCharacteristics[indexPath.row].filterMatReferModel[indexSelected].value
                    self.listData[indexPath.section].listCharacteristics[indexPath.row].value = value
                    
                default:
                    self.listData[indexPath.section].listCharacteristics[indexPath.row].selectedIndex = indexSelected
                    if !self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue.isEmpty {
                        self.listData[indexPath.section].listCharacteristics[indexPath.row].value = self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue[indexSelected].valDescr
                    }
                }
                
                self.tableview.reloadData()
            }
        case "02":
            return
        case "07":
            vc.updateSelectedIndex = { indexSelected in
                
                switch groupSection.listCharacteristics[indexPath.row].atnam {
                case AppDataShare.CreateOrderKey.botoi.atnam:
                    self.listData[indexPath.section].listCharacteristics[indexPath.row].selectedIndex = indexSelected
                    if let indexBoToi = self.listData[indexPath.section].listCharacteristics.firstIndex(where: { $0.atnam == AppDataShare.CreateOrderKey.chonbotoi.atnam }) {
                        
                        if !self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue.isEmpty {
                            
                            let value = self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue[indexSelected].value
                            self.listData[indexPath.section].listCharacteristics[indexPath.row].value = value
                            
                            self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue[indexSelected].value = value
                            
                            let filter: [GetMappingBoToiModel] = self.mappingBoToi.filter { $0.value == value }
                            
                            self.listData[indexPath.section].listCharacteristics[indexBoToi].filterBoToi = filter
                            ///- check if don't choose new item then return
                            self.listData[indexPath.section].listCharacteristics[indexBoToi].selectedIndex = 0 // always choose item 0 when update filter
                            
                            /// set value of item
                            if !self.listData[indexPath.section].listCharacteristics[indexBoToi].filterBoToi.isEmpty {
                                let index = self.listData[indexPath.section].listCharacteristics[indexBoToi].selectedIndex
                                self.listData[indexPath.section].listCharacteristics[indexBoToi].value = self.listData[indexPath.section].listCharacteristics[indexBoToi].filterBoToi[index].value
                            }
                        }
                    }
                case AppDataShare.CreateOrderKey.chonbotoi.atnam:
                    self.listData[indexPath.section].listCharacteristics[indexPath.row].selectedIndex = indexSelected
                    let index = self.listData[indexPath.section].listCharacteristics[indexPath.row].selectedIndex
                    self.listData[indexPath.section].listCharacteristics[indexPath.row].value = self.listData[indexPath.section].listCharacteristics[indexPath.row].filterBoToi[index].maktx
                default:
                    if self.listData[indexPath.section].listCharacteristics.count - 1 < indexPath.row ||
                        self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue.isEmpty {
                        break
                    }
                    self.listData[indexPath.section].listCharacteristics[indexPath.row].selectedIndex = indexSelected
                    let index = self.listData[indexPath.section].listCharacteristics[indexPath.row].selectedIndex
                    self.listData[indexPath.section].listCharacteristics[indexPath.row].value = self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue[index].valDescr
                }
                
                self.tableview.reloadData()
            }
        case "08":
            vc.updateSelectedIndex = { indexSelected in
                
                if AppDataShare.CreateOrderKey.checkListThanhRay(atnam: groupSection.listCharacteristics[indexPath.row].atnam) {
                    self.listData[indexPath.section].listCharacteristics[indexPath.row].selectedIndex = indexSelected
                    if let indexThanhRay = self.listData[indexPath.section].listCharacteristics.firstIndex(where: { $0.atnam == AppDataShare.CreateOrderKey.chonthanhray.atnam }) {
                        
                        if !self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue.isEmpty {
                            
                            let value = self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue[indexSelected].value
                            
                            self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue[indexSelected].value = value
                            
                            let filter: [GetMappingThanhRayModel] = self.mappingThanhRay.filter { $0.value == value }
                            
                            self.listData[indexPath.section].listCharacteristics[indexThanhRay].filterThanhRay = filter
                            
                            ///- check if don't choose new item then return
                            self.listData[indexPath.section].listCharacteristics[indexThanhRay].selectedIndex = 0 // always choose item 0 when update filter
                            
                            /// set value of item
                            if !self.listData[indexPath.section].listCharacteristics[indexThanhRay].filterThanhRay.isEmpty {
                                let index = self.listData[indexPath.section].listCharacteristics[indexThanhRay].selectedIndex
                                self.listData[indexPath.section].listCharacteristics[indexThanhRay].value = self.listData[indexPath.section].listCharacteristics[indexThanhRay].filterThanhRay[index].descriptions
                            }
                        }
                    }
                }
                
                
                if groupSection.listCharacteristics[indexPath.row].atnam == AppDataShare.CreateOrderKey.chonthanhray.atnam {
                    self.listData[indexPath.section].listCharacteristics[indexPath.row].selectedIndex = indexSelected
                    let index = self.listData[indexPath.section].listCharacteristics[indexPath.row].selectedIndex
                    if !self.listData[indexPath.section].listCharacteristics[indexPath.row].filterThanhRay.isEmpty {
                        self.listData[indexPath.section].listCharacteristics[indexPath.row].value = self.listData[indexPath.section].listCharacteristics[indexPath.row].filterThanhRay[index].matnrRefer
                    }
                }
                
                self.tableview.reloadData()
            }
        default:
            vc.updateSelectedIndex = { indexSelected in
                
                self.listData[indexPath.section].listCharacteristics[indexPath.row].selectedIndex = indexSelected
                
                // set value of characteric if filter not empty
                if !self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue.isEmpty {
                    self.listData[indexPath.section].listCharacteristics[indexPath.row].value = self.listData[indexPath.section].listCharacteristics[indexPath.row].filterValue[indexSelected].valDescr
                }
                
                self.tableview.reloadData()
            }
        }
        
        if vc.listItem.count < 2 {
            self.tableview.reloadData()
            return
        }
        
        
        AlertHelperKit.showControllerEntryKit(controller: vc)
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        let groupSection = listData[indexPath.section]
        
        switch groupSection.groupID {
        case "02":
            return 180
        default:
            return 60
        }
        
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        guard let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: HeaderTitleView.className) as? HeaderTitleView else {
            return nil
        }
        
        headerView.bindingData(title: listData[section].title, background: #colorLiteral(red: 0, green: 0.3568627451, blue: 0.5882352941, alpha: 1), titleColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
        
        return headerView
    }
        
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44
    }
}

extension EditOrderDetailController: UITableViewDataSource {
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return listData.count
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        let groupSection = listData[section]
        switch groupSection.groupID {
        case "02":
            return 1
        default:
            return listData[section].listCharacteristics.count
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let groupSection = listData[indexPath.section]
        
        switch groupSection.groupID {
        case "02":
            guard let cell = tableView.dequeueReusableCell(withIdentifier: CreateOrderSizeCell.className) as? CreateOrderSizeCell else {
                return UITableViewCell()
            }
            
            let model = groupSection.listCharacteristics
            
            // -- check value array
            if model.count != 3 {
                return cell
            }
            
            cell.updateValue = { first, second, size in
                
                self.listData[indexPath.section].listCharacteristics[0].value = first.toString
                self.listData[indexPath.section].listCharacteristics[1].value = second.toString
                self.listData[indexPath.section].listCharacteristics[2].value = "\(size)"
                
                self.templateMergeFilterModel?.height = self.listData[indexPath.section].listCharacteristics[0].value.toDouble
                self.templateMergeFilterModel?.width = self.listData[indexPath.section].listCharacteristics[1].value.toDouble
                self.templateMergeFilterModel?.quantity = Double(self.listData[indexPath.section].listCharacteristics[2].value) ?? 0
            }
            
            cell.bindingData(titleFirst: model[0].smbez,
                             contentFirst: model[0].value,
                             titleSecond: model[1].smbez,
                             contentSecond: model[1].value,
                             titleSize: model[2].smbez)
            
            return cell
        default:
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: CreateOrderDetailCell.className, for: indexPath) as? CreateOrderDetailCell else {
                return UITableViewCell()
            }
            
            cell.updateValueTextField = { result in
                self.listData[indexPath.section].listCharacteristics[indexPath.row].value = result
                
            }
            let model = groupSection.listCharacteristics[indexPath.row]
            
            
            switch model.atnam {
            case AppDataShare.CreateOrderKey.chonbotoi.atnam:
                
                let content = model.filterBoToi.isEmpty ? "" : model.filterBoToi[model.selectedIndex].maktx
                cell.bindingData(title: model.smbez, content: content)
                cell.isInputEnter = false
                
            case AppDataShare.CreateOrderKey.chonthanhray.atnam:
                
                let content = model.filterThanhRay.isEmpty ? "": model.filterThanhRay[model.selectedIndex].descriptions
                cell.bindingData(title: model.smbez, content: content)
                cell.isInputEnter = false
            case AppDataShare.CreateOrderKey.modelCua.atnam: 
                let content = model.filterMatReferModel.isEmpty ? "": model.filterMatReferModel[model.selectedIndex].value
                cell.bindingData(title: model.smbez, content: content)
                cell.isInputEnter = false
            default:
                let content = model.filterValue.count < 2 ? model.value : model.filterValue[model.selectedIndex].valDescr
                cell.bindingData(title: model.smbez, content: content)
                cell.isInputEnter = model.filterValue.count < 2
            }
            
            return cell
        }
        
    }
}
