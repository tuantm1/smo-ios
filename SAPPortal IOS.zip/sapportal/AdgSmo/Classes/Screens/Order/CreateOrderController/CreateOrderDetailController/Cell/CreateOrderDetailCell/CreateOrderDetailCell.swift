//
//  CreateOrderDetailCell.swift
//  SapPortal
//
//  Created by LuongTiem on 8/1/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class CreateOrderDetailCell: UITableViewCell {
    
    @IBOutlet weak var itemTitleLabel: UILabel!
    @IBOutlet weak var itemContentLabel: UILabel!
    @IBOutlet weak var contentTextField: UITextField!
    @IBOutlet weak var borderView: UIView!
    @IBOutlet weak var dropDownImage: UIImageView!
    
    var isInputEnter: Bool = false {
        didSet {
            itemContentLabel.isHidden = isInputEnter
            contentTextField.isHidden = !isInputEnter
            dropDownImage.isHidden = isInputEnter
        }
    }
    
    var updateValueTextField: ((String) -> Void)?

    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
        isInputEnter = false
        
        borderView.layer.cornerRadius = 4
        borderView.layer.masksToBounds = true
        borderView.layer.borderColor = UIColor.lightGray.cgColor
        borderView.layer.borderWidth = 0.8
    }
    
    @IBAction func editingChangeAction(_ sender: Any) {
        
        let result = contentTextField.text ?? ""
        
        updateValueTextField?(result)
    }
    
    func bindingData(title: String, content: String) {
        itemTitleLabel.text = title.replacingOccurrences(of: "Model", with: "Loại")
        itemContentLabel.text = content
        contentTextField.text = content
    }

}

extension CreateOrderDetailCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    
    private func resetAllValue() {
        itemTitleLabel.text = ""
        itemContentLabel.text = ""
        contentTextField.text = ""
    }
}
