//
//  CreateOrderController.swift
//  SapPortal
//
//  Created by LuongTiem on 7/27/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import SwiftEntryKit

class CreateOrderModel {
    
    var saleORG: [SaleORGModel] = []
    
    var dc: [DCModel] = []
    
    var division: [DivisionModel] = []
    
    var template: [GetTempModel] = []
    
    init() {}
}

struct GeneralCreateModel {
    
    var id: Int
    
    var title: String
    
    var listItem: [String]
    
    var selectedIndex: Int
}

class CreateOrderController: UIViewController {
    
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var orderButton: RoundButton!
    
    private var model: CreateOrderModel = CreateOrderModel()
    
    private var data: [GeneralCreateModel] = []
    
    private var templateSelected: GetTempModel? = nil
    
    private var filterTemplate: [GetTempModel] = []
    
    var menuModel: MenuModel!
    
    let zTypeList: [String] = ["", "PKADC", "PKDTC", "PKNL", "CCBH"]
    var zType: String = ""
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = menuModel.description.uppercased()
        tableview.register(CreateOrderCell.nib, forCellReuseIdentifier: CreateOrderCell.className)
        tableview.estimatedRowHeight = 80
        tableview.rowHeight = UITableView.automaticDimension
        tableview.tableFooterView = UIView()
        tableview.bounces = false
        
        requestAPI()
    }
    


    @IBAction func orderAction(_ sender: Any) {
        
        guard let result = self.templateSelected else {
            AlertHelperKit.showDefaultAlert(message: "Vui lòng chọn đơn đặt hàng mẫu")
            return
        }
        
        GetDetailTempAPI.init(idTemp: result.idTemplate).execute(target: self, success: { (response) in
            
            if !response.model.items.isEmpty, response.model.items[0].characteristics.isEmpty {
                self.performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushCreateOrderInfoController, sender: response.model)
            } else {
                self.performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushCreateOrderDetailController, sender: response.model)
            }
            
        }) { (error) in
            AlertHelperKit.showDefaultAlert(message: "Lỗi sever, vui lòng thử lại sau")
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    
    private func requestAPI() {
        
        let group = DispatchGroup()
        
        // api 1
        group.enter()
        SaleORGAPI.init(kunnr: AppDataShare.shared.userDetail.user.kunnr).execute(target: self, success: { (response) in
            self.model.saleORG = response.listSaleORG
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        
        // api 2
        group.enter()
        GetDCAPI.init(kunnr: AppDataShare.shared.userDetail.user.kunnr).execute(target: self, success: { (response) in
            self.model.dc = response.dcModel
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        
        // api 3
        group.enter()
        GetDivisionAPI.init().execute(target: self, success: { (response) in
            self.model.division = response.divisions
            group.leave()
        }) { (error) in
            
            group.leave()
        }
        
        
        // api 4
        group.enter()
        GetTempAPI.init(idUser: AppDataShare.shared.userDetail.user.userID).execute(target: self, success: { (response) in
            self.model.template = response.listTemplate
            group.leave()
        }) { (error) in
            group.leave()
        }
        
        
        group.notify(queue: DispatchQueue.main) {
            self.data = self.convertModelData(model: self.model)
            self.tableview.reloadData()
        }
        
    }

    
    private func convertModelData(model: CreateOrderModel) -> [GeneralCreateModel] {
        
        var result: [GeneralCreateModel] = []
        
        let saleORG = GeneralCreateModel(id: 0,
                                         title: "Đơn vị bán hàng",
                                         listItem: model.saleORG.map { $0.vtext },
                                         selectedIndex: 0)
        result.append(saleORG)
        
        let dc = GeneralCreateModel(id: 1,
                                         title: "Kênh bán hàng",
                                         listItem: model.dc.map { $0.vtext },
                                         selectedIndex: 0)
        result.append(dc)
        
        let division = GeneralCreateModel(id: 2,
                                         title: "Ngành hàng",
                                         listItem: model.division.map { $0.vtext },
                                         selectedIndex: 0)
        result.append(division)
        
        let template = GeneralCreateModel(id: 3,
                                         title: "Đơn đặt hàng mẫu",
                                         listItem: [],
                                         selectedIndex: 0)
        result.append(template)
        
        let action = GeneralCreateModel(id: 4,
                                         title: "Thao tác đặt hàng cửa cuốn",
                                         listItem: ["", "Phụ kiện AD", "Phụ kiện DT", "Phụ kiện nan lẻ và thanh đáy", "Công cụ bán hàng"],
                                         selectedIndex: 0)
        result.append(action);
        
        return result
    }
}

extension CreateOrderController: UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc: ItemListController = ItemListController(nibName: "ItemListController", bundle: nil)
        
        let item = data[indexPath.row]
        vc.listItem = item.listItem
        vc.indexSelected = item.selectedIndex
        
        
        vc.updateSelectedIndex = { index in
            self.data[indexPath.row].selectedIndex = index
            
            if item.id == 0 {
                self.filterTemplate = self.model.template.filter { $0.division == self.model.division[self.data[2].selectedIndex].spart }
                if self.model.saleORG[self.data[0].selectedIndex].vkorg == "1000" {
                    self.filterTemplate = self.filterTemplate.filter {$0.orderType == "ZI01"}
                } else if self.model.saleORG[self.data[0].selectedIndex].vkorg == "3000" {
                    self.filterTemplate = self.filterTemplate.filter {$0.orderType == "ZI11"}
                }
                self.data[3].listItem = self.filterTemplate.map { $0.name }
                self.data[3].selectedIndex = 0
            }
            
            if item.id == 2 {
                self.filterTemplate = self.model.template.filter { $0.division == self.model.division[self.data[indexPath.row].selectedIndex].spart }
                if self.model.saleORG[self.data[0].selectedIndex].vkorg == "1000" {
                    self.filterTemplate = self.filterTemplate.filter {$0.orderType == "ZI01"}
                } else if self.model.saleORG[self.data[0].selectedIndex].vkorg == "3000" {
                    self.filterTemplate = self.filterTemplate.filter {$0.orderType == "ZI11"}
                }
                self.data[3].listItem = self.filterTemplate.map { $0.name }
                self.data[3].selectedIndex = 0
            }
            
            // check value temple exist set value choose
            if !self.filterTemplate.isEmpty {
                self.templateSelected = self.filterTemplate[self.data[3].selectedIndex]
            } else {
                self.templateSelected = nil
            }
            
            if item.id == 4 {
                self.zType = self.zTypeList[self.data[indexPath.row].selectedIndex]
            }
            
            self.tableview.reloadData()
        }
        
        
        
        if vc.listItem.isEmpty {
            self.tableview.reloadData()
            return
        }
        
        AlertHelperKit.showControllerEntryKit(controller: vc)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case SegueIdentifier.MenuOrder.pushCreateOrderDetailController:
            if let model = sender as? GetDetailTempModel, let vc = segue.destination as? CreateOrderDetailController {
                vc.templateDetailModel = model
                vc.zType = self.zType;
                print("xxx: " + self.zType)
            }
        case SegueIdentifier.MenuOrder.pushCreateOrderInfoController:
            if let model = sender as? GetDetailTempModel, let vc = segue.destination as? CreateOrderInfoController {
                
                model.items.removeAll()
                
                vc.zType = self.zType;
                vc.passDataModel = model
                vc.isPushScreen1 = true
            }
        default:
            break
        }
    }
}

extension CreateOrderController: UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableview.dequeueReusableCell(withIdentifier: CreateOrderCell.className, for: indexPath) as? CreateOrderCell else {
            return UITableViewCell()
        }
        
        let item = data[indexPath.row]
        
        var content: String = ""
        
        if !item.listItem.isEmpty {
            content = item.listItem[item.selectedIndex]
        }
        
        cell.bindingData(title: item.title, content: content)
        
        return cell
    }
}
