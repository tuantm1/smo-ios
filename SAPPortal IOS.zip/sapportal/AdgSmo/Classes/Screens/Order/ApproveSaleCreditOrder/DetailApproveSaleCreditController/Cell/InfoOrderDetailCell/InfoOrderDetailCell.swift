//
//  InfoOrderDetailCell.swift
//  SapPortal
//
//  Created by LuongTiem on 6/15/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class InfoOrderDetailCell: UITableViewCell {
    
    @IBOutlet weak var borderView: UIView!
    
    @IBOutlet weak var dealerOrderLabel: UILabel!
    @IBOutlet weak var dealerOrderContentLabel: UILabel!
    
    @IBOutlet weak var orderIDLabel: UILabel!
    @IBOutlet weak var orderIDContentLabel: UILabel!
    
    @IBOutlet weak var liabilitiesSapLabel: UILabel!
    @IBOutlet weak var liabilitiesSapTitleLabel: UILabel!
    @IBOutlet weak var liabilitiesSapContentLabel: UILabel!
    
    @IBOutlet weak var limitCreditLabel: UILabel!
    @IBOutlet weak var limitCreditTitleLabel: UILabel!
    @IBOutlet weak var limitCreditContentLabel: UILabel!
    
    @IBOutlet weak var totalOrderLabel: UILabel!
    @IBOutlet weak var totalOrderContentLabel: UILabel!
    
    @IBOutlet weak var totalGuaranteedLabel: UILabel!
    @IBOutlet weak var totalGuaranteedContentLabel: UILabel!
    
    @IBOutlet weak var moneySapLabel: UILabel!
    @IBOutlet weak var moneySapContentLabel: UILabel!
    
    @IBOutlet weak var amountGuaranteeLabel: UILabel!
    @IBOutlet weak var amountGuaranteeContentLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }

   
    func bindingData(model: TotalApproveSaleCreditDetailModel) {
        
        dealerOrderContentLabel.text = model.orderDetailModel.nameShipTo
        
        orderIDContentLabel.text = model.orderDetailModel.idOrder
        
        //--
//        liabilitiesSapTitleLabel.text = setupLimitGuaranteeTitle(grade: model.guardian.grade,
//                                                                 divisions: model.divisionModel)
        
        liabilitiesSapContentLabel.text = setupLimitGuaranteeTitle(division: model.orderDetailModel.division,
                                                                   credits: model.customerDetailModel.creditCustomModel)?.amount.convertToCurrency
        
        
        //--
//        limitCreditTitleLabel.text = setupLimitGuaranteeTitle(grade: model.guardian.grade,
//                                                              divisions: model.divisionModel)
        limitCreditContentLabel.text = setupCreditTitle(division: model.orderDetailModel.division,
                                                        credits: model.customerDetailModel.creditModel)?.value.convertToCurrency
        
        totalOrderContentLabel.text = model.orderDetailModel.price.convertToCurrency
        
        totalGuaranteedContentLabel.text = model.orderDetailModel.stdbl.convertToCurrency
        
        moneySapContentLabel.text = model.orderDetailModel.totalInquiry.convertToCurrency
        
        amountGuaranteeContentLabel.text = model.orderDetailModel.stbl.convertToCurrency
    }
    
    
    
    private func setupLimitGuaranteeTitle(division: String, credits: [CreditCustomerModel]) -> CreditCustomerModel? {
        
        if let result = credits.first(where: { "CS\(division)" == $0.cs }) {
            
            return result
        }
        
        return nil
    }
    
    
    private func setupCreditTitle(division: String, credits: [CreditModel]) -> CreditModel? {
        
        if let result = credits.first(where: { "CS\(division)" == $0.cs }) {
            
            return result
        }
        
        return nil
    }
}


extension InfoOrderDetailCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
        
    }
    
    
    private func resetAllValue() {
        
        dealerOrderLabel.text = "Đại lý đặt hàng"
        dealerOrderContentLabel.text = ""
        
        orderIDLabel.text = "Số đơn hàng cần bảo lãnh"
        orderIDContentLabel.text = ""
        
        liabilitiesSapLabel.text = "Công nợ hiện tại SAP (Đồng)"
        liabilitiesSapTitleLabel.text = ""
        liabilitiesSapContentLabel.text = ""
        
        limitCreditLabel.text = "Hạn mức tín dụng SX (Đồng)"
        limitCreditTitleLabel.text = ""
        limitCreditContentLabel.text = ""
        
        totalOrderLabel.text = "Tổng giá trị đơn hàng (Đồng)"
        totalOrderContentLabel.text = ""
        
        totalGuaranteedLabel.text = "Tổng tiền hàng đã bảo lãnh (Đồng)"
        totalGuaranteedContentLabel.text = ""
        
        moneySapLabel.text = "Tổng tiền đã tạo báo giá SAP (Đồng)"
        moneySapContentLabel.text = ""
        
        amountGuaranteeLabel.text = "Số tiền cần bảo lãnh (Đồng)"
        amountGuaranteeContentLabel.text = ""
    }
}
