//
//  CreditDetailInfoCell.swift
//  SapPortal
//
//  Created by LuongTiem on 6/15/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class CreditDetailInfoCell: UITableViewCell {
    
    @IBOutlet weak var borderView: UIView!
    
    @IBOutlet weak var guaranteeUserLabel: UILabel!
    @IBOutlet weak var guaranteeUserContentLabel: UILabel!
    
    @IBOutlet weak var recipientGuaranteeLabel: UILabel!
    @IBOutlet weak var recipientGuaranteeContentLabel: UILabel!
    @IBOutlet weak var chooseGuaranteeHitTestView: TouchHitTestView!
    @IBOutlet weak var recipientGuaranteeSelectedtLabel: UILabel!
    
    @IBOutlet weak var limitGuaranteeLabel: UILabel!
    @IBOutlet weak var limitGuaranteeTitleLabel: UILabel!
    @IBOutlet weak var limitGuaranteeContentLabel: UILabel!
    
    @IBOutlet weak var dateCreateLabel: UILabel!
    @IBOutlet weak var dateCreateContentLabel: UILabel!
    
    @IBOutlet weak var timeExpiresLabel: UILabel!
    @IBOutlet weak var timeExpiresContentLabel: UILabel!
    @IBOutlet weak var chooseTimeExpireHitTestView: TouchHitTestView!
    @IBOutlet weak var timeExpiresSelectedLabel: UILabel!
    
    @IBOutlet weak var dateExpiresLabel: UILabel!
    @IBOutlet weak var dateExpiresContentLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var statusContentLabel: PaddingLabel!
    
    @IBOutlet weak var noteLabel: UILabel!
    @IBOutlet weak var noteTextView: UITextView!
    
    
    var isCreateGuaranteeOrder: Bool = false {
        didSet {
            chooseGuaranteeHitTestView.isHidden = !isCreateGuaranteeOrder
            recipientGuaranteeContentLabel.isHidden = isCreateGuaranteeOrder
            
            chooseTimeExpireHitTestView.isHidden = !isCreateGuaranteeOrder
            timeExpiresContentLabel.isHidden = isCreateGuaranteeOrder
            
            noteTextView.isUserInteractionEnabled = isCreateGuaranteeOrder
        }
    }
    
    var updateGuarantee: (() -> Void)?
    
    var updateExpiresDay: (() -> Void)?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
        
        statusContentLabel.padding(5, 5, 8, 8)
        statusContentLabel.textColor = .white
        statusContentLabel.layer.cornerRadius = 12
        statusContentLabel.layer.masksToBounds = true
        
        isCreateGuaranteeOrder = false
        
        chooseGuaranteeHitTestView.layer.cornerRadius = 4
        chooseGuaranteeHitTestView.layer.masksToBounds = true
        chooseGuaranteeHitTestView.layer.borderColor = UIColor.lightGray.cgColor
        chooseGuaranteeHitTestView.layer.borderWidth = 0.8
        chooseGuaranteeHitTestView.didSelectedView = {
            self.updateGuarantee?()
        }
        
        chooseTimeExpireHitTestView.layer.cornerRadius = 4
        chooseTimeExpireHitTestView.layer.masksToBounds = true
        chooseTimeExpireHitTestView.layer.borderColor = UIColor.lightGray.cgColor
        chooseTimeExpireHitTestView.layer.borderWidth = 0.8
        chooseTimeExpireHitTestView.didSelectedView = {
            self.updateExpiresDay?()
        }
    }

    func bindingData(model: TotalApproveSaleCreditDetailModel) {
         
        guaranteeUserContentLabel.text = model.guardian.user.description
        
        
//        if !model.guardian.parents.isEmpty {
//            let name = model.guardian.parents[model.indexGuaranteeSelected].description
//            recipientGuaranteeSelectedtLabel.text = name
//            recipientGuaranteeContentLabel.text = name
//        }
        recipientGuaranteeContentLabel.text = model.saleManager.user.description
        
        limitGuaranteeTitleLabel.text = setupLimitGuaranteeTitle(grade: model.guardian.grade, divisions: model.divisionModel)
        limitGuaranteeContentLabel.text = model.guardian.hmcl.convertToCurrency
        
        dateCreateContentLabel.text = model.guaranteeDetailModel.date
        
        let timeExpires = Int(model.guaranteeDetailModel.day) ?? 0
        timeExpiresContentLabel.text = "\(timeExpires)"
        
        dateExpiresContentLabel.text =  Date.updateNewDate(dateString: model.guaranteeDetailModel.date, increase: timeExpires)
        
        statusContentLabel.text = setStatus(status: model.guaranteeDetailModel.status).0
        statusContentLabel.backgroundColor = setStatus(status: model.guaranteeDetailModel.status).1
        
        noteTextView.text = model.guaranteeDetailModel.note
    }
    
    
    private func setupLimitGuaranteeTitle(grade: String, divisions: [DivisionModel]) -> String {
        
        if let result = divisions.first(where: { "CS\($0.spart)" == grade}) {
            
            return result.vtext
        }
        
        return ""
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        noteTextView.layer.cornerRadius = 8
        noteTextView.layer.masksToBounds = true
        noteTextView.layer.borderColor = UIColor.lightGray.cgColor
        noteTextView.layer.borderWidth = 0.5
    }
    
    
    private func setStatus(status: String) -> (title: String, color: UIColor) {
        
        switch status {
        case "":
            return ("Đang tạo bảo lãnh".uppercased(), #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1))
        default:
            return ("Đã bảo lãnh".uppercased(), #colorLiteral(red: 0, green: 0.4901960784, blue: 1, alpha: 1))
        }
    }
    
    
}

// MARK: BindingData Create Guarantee
extension CreditDetailInfoCell {
    
    func bindingCreateGuaranteeData(model: TotalApproveSaleCreditDetailModel) {
         
        guaranteeUserContentLabel.text = model.guardian.user.description
        
        if !model.guardian.parents.isEmpty {
            let name = model.guardian.parents[model.indexGuaranteeSelected].description
            recipientGuaranteeSelectedtLabel.text = name
            recipientGuaranteeContentLabel.text = name
        }
        
        
        limitGuaranteeTitleLabel.text = setupLimitGuaranteeTitle(grade: model.guardian.grade, divisions: model.divisionModel)
        limitGuaranteeContentLabel.text = model.guardian.hmcl.convertToCurrency
        
        let nowDay = Date().convertString(formatter: "dd/MM/yyyy")
        dateCreateContentLabel.text = nowDay
        
        let timeExpires = model.dateExpires.model[model.dateExpires.indexSelected]
        timeExpiresSelectedLabel.text = "\(timeExpires) ngày"
        
        dateExpiresContentLabel.text =  Date.updateNewDate(dateString: nowDay, increase: timeExpires)
        
        statusContentLabel.text = setStatus(status: model.guaranteeDetailModel.status).0
        statusContentLabel.backgroundColor = setStatus(status: model.guaranteeDetailModel.status).1
        
        noteTextView.text = model.guaranteeDetailModel.note
    }
}


extension CreditDetailInfoCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        resetAllValue()
    }
    
    private func resetAllValue() {
        
        guaranteeUserLabel.text = "Nhân viên Quản lý Đơn hàng"
        guaranteeUserContentLabel.text = ""
        
        recipientGuaranteeLabel.text = "Người bảo lãnh"
        recipientGuaranteeContentLabel.text = ""
        
        limitGuaranteeLabel.text = "Hạn mức bảo lãnh SX còn lại (Đồng)"
        limitGuaranteeTitleLabel.text = ""
        limitGuaranteeContentLabel.text = ""
        
        dateCreateLabel.text = "Ngày yêu cầu bảo lãnh"
        dateCreateContentLabel.text = ""
        
        timeExpiresLabel.text = "Thời hạn bảo lãnh (Ngày)"
        timeExpiresContentLabel.text = ""
        
        dateExpiresLabel.text = "Ngày hết hạn bảo lãnh"
        dateExpiresContentLabel.text = ""
        
        statusLabel.text = "Trạng thái"
        statusContentLabel.text = ""
        
        noteLabel.text = "Ghi chú"
        noteTextView.text = ""
        
        statusContentLabel.text = ""
        statusContentLabel.backgroundColor = UIColor.clear
        
        recipientGuaranteeSelectedtLabel.text = ""
        recipientGuaranteeContentLabel.text = ""
    }
}
