//
//  ApproveSalesOrderCreditCell.swift
//  SapPortal
//
//  Created by LuongTiem on 5/31/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ApproveSalesOrderCreditCell: UITableViewCell {
    

    @IBOutlet weak var codeOrderLabel: UILabel!
    @IBOutlet weak var codeOrderContentLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var dateContentLabel: UILabel!
    
    @IBOutlet weak var agencyLabel: UILabel!
    @IBOutlet weak var agencyContentLabel: UILabel!
    
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var priceContentLabel: UILabel!
    
    @IBOutlet weak var approveButton: RoundButton!
    @IBOutlet weak var rejectButton: RoundButton!
    
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var statusContentLabel: PaddingLabel!
    
    @IBOutlet weak var actionStackView: UIStackView!
    @IBOutlet weak var topActionStackViewConstraint: NSLayoutConstraint!
    
    var approveSalesOrderCreditModel: ApproveSalesOrderCreditModel! {
        didSet {
            self.bindingData(model: approveSalesOrderCreditModel)
        }
    }
    
    
    var delegate: ActionOrderDelegate?
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
        
        statusContentLabel.padding(5, 5, 8, 8)
        statusContentLabel.textColor = .white
        statusContentLabel.layer.cornerRadius = 12
        statusContentLabel.layer.masksToBounds = true
    }

    
    func bindingData(model: ApproveSalesOrderCreditModel) {
        
        codeOrderLabel.text = "Số yêu cầu"
        codeOrderContentLabel.text = model.creditID
        
        dateLabel.text = "Ngày yêu cầu bảo lãnh"
        dateContentLabel.text = model.date
        
        agencyLabel.text = "Đại lý được bảo lãnh"
        agencyContentLabel.text = ""//model.orderID
        
        priceLabel.text = "Số tiền bảo lãnh"
        priceContentLabel.text = model.stbl.convertToCurrency
        
        statusLabel.text = "Trạng thái"
        statusContentLabel.text = setStatus(status: model.status).0
        statusContentLabel.backgroundColor = setStatus(status: model.status).color
    }
    
    
    private func setStatus(status: String) -> (title: String, color: UIColor) {
        
        switch status {
        case "1":
            return ("Đã bảo lãnh".uppercased(), #colorLiteral(red: 0, green: 0.4901960784, blue: 1, alpha: 1))
        case "2":
            return ("Đã từ chối".uppercased(), #colorLiteral(red: 0.8039215686, green: 0.3568627451, blue: 0.3333333333, alpha: 1))
        default:
            return ("Chờ phê duyệt".uppercased(), #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1))
        }
    }
    
    
    
    func configPermissionsAction(model: ApproveSalesOrderCreditModel) {
        
        let permissionApprove: Bool = ApproveSalesOrderCreditModel.showHiddenApproveSalesOrderCreditAction(model: model)
        
        topActionStackViewConstraint.constant = permissionApprove ? 24 : -actionStackView.frame.height
        actionStackView.isHidden = !permissionApprove
        
        
        approveButton.isHidden = ApproveSalesOrderCreditModel.hiddenGuaranteeButton(model: model)
        
        
    }
    
    
    @IBAction func approveAction(_ sender: Any) {
        self.delegate?.selectApprove(cell: self)
    }
    
    @IBAction func rejectAction(_ sender: Any) {
        self.delegate?.selectReject(cell: self)
    }
}


extension ApproveSalesOrderCreditCell {
    
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    

    private func resetAllValue() {
        codeOrderLabel.text = ""
        codeOrderContentLabel.text = ""
        
        dateLabel.text = ""
        dateContentLabel.text = ""
        
        agencyLabel.text = ""
        agencyContentLabel.text = ""
        
        priceLabel.text = ""
        priceContentLabel.text = ""
        
        statusLabel.text = ""
        statusContentLabel.text = ""
    }
}
