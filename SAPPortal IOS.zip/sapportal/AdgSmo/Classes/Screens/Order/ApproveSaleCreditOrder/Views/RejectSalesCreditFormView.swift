//
//  RejectSalesCreditFormView.swift
//  SapPortal
//
//  Created by LuongTiem on 6/1/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class RejectSalesCreditFormView: UIView {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var reasonOtherTextField: UITextField!
    @IBOutlet weak var sendButton: RoundButton!
    
    
    var reasonRejectOrder: ((String) -> Void)?
    
    
    override class func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    
    @IBAction func sendAction(_ sender: Any) {
        
        self.reasonRejectOrder?(reasonOtherTextField.text ?? "")
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        reasonOtherTextField.addPadding(.left(8))
        reasonOtherTextField.placeholderColor = UIColor(white: 0.5, alpha: 1)
        reasonOtherTextField.layer.borderColor = #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
        reasonOtherTextField.layer.borderWidth = 1
        reasonOtherTextField.layer.masksToBounds = true
        reasonOtherTextField.layer.cornerRadius = 8
    }
    
}
