//
//  ApproveSalesOrderCreditController.swift
//  SapPortal
//
//  Created by LuongTiem on 5/31/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import SwiftEntryKit


class ApproveSalesOrderCreditController: BaseViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var listApproveCredit: [ApproveSalesOrderCreditModel] = []
    
    private var filteredResults: [ApproveSalesOrderCreditModel] = [] {
        didSet {
            isSearching = true
        }
    }
    
    var menuModel: MenuModel!
    
    var isSearching: Bool = false {
        
        didSet {
            if tableView == nil { return }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    private let searchController = UISearchController(searchResultsController: nil)
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = menuModel.description.uppercased()
        
        tableView.register(UINib(nibName: ApproveSalesOrderCreditCell.className, bundle: nil), forCellReuseIdentifier: ApproveSalesOrderCreditCell.className)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 200
        tableView.tableFooterView = UIView()
        tableView.keyboardDismissMode = .onDrag
        
        searchController.delegate = self
        searchController.searchResultsUpdater = self
        searchController.searchBar.autocapitalizationType = .none
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.delegate = self // Monitor when the search button is tapped.
        
        definesPresentationContext = true
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
    }
    

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        fetchAllData()
    }
    
    
    override func fetchAllData() {
        super.fetchAllData()
        
        ApproveSalesOrderCreditAPI.init(userID: MenuManager.shared.userID).execute(target: self, success: { (response) in
            
            self.listApproveCredit = response.gtCredit
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }) { (error) in
            
        }
        
    }

}

extension ApproveSalesOrderCreditController: UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let items = isSearching ? filteredResults : listApproveCredit
        
        performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushDetailApproveSaleOrderCredit, sender: items[indexPath.row])
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case SegueIdentifier.MenuOrder.pushDetailApproveSaleOrderCredit:
            if let model = sender as? ApproveSalesOrderCreditModel, let vc = segue.destination as? DetailApproveSaleCreditController {
                vc.modelData = model
            }
        default:
            break
        }
    }
}


extension ApproveSalesOrderCreditController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return isSearching ? filteredResults.count : listApproveCredit.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ApproveSalesOrderCreditCell.className, for: indexPath) as? ApproveSalesOrderCreditCell else {
            return UITableViewCell()
        }
        
        let items = isSearching ? filteredResults : listApproveCredit
        let model = items[indexPath.row]
        cell.approveSalesOrderCreditModel = model
        cell.configPermissionsAction(model: model)
        cell.delegate = self
        
        return cell
    }
    
}


extension ApproveSalesOrderCreditController: ActionOrderDelegate {
    
    func selectApprove(cell: UITableViewCell) {
        guard let selectedCell = cell as? ApproveSalesOrderCreditCell, let modelData = selectedCell.approveSalesOrderCreditModel else {
            return
        }
        
        ApproveOrderActionAPI.init(userID: MenuManager.shared.userID, orderID: modelData.orderID).execute(target: self, success: { (response) in
            self.fetchAllData()
            
        }) { (error) in
            
        }
    }
    
    func selectReject(cell: UITableViewCell) {
        guard let selectedCell = cell as? ApproveSalesOrderCreditCell, let modelData = selectedCell.approveSalesOrderCreditModel else { return }
        
        let customView: RejectSalesCreditFormView = RejectSalesCreditFormView.fromNib()
        customView.layer.cornerRadius = 10
        customView.layer.masksToBounds = true
        customView.reasonRejectOrder = { reasonReject in
            
            SwiftEntryKit.dismiss()
            
            RejectCreditActionAPI.init(creditID: modelData.creditID,
                                       orderID: modelData.orderID,
                                       userID: modelData.requestID,
                                       reasonReject: reasonReject)
                .execute(target: self, success: { (response) in
                    self.fetchAllData()
                }) { (error) in
            }
        }
        
        AlertHelperKit.showSwiftEntryKit(customView: customView)
    }
    
    
}


// MARK: SEARCH

extension ApproveSalesOrderCreditController {
    
    private func findMatches(searchString: String = "") -> NSCompoundPredicate {
        
        var searchItemsPredicate: [NSPredicate] = []
        
        let titleExpression: NSExpression = NSExpression(forKeyPath: "creditID")
        let searchStringExpression = NSExpression(forConstantValue: searchString)
        
        let titleSearchComparisonPredicate = NSComparisonPredicate(leftExpression: titleExpression,
                                                                   rightExpression: searchStringExpression,
                                                                   modifier: .direct,
                                                                   type: .contains,
                                                                   options: [.caseInsensitive, .diacriticInsensitive])
        
        searchItemsPredicate.append(titleSearchComparisonPredicate)
        
        
        var finalCompoundPredicate: NSCompoundPredicate!
        
        finalCompoundPredicate = NSCompoundPredicate(orPredicateWithSubpredicates: searchItemsPredicate)
        
        return finalCompoundPredicate
    }
    
}

extension ApproveSalesOrderCreditController: UISearchResultsUpdating {
    
    func updateSearchResults(for searchController: UISearchController) {
        
        let searchResults = listApproveCredit
        
        let strippedString = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        
        let searchItems = strippedString.components(separatedBy: " ") as [String]
        
        // Build all the "AND" expressions for each value in searchString.
        let andMatchPredicates: [NSPredicate] = searchItems.map { searchString in
            findMatches(searchString: searchString)
        }
        
        let finalCompoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: andMatchPredicates)
        
        filteredResults = searchResults.filter { finalCompoundPredicate.evaluate(with: $0) }
    }
    
}


extension ApproveSalesOrderCreditController: UISearchControllerDelegate {

    func didDismissSearchController(_ searchController: UISearchController) {
        isSearching = false
    }
    
    
    func willPresentSearchController(_ searchController: UISearchController) {
        
        isSearching = true
    }
}


extension ApproveSalesOrderCreditController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        updateSearchResults(for: searchController)
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
    }
}

