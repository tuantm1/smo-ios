//
//  MenuOrderController.swift
//  SapPortal
//
//  Created by LuongTiem on 4/22/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class MenuOrderController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    private var pagingCollectionFlowLayout = PagingCollectionFlowLayout()
    
    @IBOutlet weak var pageControl: UIPageControl!
    
    var listMenu: [MenuModel] = MenuManager.shared.menuOrder
    
    let heightHeaderView: CGFloat = 0
    
    var isGoList: Bool = false;
    var idOrder: String = "";
    
    lazy var headerView: MenuOrderHeaderView = {
        let view: MenuOrderHeaderView = MenuOrderHeaderView.fromNib()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
   

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "QUẢN LÝ ĐƠN HÀNG"
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.contentInset = UIEdgeInsets(top: heightHeaderView, left: 0, bottom: 4, right: 0)
        collectionView.register(UINib(nibName: MenuOrderCollectionCell.className, bundle: nil),
                                forCellWithReuseIdentifier: MenuOrderCollectionCell.className)
        pagingCollectionFlowLayout.rows = 3
        pagingCollectionFlowLayout.columns = 2
        collectionView.collectionViewLayout = pagingCollectionFlowLayout
        setupPageControl()
        
        if listMenu.isEmpty {
            displayWarningLabel(message: "Tài khoản bị giới hạn quyền truy cập mục")
        }
    }
    
    private func setupPageControl() {
        pageControl.currentPage = 0
        pagingCollectionFlowLayout.totalPage = { result in
            self.pageControl.numberOfPages = result
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        collectionView.reloadData()
        collectionView.collectionViewLayout.invalidateLayout()
        
        if isGoList {
            isGoList = false
            let model = MenuManager.shared.menuOrder.first(where: { $0.name == "Order" })
            performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushOrderController, sender: model)
        }
    }
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        pageControl.currentPage = Int(floor(collectionView.contentOffset.x/collectionView.frame.size.width))
    }


}

extension MenuOrderController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let model = listMenu[indexPath.row]
        
        let menuType: MenuType = MenuType.getMenuType(idMenu: model.idMenu)
        
        switch menuType {
        case .approve:
            performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushApproveOrder, sender: model)
        case .orderReturn:
            performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushReturnOrder, sender: model)
        case .order:
            performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushOrderController, sender: model)
        case .credit:
            performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushApproveCredit, sender: model)
        case .createCredit:
            performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushGuaranteeListOrder, sender: model)
        case .createOrder:
            performSegue(withIdentifier: SegueIdentifier.MenuOrder.pushCreateOrder, sender: model)
        default:
            AlertHelperKit.showDefaultAlert(message: "Tính năng đang được cập nhật") {
                
            }
            return
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        switch segue.identifier {
        case SegueIdentifier.MenuOrder.pushApproveOrder:
            if let model = sender as? MenuModel, let vc = segue.destination as? ApproveOrderController {
                vc.menuModel = model
            }
        case SegueIdentifier.MenuOrder.pushReturnOrder:
            if let model = sender as? MenuModel, let vc = segue.destination as? ReturnOrderController {
                vc.menuModel = model
            }
        case SegueIdentifier.MenuOrder.pushOrderController:
            if let model = sender as? MenuModel, let vc = segue.destination as? OrderController {
                vc.menuModel = model
                vc.idOrder = self.idOrder
            }
        case SegueIdentifier.MenuOrder.pushGuaranteeListOrder:
            if let model = sender as? MenuModel, let vc = segue.destination as? GuaranteeListOrderController {
                vc.menuModel = model
            }
        case SegueIdentifier.MenuOrder.pushApproveCredit:
            if let model = sender as? MenuModel, let vc = segue.destination as? ApproveSalesOrderCreditController {
                vc.menuModel = model
            }
        case SegueIdentifier.MenuOrder.pushCreateOrder:
            if let model = sender as? MenuModel, let vc = segue.destination as? CreateOrderController {
                vc.menuModel = model
            }
        default:
            break
        }
    }
    
}

extension MenuOrderController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let condition: CGFloat = 3
        
        return CGSize(width: collectionView.frame.width/2,
                      height: (collectionView.frame.height - collectionView.contentInset.bottom - heightHeaderView)/condition)
    }
}

extension MenuOrderController: UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return listMenu.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MenuOrderCollectionCell.className, for: indexPath) as! MenuOrderCollectionCell
        cell.bindingData(name: listMenu[indexPath.row].description)
        cell.shadowView.backgroundColor = MenuManager.shared.randomColor(item: indexPath.row, totalItem: listMenu.count)
        return cell
    }
}

