//
//  MenuOrderCollectionCell.swift
//  SapPortal
//
//  Created by LuongTiem on 4/22/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class MenuOrderCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var shadowView: ShadowView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    func bindingData(name: String) {
        nameLabel.text = name
    }

}

extension MenuOrderCollectionCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        nameLabel.text = ""
    }
}
