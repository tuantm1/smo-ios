//
//  MenuOrderDashboardCollectionCell.swift
//  SapPortal
//
//  Created by LuongTiem on 4/22/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class MenuOrderDashboardCollectionCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
