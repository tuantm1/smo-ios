//
//  MenuOrderHeaderView.swift
//  SapPortal
//
//  Created by LuongTiem on 5/2/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class MenuOrderHeaderView: UIView {

    
}
