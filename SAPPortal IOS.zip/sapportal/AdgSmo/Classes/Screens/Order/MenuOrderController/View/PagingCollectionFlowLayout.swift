//
//  PagingCollectionFlowLayout.swift
//  SapPortal
//
//  Created by LuongTiem on 4/23/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class PagingCollectionFlowLayout: UICollectionViewFlowLayout {
    
    var columns: Int = -1
    
    var rows: Int = -1
    
    var totalPage: ((Int) -> Void)? ///* Always call after init UICollectionViewFlowLayout success */
    
    
    
    override init() {
        super.init()
        
        columns = -1
        
        rows = -1

        self.minimumLineSpacing = 0

        self.minimumInteritemSpacing = 0
        
        self.scrollDirection = .horizontal
        
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override var collectionViewContentSize: CGSize {
        
        let size = super.collectionViewContentSize
        
        let collectionWidth = self.collectionView!.frame.size.width
        
        let numberOfScreen = ceil(size.width/collectionWidth)
        
        totalPage?(Int(numberOfScreen))
        
        let newSize = CGSize(width: numberOfScreen * collectionWidth, height: size.height)
        
        return newSize
    }


    override func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        return true
    }
    
    
    override func layoutAttributesForItem(at indexPath: IndexPath) -> UICollectionViewLayoutAttributes? {
        
        guard let width = self.collectionView?.frame.size.width, let height = self.collectionView?.frame.size.height else {
            return nil
        }
        
        let column: Int = self.columns == -1 ? Int(width/itemSize.width) : self.columns
        
        let row: Int = self.rows == -1 ? Int(height/itemSize.height) : self.rows
        
        let idPage: Int = Int(indexPath.row/(column * row))
        
        let temp: Int = indexPath.row - (idPage * column * row)
        
        let xD: Int = Int(temp/column)
        
        let yD: Int = temp % column
        
        let D = xD + yD * row + idPage * column * row
        
        let fakeIndexPath = IndexPath(row: D, section: indexPath.section)
        
        let attributes = super.layoutAttributesForItem(at: fakeIndexPath)
        
        return attributes
    }
    
    
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        
        let newX: CGFloat = min(0, rect.origin.x - rect.size.width/2)
        
        let newWidth: CGFloat = rect.size.width*2 + (rect.origin.x - newX)
        
        let newRect: CGRect = CGRect(x: newX, y: rect.origin.y, width: newWidth, height: rect.size.height)
        
        guard let superAttributes = super.layoutAttributesForElements(in: newRect) else { return nil }
        
        guard let allAttributesInRect = superAttributes.map( { $0.copy() }) as? [UICollectionViewLayoutAttributes] else {
            return nil
        }
        
        allAttributesInRect.forEach({ (attributes) in
            
            let newAttributes = self.layoutAttributesForItem(at: attributes.indexPath)
            
            if let frame = newAttributes?.frame, let center = newAttributes?.center,
                let bounds = newAttributes?.bounds, let isHidden = newAttributes?.isHidden,
                let size = newAttributes?.size {
                
                attributes.frame = frame
                attributes.center = center
                attributes.bounds = bounds
                attributes.isHidden = isHidden
                attributes.size = size
            }
        })
        
        return allAttributesInRect
    }
    
    
}
