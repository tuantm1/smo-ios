//
//  ReceiptPrintController.swift
//  SapPortal
//
//  Created by LuongTiem on 5/22/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import PDFKit

class ReceiptPrintController: BaseViewController {
    
    @IBOutlet weak var pdfView: PDFView!
    
    var passModel: DeliveryHeaderModel!

    var rawDataBase64: String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "TRẠNG THÁI ĐƠN HÀNG"
        pdfView.autoScales = true
        pdfView.delegate = self
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        fetchAllData()
    }
    
    
    override func fetchAllData() {
        super.fetchAllData()
        
        ReceiptPrintAPI.init(idOrder: passModel.saleOrder).execute(target: self, success: { (response) in
            
            DispatchQueue.main.async {
                self.rawDataBase64 = response.rawData
                self.configPDFView(rawDataBase64: response.rawData)
            }
                
        }) { (error) in
            
        }
    }
    
    
    
    @IBAction func printAction(_ sender: Any) {
        
        guard let data = Data(base64Encoded: rawDataBase64, options: Data.Base64DecodingOptions.ignoreUnknownCharacters) else { return }
        
        if UIPrintInteractionController.canPrint(data) {
            let printInfo = UIPrintInfo(dictionary: nil)
            printInfo.jobName = "DON HANG"
            printInfo.outputType = .general

            let printController = UIPrintInteractionController.shared
            printController.printInfo = printInfo
            printController.showsNumberOfCopies = false

            printController.printingItem = data

            printController.present(animated: true, completionHandler: nil)
        }
    }
    
}

extension ReceiptPrintController: PDFViewDelegate {
    
    private func configPDFView(rawDataBase64: String) {
        
        guard let data = Data(base64Encoded: rawDataBase64, options: Data.Base64DecodingOptions.ignoreUnknownCharacters) else { return }
        
        if let document = PDFDocument(data: data) {
            pdfView.document = document
        }

    }
    
}
