//
//  DeliveryController.swift
//  SapPortal
//
//  Created by LuongTiem on 5/15/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

enum StateDeliveryOrder {
    
    case unowned
    
    case notDelivery
    
    case delivered

    
    static func getState(value: String) -> StateDeliveryOrder {
        
        switch value {
        case "2":
            return .notDelivery
        case "3":
            return .delivered
        default:
            return .unowned
        }
    }
    
    
    var paramValue: String {
        switch self {
        case .unowned:
            return ""
        case .notDelivery:
            return "2"
        case .delivered:
            return "3"
        }
    }
    
    
    var pageIndex: Int {
        switch self {
        case .unowned:
            return 0
        case .notDelivery:
            return 0
        case .delivered:
            return 1
        }
    }
}

class DeliveryController: UIViewController {
    
    @IBOutlet weak var tableview: UITableView!
    
    @IBOutlet weak var menuBar: UIView!
    
    var deliveryModel: DeliveryModel = DeliveryModel()
    
    private lazy var pageTitleView: PageTitleView = { [weak self] in
        let titleView = PageTitleView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 40), titles: titles)
        titleView.delegate = self
        
        return titleView
    }()
    
    let titles = ["Chưa Giao", "Đã giao"]
    
    private var fetchDataAtDate: Date = Date()
    
    private var isForbidScrollDelegate : Bool = false
    
    private var startOffsetX : CGFloat = 0.0
    
    private var statusDelivery: StateDeliveryOrder = .notDelivery
    
    private var resultTotalOrder: [DeliveryHeaderModel] = []
    
    private let searchController = UISearchController(searchResultsController: nil)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Lịch sử giao hàng".uppercased()
        
        tableview.register(UINib(nibName: DeliveryListCell.className, bundle: nil), forCellReuseIdentifier: DeliveryListCell.className)
        tableview.register(UINib(nibName: DeliveryHeaderSessionView.className, bundle: nil), forHeaderFooterViewReuseIdentifier: DeliveryHeaderSessionView.className)
        
        tableview.rowHeight = UITableView.automaticDimension
        tableview.estimatedRowHeight = 240
        
        tableview.sectionHeaderHeight = UITableView.automaticDimension
        tableview.estimatedSectionHeaderHeight = 60
        tableview.keyboardDismissMode = .onDrag
        
        menuBar.addSubview(pageTitleView)
        

    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.resultTotalOrder = []
        self.tableview.reloadData()
        
        let index = statusDelivery == .notDelivery ? 0 : 1
        self.pageTitleView(titleView: self.pageTitleView, selectedIndex: index)
        
    }
    
    
    @IBAction func calendarAction(_ sender: Any) {
        
        let calendarView: CalendarView = CalendarView.fromNib()
        calendarView.layer.cornerRadius = 8
        calendarView.layer.masksToBounds = true
        calendarView.layer.borderColor = UIColor.red.cgColor
        calendarView.layer.borderWidth = 0.5
        
        calendarView.didSelectDate = { date in
            
            AlertHelperKit.dismiss()
            
            self.fetchDataAtDate = date
            self.fetchAllData(date: date, ttGH: self.statusDelivery)
        }
        
        AlertHelperKit.showSwiftEntryKit(customView: calendarView)
    }
    
    
    
    func fetchAllData(date: Date, ttGH: StateDeliveryOrder) {
        
        DeliveryAPI.init(maVT: "", ngayGiao: date.convertString, maChuyen: MenuManager.shared.userDetail.user.username,
                         ttGH: ttGH.paramValue).execute(target: self, success: { (response) in
            
            if let data = response.model {
                self.deliveryModel = data
                self.resultTotalOrder = data.header
                self.tableview.reloadData()
            }
            
        }) { (error) in
            
        }
    }
}

extension DeliveryController: UITableViewDelegate {

    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = tableview.dequeueReusableHeaderFooterView(withIdentifier: DeliveryHeaderSessionView.className) as! DeliveryHeaderSessionView
        
        let title = MenuManager.shared.userDetail.user.username + " - \(self.fetchDataAtDate.convertString(formatter: "dd/MM/YYYY"))"
        
        let subTitle = "Ngày cập nhật: \(Date().convertString(formatter: "dd/MM/YYYY")), \(resultTotalOrder.count) đơn hàng."
        
        headerView.bindingData(title: title, subTitle: subTitle)
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let model = DeliveryDetailModel(deliveryModel: self.deliveryModel, headerModel: self.resultTotalOrder[indexPath.row])
        performSegue(withIdentifier: SegueIdentifier.MenuDelivery.showDeliveryDetail, sender: model)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case SegueIdentifier.MenuDelivery.showDeliveryDetail:
            if let model = sender as? DeliveryDetailModel, let vc = segue.destination as? DeliveryDetailController {
                vc.modelData = model
                vc.stateDeliveryOrder = self.statusDelivery
            }
        default:
            break
        }
    }
    
}


extension DeliveryController: UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return resultTotalOrder.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: DeliveryListCell.className, for: indexPath) as? DeliveryListCell else {
            return UITableViewCell()
        }
        
        cell.bindingData(model: resultTotalOrder[indexPath.row])
        
        return cell
    }
}

extension DeliveryController {
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        
        isForbidScrollDelegate = false
        
        startOffsetX = scrollView.contentOffset.x
    }
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if isForbidScrollDelegate { return }
        
        var progress : CGFloat = 0.0
        var sourceIndex : Int = 0
        var targetIndex : Int = 0
        
        let currentOffsetX = scrollView.contentOffset.x
        let scrollViewW = scrollView.frame.width
        
        if currentOffsetX > startOffsetX {
            
            progress = currentOffsetX / scrollViewW - floor(currentOffsetX / scrollViewW)
            
            sourceIndex = Int(currentOffsetX / scrollViewW)
            
            targetIndex = sourceIndex + 1
            if targetIndex >= titles.count {
                targetIndex = titles.count - 1
            }
            
            if currentOffsetX - startOffsetX == scrollViewW {
                progress = 1
                targetIndex = sourceIndex
            }
            
        } else {
            
            progress = 1 - (currentOffsetX / scrollViewW - floor(currentOffsetX / scrollViewW))
            
            targetIndex = Int(currentOffsetX / scrollViewW)
            
            sourceIndex = targetIndex + 1
            if sourceIndex >= titles.count {
                sourceIndex = titles.count - 1
            }
            
        }
        
        pageTitleView.setTitleWithProgress(progress: progress, sourceIndex: sourceIndex, targetIndex: targetIndex)
    }
    
}

extension DeliveryController: PageTitleViewDelegate {
    
    func pageTitleView(titleView: PageTitleView, selectedIndex: Int) {
        
        isForbidScrollDelegate = true
        
        statusDelivery = selectedIndex == 0 ? .notDelivery : .delivered
        
        fetchAllData(date: self.fetchDataAtDate, ttGH: statusDelivery)
    }

}
