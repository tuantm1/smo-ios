//
//  ReceiptUploadController.swift
//  SapPortal
//
//  Created by LuongTiem on 5/22/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ReceiptUploadController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

}



