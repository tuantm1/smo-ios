//
//  DeliveryPhotoCell.swift
//  SapPortal
//
//  Created by LuongTiem on 5/29/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class DeliveryPhotoCell: UITableViewCell {

    @IBOutlet weak var photoImage: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
    }

    
    
}
