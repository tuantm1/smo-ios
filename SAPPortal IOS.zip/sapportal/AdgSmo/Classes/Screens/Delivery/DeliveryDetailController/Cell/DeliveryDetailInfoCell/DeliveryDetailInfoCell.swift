//
//  DeliveryDetailInfoCell.swift
//  SapPortal
//
//  Created by LuongTiem on 5/20/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class DeliveryDetailInfoCell: UITableViewCell {
    
    @IBOutlet weak var codeOrderLabel: UILabel!
    @IBOutlet weak var nameCustomerLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var motaXKLabel: UILabel!
    @IBOutlet weak var orderLabel: UILabel!
    @IBOutlet weak var timeGiaoHangLabel: UILabel!
    @IBOutlet weak var driverLabel: UILabel!
    @IBOutlet weak var borderView: UIView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }
    
    
    func bindingData(model: DeliveryDetailModel?) {
        
        guard let deliveryModel = model?.deliveryModel, let headerModel = model?.headerModel else { return }
        
        let itemDelivery = deliveryModel.itemDelivery(saleOrder: headerModel.saleOrder).map { data -> String in
            return data.motaMH
        }
        
        let itemDeliveryString = itemDelivery.joined(separator: ", ")
        codeOrderLabel.customFontSize(firstString: "Mã đơn hàng:  ", secondString: "#\(headerModel.ctXK)", secondFont: UIFont.italicSystemFont(ofSize: 16))
        nameCustomerLabel.customFontSize(firstString: "Tên khách hàng:  ", secondString: headerModel.nguoiNH)
        addressLabel.customFontSize(firstString: "Địa chỉ:  ", secondString: headerModel.getAddress())
        motaXKLabel.customFontSize(firstString: "Xuất kho:  ", secondString: headerModel.motaXNK)
        timeGiaoHangLabel.customFontSize(firstString: "Thời gian giao hàng:  ", secondString: headerModel.timeGH)
//        driverLabel.customFontSize(firstString: "Lái xe:  ", secondString: headerModel.laixe)
        orderLabel.customFontSize(firstString: "Mặt hàng:  ", secondString: itemDeliveryString)
    }
    
    private func getAddress(_ model: DeliveryHeaderModel) -> String {
        
        if model.diachiGH1.isEmpty {
            
            if model.diachiGH2.isEmpty {
                return model.diachiGH3
            }
            
            return model.diachiGH2
            
        } else {
            return model.diachiGH1
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        borderView.layer.borderWidth = 1
        borderView.layer.cornerRadius = 16
        borderView.layer.masksToBounds = true
        borderView.layer.borderColor = #colorLiteral(red: 0.2901960784, green: 0.6941176471, blue: 0.7450980392, alpha: 1).cgColor
    }
    
}

extension DeliveryDetailInfoCell {
    
    private func resetAllValue() {
        codeOrderLabel.customFontSize(firstString: "Mã đơn hàng:  ", secondString: "")
        nameCustomerLabel.customFontSize(firstString: "Tên khách hàng:  ", secondString: "")
        addressLabel.customFontSize(firstString: "Địa chỉ:  ", secondString: "")
        motaXKLabel.customFontSize(firstString: "Xuất kho:  ", secondString: "")
        timeGiaoHangLabel.customFontSize(firstString: "Thời gian giao hàng:  ", secondString: "")
        orderLabel.customFontSize(firstString: "Mặt hàng:  ", secondString: "")
    }
}
