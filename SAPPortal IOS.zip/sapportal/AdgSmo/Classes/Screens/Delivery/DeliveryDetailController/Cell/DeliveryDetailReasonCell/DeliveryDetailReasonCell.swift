//
//  DeliveryDetailReasonCell.swift
//  SapPortal
//
//  Created by LuongTiem on 5/20/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class DeliveryDetailReasonCell: UITableViewCell {
    
    @IBOutlet weak var reasonTitleLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var priceTextField: UITextField!
    
    @IBOutlet weak var reasonLabel: UILabel!
    @IBOutlet weak var reasonTextView: UITextView!
    
    @IBOutlet weak var borderView: UIView!
    @IBOutlet weak var feeTypeLabel: UILabel!
    @IBOutlet weak var feeTypeTextField: UITextField!
    
    @IBOutlet weak var kmStartTextField: UITextField!
    @IBOutlet weak var kmEndTextField: UITextField!
    
    var updatePriceHandler: ((String) -> Void)?
    
    var updateReasonHandler: ((String) -> Void)?
    
    var updateFeeTypeHandler: ((Int) -> Void)?
    
    var updateKMHandler: ((Double, Double) -> Void)?
    
    var feeTypes: [FeeType] = []
    var index: Int = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        
        reasonTextView.text = ""
        reasonTextView.layer.cornerRadius = 8
        reasonTextView.layer.masksToBounds = true
        reasonTextView.layer.borderColor = UIColor.lightGray.cgColor
        reasonTextView.layer.borderWidth = 0.5
        reasonTextView.delegate = self
        
        priceTextField.delegate = self
        feeTypeTextField.delegate = self
        kmStartTextField.delegate = self
        kmEndTextField.delegate = self
    }
    
    
    func bindindData(price: Double, reason: String, feeTypes: [FeeType], index: Int, kmStart: String, kmEnd: String, isEdit: Bool = true) {
        
//        priceTextField.isUserInteractionEnabled = isEdit
//        reasonTextView.isUserInteractionEnabled = isEdit
//        feeTypeTextField.isUserInteractionEnabled = isEdit
        
        priceTextField.text = price == 0 ? "" : price.toString
        reasonTextView.text = reason
        kmStartTextField.text = kmStart
        kmEndTextField.text = kmEnd
        self.feeTypes = feeTypes
        self.index = index
        if index != 0 {
            feeTypeTextField.text = self.feeTypes[index].description
        }
    }
    
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        borderView.layer.borderWidth = 1
        borderView.layer.cornerRadius = 16
        borderView.layer.masksToBounds = true
        borderView.layer.borderColor = #colorLiteral(red: 0.2901960784, green: 0.6941176471, blue: 0.7450980392, alpha: 1).cgColor
    }

}

extension DeliveryDetailReasonCell: UITextViewDelegate {
    
    func textViewDidChange(_ textView: UITextView) {
        updateReasonHandler?(textView.text ?? "")
    }
}


extension DeliveryDetailReasonCell: UITextFieldDelegate {
    
    func textFieldDidChangeSelection(_ textField: UITextField) {
        if textField == priceTextField {
            updatePriceHandler?(priceTextField.text ?? "")
        }
    }
    
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//        if let text = textField.text,
//                   let textRange = Range(range, in: text) {
//                   let updatedText = text.replacingCharacters(in: textRange,
//                                                               with: string)
//            print(updatedText)
//        }
//        print(textField.text!)
//        return true
//    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == priceTextField {
            updatePriceHandler?(priceTextField.text ?? "")
        } else if (textField == kmStartTextField || textField == kmEndTextField) {
            if let text = textField.text, let index = text.indexOf(char: "."), text.count - index > 3 {
                let index = text.index(text.startIndex, offsetBy: index + 3)
                let mySubstring = String(text[..<index])
                textField.text = mySubstring
            }
            if let kmS = kmStartTextField.text?.toDouble, let kmE = kmEndTextField.text?.toDouble, let update = updateKMHandler {
                update(kmS, kmE)
            }
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == feeTypeTextField {
            self.endEditing(true)
            let vc: ItemListController = ItemListController(nibName: "ItemListController", bundle: nil)
            vc.listItem = self.feeTypes.map({ $0.description })
            vc.indexSelected = self.index
            
            vc.updateSelectedIndex = { indexSelected in
                self.index = indexSelected
                self.feeTypeTextField.text = self.feeTypes[indexSelected].description
                self.updateFeeTypeHandler?(self.index)
            }
            
            AlertHelperKit.showControllerEntryKit(controller: vc)
        }
    }
}
