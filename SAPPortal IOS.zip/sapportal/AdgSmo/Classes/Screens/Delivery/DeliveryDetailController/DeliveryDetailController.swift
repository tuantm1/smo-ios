//
//  DeliveryDetailController.swift
//  SapPortal
//
//  Created by LuongTiem on 5/20/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import CoreLocation

class DeliveryDetailController: BaseViewController, UINavigationControllerDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var confirmButton: RoundButton!
    @IBOutlet weak var printButton: RoundButton!
    @IBOutlet weak var uploadButton: RoundButton!
    @IBOutlet weak var confirmOKView: UIStackView!
    
    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    var modelData: DeliveryDetailModel?
    
    var stateDeliveryOrder: StateDeliveryOrder! = .unowned
    
    private var priceParams: String = ""
    
    private var reasonParams: String = ""
    
    private var deliveryGetImageModel: DeliveryGetImageModel?
    var feeTypes: [FeeType] = []
    var feeType: FeeType = FeeType()
    var kmStart: Double = 0.0;
    var kmEnd: Double = 0.0;
    
    var image: UIImage?
    
    var isUploadImage: Bool = false
    var locationManager = CLLocationManager()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "ĐƠN HÀNG: \(modelData?.headerModel.ctXK ?? "")"
        self.saveButton.isEnabled = false

        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = UIView()
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 240
        tableView.contentInset.bottom = 40
        
        tableView.register(UINib(nibName: DeliveryDetailInfoCell.className, bundle: nil), forCellReuseIdentifier: DeliveryDetailInfoCell.className)
        tableView.register(UINib(nibName: DeliveryDetailReasonCell.className, bundle: nil), forCellReuseIdentifier: DeliveryDetailReasonCell.className)
        tableView.register(UINib(nibName: DeliveryPhotoCell.className, bundle: nil), forCellReuseIdentifier: DeliveryPhotoCell.className)
        
        confirmOKView.isHidden = stateDeliveryOrder == .notDelivery
        confirmButton.isHidden = stateDeliveryOrder == .delivered
        
        fetchAllData()
        locationManager.delegate = self
        
        
        self.locationManager.requestAlwaysAuthorization();
        self.locationManager.pausesLocationUpdatesAutomatically = false;
        self.locationManager.startUpdatingLocation()
    }


    override func fetchAllData() {
        DeliveryGetImageAPI.init(saleOrder: modelData?.headerModel.saleOrder ?? "").execute(target: self, success: { (response) in
            
            self.deliveryGetImageModel = response.model
            
            self.isUploadImage = !(self.deliveryGetImageModel?.image ?? "").isEmpty
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }) { (error) in
            
        }
        
        GetFeeTypeAPI.init().execute(target: self, success: { (response) in
            self.feeTypes = response.feeTypes
            self.feeTypes.insert(FeeType(), at: 0)
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }) { (error) in
            
        }
    }
    
    @IBAction func saveAction(_ sender: Any) {
        self.view.endEditing(true)
        if (kmStart > kmEnd) {
            AlertHelperKit.showDefaultAlert(message: "Vui lòng nhập đúng thông tin chỉ số kilomet")
            return
        } else if (kmStart * kmEnd == 0 && kmStart + kmEnd != 0) {
            AlertHelperKit.showDefaultAlert(message: "Vui lòng nhập đầy đủ thông tin chỉ số kilomet")
            return
        }
        locationManager.requestLocation()
        if (CLLocationManager.authorizationStatus() == .authorizedWhenInUse ||
        CLLocationManager.authorizationStatus() == .authorizedAlways) {
            if let lat = locationManager.location?.coordinate.latitude, let long = locationManager.location?.coordinate.latitude {
                
                let model =  self.modelData!.deliveryModel.itemDelivery(saleOrder: self.modelData?.headerModel.saleOrder ?? "")

                DeliveryAPI.init(ngayGiao: Date().convertString, maChuyen: "B1", ttGH: "3", feeType: self.feeType.value , feeTypeDesc: self.feeType.description , price: self.priceParams , reason: self.reasonParams , lat: "\(lat)", long: "\(long)", kmStart: "\(self.kmStart)", kmEnd: "\(self.kmEnd)", items: model).execute(target: self, success: { (response) in
                }) { (error) in

                }
            }
           
            
        } else {
            if let bundleId = Bundle.main.bundleIdentifier,
               let url = URL(string: "\(UIApplication.openSettingsURLString)&path=LOCATION/\(bundleId)") {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
    }
    
    @IBAction func confirmAction(_ sender: Any) {
        if (kmStart > kmEnd) {
            AlertHelperKit.showDefaultAlert(message: "Vui lòng nhập đúng thông tin chỉ số kilomet")
            return
        } else if (kmStart * kmEnd == 0 && kmStart + kmEnd != 0) {
            AlertHelperKit.showDefaultAlert(message: "Vui lòng nhập đầy đủ thông tin chỉ số kilomet")
            return
        }
        
        locationManager.requestLocation()
        if (CLLocationManager.authorizationStatus() == .authorizedWhenInUse ||
        CLLocationManager.authorizationStatus() == .authorizedAlways) {
            if let lat = locationManager.location?.coordinate.latitude, let long = locationManager.location?.coordinate.latitude {
                let alertViewController = UIAlertController(title: "Xác nhận", message: "Bạn muốn xác nhận đã giao hàng cho đơn hàng \(modelData?.headerModel.ctXK ?? "")?", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "Có, Xác nhận", style: .default) { _ in


                    let model =  self.modelData!.deliveryModel.itemDelivery(saleOrder: self.modelData?.headerModel.saleOrder ?? "")

                    DeliveryAPI.init(ngayGiao: Date().convertString, maChuyen: "B1", ttGH: "3", feeType: self.feeType.value, feeTypeDesc: self.feeType.description, price: self.priceParams, reason: self.reasonParams, lat: "\(lat)", long: "\(long)", kmStart: "\(self.kmStart)", kmEnd: "\(self.kmEnd)", items: model).execute(target: self, success: { (response) in

                        //self.navigationController?.popViewController(animated: true)
                        // Reload
                        self.stateDeliveryOrder = .delivered
                        self.confirmOKView.isHidden = false
                        self.confirmButton.isHidden = true
                        self.fetchAllData()
                    }) { (error) in

                    }
                }

                let cancelAction = UIAlertAction(title: "Không", style: .cancel) { _ in

                }

                if #available(iOS 13.0, *) {
                    alertViewController.overrideUserInterfaceStyle  = .light
                } else {
                   // Fallback on earlier versions
                }

                alertViewController.addAction(okAction)
                alertViewController.addAction(cancelAction)

                present(alertViewController, animated: true, completion: nil)
            }
           
            
        } else {
            if let bundleId = Bundle.main.bundleIdentifier,
               let url = URL(string: "\(UIApplication.openSettingsURLString)&path=LOCATION/\(bundleId)") {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
    }
    
    
    @IBAction func printAction(_ sender: Any) {
        
        performSegue(withIdentifier: SegueIdentifier.MenuDelivery.showReceiptPrint, sender: modelData?.headerModel)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        switch segue.identifier {
        case SegueIdentifier.MenuDelivery.showReceiptPrint:
            if let model = sender as? DeliveryHeaderModel, let vc = segue.destination as? ReceiptPrintController {
                vc.passModel = model
            }
        default:
            break
        }
    }
    
    @IBAction func uploadAction(_ sender: Any) {
        let pickerVC = UIImagePickerController()
        pickerVC.modalPresentationStyle = .fullScreen
        pickerVC.mediaTypes = ["public.image"]
        if (UIImagePickerController.isSourceTypeAvailable(.camera) == false) {
            pickerVC.sourceType = .photoLibrary
        } else {
            pickerVC.sourceType = .camera
        }
        pickerVC.delegate = self
        present(pickerVC, animated: true)

    }
}

extension DeliveryDetailController : CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first {
            print("Location data received.")
            print(location)
        }
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Failed to get users location.")
    }
}

extension DeliveryDetailController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 2 {
            
        }
    }
}

extension DeliveryDetailController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return isUploadImage ? 3 : 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return 1
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.section {
        case 0:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: DeliveryDetailInfoCell.className) as? DeliveryDetailInfoCell else {
                return UITableViewCell()
            }
            cell.bindingData(model: self.modelData)
            return cell
        case 1:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: DeliveryDetailReasonCell.className) as? DeliveryDetailReasonCell else {
                return UITableViewCell()
            }
        
            let index = self.feeTypes.firstIndex(where: { $0.value == modelData?.headerModel.loaiPhi }) ?? 0
            var price = modelData?.headerModel.chiphiVC ?? 0
            if (!self.priceParams.isEmpty) {
                price = self.priceParams.toDouble
            } else {
                self.priceParams = price.toString
            }
            var reason = modelData?.headerModel.diachiGH3 ?? ""
            if (!self.reasonParams.isEmpty) {
                reason = self.reasonParams
            } else {
                self.reasonParams = reason
            }
            var kmS = modelData?.headerModel.kmStart ?? 0
            if (self.kmStart > 0) {
                kmS = self.kmStart
            } else {
                self.kmStart = kmS
            }
            var kmE = modelData?.headerModel.kmEnd ?? 0
            if (self.kmEnd > 0) {
                kmE = self.kmEnd
            } else {
                self.kmEnd = kmE
            }
            cell.bindindData(price: price,
                             reason: reason,
                             feeTypes: self.feeTypes,
                             index: index,
                             kmStart: "\(kmS)",
                             kmEnd: "\(kmE)",
                             isEdit: stateDeliveryOrder == .notDelivery)
            
            cell.updatePriceHandler = { price in
                self.priceParams = price
                self.saveButton.isEnabled = self.stateDeliveryOrder == .delivered
            }
            
            cell.updateReasonHandler = { reason in
                self.reasonParams = reason
                self.saveButton.isEnabled = self.stateDeliveryOrder == .delivered
            }
            
            cell.updateFeeTypeHandler = { type in
                self.feeType = self.feeTypes[type]
                self.saveButton.isEnabled = self.stateDeliveryOrder == .delivered
            }
            
            cell.updateKMHandler = { (kmS, kmE) in
                self.kmStart = kmS
                self.kmEnd = kmE
                self.saveButton.isEnabled = self.stateDeliveryOrder == .delivered
            }
            
            return cell
        case 2:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: DeliveryPhotoCell.className) as? DeliveryPhotoCell else {
                return UITableViewCell()
            }
            
            // -- update new Image
            if self.image != nil {
                
                cell.photoImage.image = self.image
                
                return cell
            }
            
            
            // -- fill image from to server
            if let rawData = deliveryGetImageModel?.image, let base64String = Data(base64Encoded: rawData) {
                
                 cell.photoImage.image = UIImage(data: base64String)
                
            } else {
                
                 cell.photoImage.image = self.image
            }
           
            
            return cell
        default:
            return UITableViewCell()
        }
    }
    


}


extension DeliveryDetailController: UIImagePickerControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        picker.dismiss(animated: true, completion: nil)
        
        guard let image = info[.originalImage] as? UIImage else {
            return
        }

        self.image = image
        UploadImageAPI.init(orderID: modelData?.headerModel.saleOrder ?? "", image: image).execute(target: self, success: { (response) in
            
            print(response.returnResponse)
            if !self.isUploadImage {
                self.isUploadImage = true
                self.tableView.beginUpdates()
                self.tableView.insertSections(IndexSet([2]), with: .automatic)
                self.tableView.endUpdates()
                
            } else {
                self.tableView.reloadSections(IndexSet([2]), with: .automatic)
            }
            
            self.tableView.scrollToBottom()
            
            
        }) { (error) in
            
            print(error)
        }
        
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
