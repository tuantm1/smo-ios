//
//  DeliveryListCell.swift
//  SapPortal
//
//  Created by LuongTiem on 5/15/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class DeliveryListCell: UITableViewCell {
    
    @IBOutlet weak var codeDeliveryLabel: UILabel!
    @IBOutlet weak var agencyLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var routerLabel: UILabel!
    
    @IBOutlet weak var circleView: UIView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }
    
    
    func bindingData(model: DeliveryHeaderModel) {
        
        codeDeliveryLabel.text = "#\(model.ctXK)"
        agencyLabel.text = model.nguoiNH
        addressLabel.text = getAddress(model)
//        routerLabel.text = model.routerMoTa
        
    }
    
    
    private func getAddress(_ model: DeliveryHeaderModel) -> String {
        
        if model.diachiGH1.isEmpty {
            
            if model.diachiGH2.isEmpty {
                return model.diachiGH3
            }
            
            return model.diachiGH2
            
        } else {
            return model.diachiGH1
        }
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        circleView.layer.cornerRadius = circleView.frame.width/2
        circleView.layer.masksToBounds = true
        circleView.layer.backgroundColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
    }
    
    
}

extension DeliveryListCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    
    private func resetAllValue() {
        codeDeliveryLabel.text = ""
        agencyLabel.text = ""
        addressLabel.text = ""
//        routerLabel.text = ""
    }
}

