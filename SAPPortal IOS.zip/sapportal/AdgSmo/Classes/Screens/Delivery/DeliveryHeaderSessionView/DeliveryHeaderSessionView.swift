//
//  DeliveryHeaderSessionView.swift
//  SapPortal
//
//  Created by LuongTiem on 6/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class DeliveryHeaderSessionView: UITableViewHeaderFooterView {

    @IBOutlet weak var titleHeaderLabel: UILabel!
    @IBOutlet weak var subTitleLabel: UILabel!
    
    
    
    func bindingData(title: String, subTitle: String) {
        titleHeaderLabel.text = title
        subTitleLabel.text = subTitle
    }
    
}
