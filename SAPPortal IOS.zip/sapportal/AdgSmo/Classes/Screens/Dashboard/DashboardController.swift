//
//  DashboardController.swift
//  SapPortal
//
//  Created by LuongTiem on 6/14/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class DashboardController: BaseViewController {

    @IBOutlet weak var tableview: UITableView!
    
    private var listDashboardModel: [DashboardModel] = []
    
    private var lazyLoadFist: Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "TRANG CHỦ"
        
        tableview.rowHeight = UITableView.automaticDimension
        tableview.estimatedRowHeight = 100
        tableview.register(UINib(nibName: DashboardCell.className, bundle: nil), forCellReuseIdentifier: DashboardCell.className)
        tableview.tableFooterView = UIView()
        tableview.backgroundColor = UIColor.white
        tableview.contentInset.top = 8
        
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(refreshTriggerAction(refreshControl:)), for: .valueChanged)
        refreshControl.attributedTitle = NSAttributedString(string: "Cập nhật dữ liệu lúc: \(Date().convertString(formatter: "HH:mm"))")
        tableview.refreshControl = refreshControl
        
    }
    
    
    @objc
    private func refreshTriggerAction(refreshControl: UIRefreshControl) {
        
        refreshControl.endRefreshing()
        
        fetchAllData()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if !lazyLoadFist {
            tableview.refreshControl?.beginRefreshing()
            lazyLoadFist = true
        }
        
        fetchAllData()
    }
    
    
    override func fetchAllData() {
        super.fetchAllData()
        
        DashboardAPI.init(idUser: MenuManager.shared.userID).execute(target: self, success: { (response) in
            
            self.listDashboardModel = response.listDashboard
            
            DispatchQueue.main.async {
                self.tableview.reloadData()
                self.tableview.refreshControl?.endRefreshing()
            }
            
        }) { (error) in
            
        }
    }
    
}

extension DashboardController: UITableViewDelegate {
    
    
}

extension DashboardController: UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return listDashboardModel.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: DashboardCell.className, for: indexPath) as? DashboardCell else {
            return UITableViewCell()
        }
        
        cell.bindingData(model: listDashboardModel[indexPath.row],
                         color: MenuManager.shared.randomColor(item: indexPath.row, totalItem: listDashboardModel.count))
        
        return cell
    }
    
}
