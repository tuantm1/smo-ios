//
//  DashboardCell.swift
//  SapPortal
//
//  Created by LuongTiem on 6/14/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class DashboardCell: UITableViewCell {
    
    @IBOutlet weak var titleDashboardLabel: UILabel!
    @IBOutlet weak var valueDashboardLabel: UILabel!
    @IBOutlet weak var borderView: ShadowView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
        
    }
    
    
    
    func bindingData(model: DashboardModel, color: UIColor) {
        
        titleDashboardLabel.text = model.text.uppercased()
        valueDashboardLabel.text = model.value.trimZeroCharacter
        
        borderView.backgroundColor = color
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
//        borderView.layer.borderColor = UIColor.white.cgColor
//        borderView.layer.borderWidth = 1
//        borderView.layer.cornerRadius = 16
//        borderView.layer.masksToBounds = true
        
    }
    
}

extension DashboardCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }

    
    private func resetAllValue() {
        titleDashboardLabel.text = ""
        valueDashboardLabel.text = ""
    }
}
