//
//  AccountProfileCell.swift
//  SapPortal
//
//  Created by LuongTiem on 2/27/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class AccountProfileCell: UITableViewCell {
    
    @IBOutlet weak var titleAccountProfileLabel: UILabel!
    @IBOutlet weak var nameAccountLabel: UILabel!
    @IBOutlet weak var nameAccountContentLabel: UILabel!
    
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var passwordContentLabel: UILabel!
    
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var descriptionContentLabel: UILabel!
    
    @IBOutlet weak var groupAccountLabel: UILabel!
    @IBOutlet weak var groupAccountContentLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }
    
    
    func bindingData(model: UserModel?) {
        
        guard let model = model else { return }
        
        nameAccountContentLabel.text = model.username
        passwordContentLabel.text = "*****"//model.password
        descriptionContentLabel.text = model.description
        groupAccountContentLabel.text = UserModel.getAccountType(model: model)
    }
    
    
    
}

extension AccountProfileCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    private func resetAllValue() {
        nameAccountContentLabel.text = ""
        passwordContentLabel.text = ""
        descriptionContentLabel.text = ""
        groupAccountContentLabel.text = ""
        
    }
}
