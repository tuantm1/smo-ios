//
//  MenuAccountCell.swift
//  SapPortal
//
//  Created by LuongTiem on 4/22/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class MenuAccountCell: UITableViewCell {
    
    @IBOutlet weak var itemLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
    func bindingData(name: String) {
        
        itemLabel.text = name
    }
    
}


extension MenuAccountCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        itemLabel.text = ""
    }
}
