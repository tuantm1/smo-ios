//
//  AccountViewController.swift
//  SapPortal
//
//  Created by LuongTiem on 2/26/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import Alamofire

class AccountViewController: UIViewController {
    
    @IBOutlet weak var tableview: UITableView!
    
    let listMenu = MenuManager.shared.menuAccount
    
    var user: UserDetailModel? = nil
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = UIStoryboardType.account.title.uppercased()
        
        tableview.register(UINib(nibName: AccountProfileCell.className, bundle: nil), forCellReuseIdentifier: AccountProfileCell.className)
        tableview.register(UINib(nibName: MenuAccountCell.className, bundle: nil), forCellReuseIdentifier: MenuAccountCell.className)
        
        user = MenuManager.shared.userDetail
        if user == nil {
            GetUserDetailAPI.init(userID: MenuManager.shared.userID).execute(target: self, success: { (response) in
                self.user = response.user
                self.tableview.reloadData()
                
            }) { (error) in
                
            }
        }
    }
    
}

extension AccountViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.section == 0 {
            return UITableView.automaticDimension
        }
        
        return 60
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        if indexPath.section == 0 { return }
        
        if indexPath.section == 2 {
            APIConfiguration.reloadAllCacheCookie()
            UIApplication.shared.windows.first?.rootViewController = UIStoryboard.load(.authentication)
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            UIApplication.shared.windows.first?.makeKey()
            
            return
        }
        
        let model = listMenu[indexPath.row]
        
        let menuType: MenuType = MenuType.getMenuType(idMenu: model.idMenu)
        
        switch menuType {
        case .user, .customer:
            performSegue(withIdentifier: SegueIdentifier.Account.pushListAccount, sender: model)
        case .changePassword:
            performSegue(withIdentifier: SegueIdentifier.Account.showForgotPassword, sender: nil)
        default:
            AlertHelperKit.showDefaultAlert(message: "Tính năng đang được cập nhật") {
                
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        switch segue.identifier {
        case SegueIdentifier.Account.pushListAccount:
            if let model = sender as? MenuModel, let vc = segue.destination as? ListAccountController {
                vc.menuModel = model
            }
        default:
            break
        }
    }
}


extension AccountViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 3
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch section {
        case 0:
            return 1
        case 1:
            return listMenu.count
        case 2:
            return 1
        default:
            return 0
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.section {
        case 0:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: AccountProfileCell.className, for: indexPath) as? AccountProfileCell else {
                return UITableViewCell()
            }
            cell.bindingData(model: user?.user)
            
            return cell
        case 1:
            
            guard let cell = tableView.dequeueReusableCell(withIdentifier: MenuAccountCell.className, for: indexPath) as? MenuAccountCell else {
                return UITableViewCell()
            }
            
            cell.bindingData(name: listMenu[indexPath.row].description)
            
            return cell
        default:
            let cell = UITableViewCell()
            cell.textLabel?.text = "Đăng xuất".uppercased()
            cell.textLabel?.textColor = UIColor.red
            return cell
        }
    }
}
