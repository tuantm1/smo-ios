//
//  ForgotPasswordController.swift
//  SapPortal
//
//  Created by LuongTiem on 5/25/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

//private struct ForgotPasswordModel {
//
//    var oldPassword: String = ""
//
//    var newPassword: String = ""
//
//    var confirmNewPassword: String = ""
//
//
//
//
//    func validate() -> String {
//
//        if oldPassword.isEmpty || newPassword.isEmpty || confirmNewPassword.isEmpty {
//            return "Vui lòng nhập đủ các trường"
//        }
//
//
//        if self.newPassword != self.confirmNewPassword {
//            return "Trường mật khẩu mới và xác nhận mật khẩu mới không giống nhau"
//        }
//
//        return ""
//    }
//}


class ForgotPasswordController: BaseViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var oldPasswordLabel: UILabel!
    @IBOutlet weak var oldPasswordTextField: UITextField!
    
    @IBOutlet weak var newPasswordLabel: UILabel!
    @IBOutlet weak var newPasswordTextField: UITextField!
    
    @IBOutlet weak var confirmNewPasswordLabel: UILabel!
    @IBOutlet weak var confirmNewPasswordTextField: UITextField!
    
    
    @IBOutlet weak var saveButton: RoundButton!
    @IBOutlet weak var cancelButton: RoundButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameTextField.isUserInteractionEnabled = false
        nameTextField.text = MenuManager.shared.userDetail.user.username
        
        navigationItem.title = "THAY ĐỔI MẬT KHẨU"
       
    }
    

    @IBAction func saveAction(_ sender: Any) {
        
        
        let model = ForgotPasswordModel(idUser: MenuManager.shared.userDetail.user.userID,
                                        userName: MenuManager.shared.userDetail.user.username,
                                        password: oldPasswordTextField.text ?? "",
                                        newPassword: newPasswordTextField.text ?? "",
                                        reNewPassword: confirmNewPasswordTextField.text ?? "")
        
        if !model.validateModel().isEmpty {
            
            AlertHelperKit.showAlertController(title: "Thông báo", message: model.validateModel(), cancel: "Đồng ý", others: []) { (action, index) in
                
            }
            return
        }
        
        
        /// ---
        
        ForgotPasswordAPI.init(model: model).execute(target: self, success: { (response) in
            
            let verify: Bool = APIConfiguration.verifyResponse(model: response.returnResponse)
            
            let message: String = verify ? "Đổi mật khẩu thành công!" : "Đổi mật khẩu thất bại!"
            
            let buttonTitle: [String] = verify ? ["Đăng nhập lại"] : []
            
            AlertHelperKit.showAlertController(title: "Thông báo", message: message, cancel: "Thoát", others: buttonTitle) { (action, index) in
                
                if index == 1 {
                    
                    APIConfiguration.reloadAllCacheCookie()
                    UIApplication.shared.windows.first?.rootViewController = UIStoryboard.load(.authentication)
                    UIApplication.shared.windows.first?.makeKeyAndVisible()
                    UIApplication.shared.windows.first?.makeKey()
                }
            }
            
        }) { (error) in
            print(error.localizedDescription)
        }

    }
    
    
    
    @IBAction func cancelAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
