//
//  ListAccountController.swift
//  SapPortal
//
//  Created by LuongTiem on 4/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ListAccountController: BaseViewController {
    
    @IBOutlet weak var tableView: UITableView!
       
    var listAccount: [ListAccountModel] = []
    
    var listUserGuarantee: [UserModel] = []
    
    var listUserManager: [UserModel] = []
    
    var menuModel: MenuModel!
    
    
    private var filteredResults: [ListAccountModel] = [] {
        didSet {
            isSearching = true
        }
    }
    
    var isSearching: Bool = false {
        
        didSet {
            if tableView == nil { return }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    private let searchController = UISearchController(searchResultsController: nil)


    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "DANH SÁCH TÀI KHOẢN"

        tableView.register(UINib(nibName: ListAccountCell.className, bundle: nil), forCellReuseIdentifier: ListAccountCell.className)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 240
        tableView.tableFooterView = UIView()
        tableView.keyboardDismissMode = .onDrag
        
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(refreshTriggerAction(refreshControl:)), for: .valueChanged)
        tableView.refreshControl = refreshControl
        
        searchController.delegate = self
        searchController.searchResultsUpdater = self
        searchController.searchBar.autocapitalizationType = .none
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.delegate = self // Monitor when the search button is tapped.
        
        definesPresentationContext = true
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchAllData()
    }
    
    
    @objc
    private func refreshTriggerAction(refreshControl: UIRefreshControl) {
        
        refreshControl.endRefreshing()
        
        fetchAllData()
    }
    
    
    override func fetchAllData() {
        
        let group = DispatchGroup()
        
        group.enter()
        GetListAccountAPI.init(userID: MenuManager.shared.userID, pages: 1).execute(target: self, success: { (response) in
            
            self.listAccount = response.listAccount
            
            /*
            self.listAccount.enumerated().forEach { (index, model) in
                
                if model.parentID != "0000000000" {
                    
                    group.enter()
                    DetailUserAPI.init(userID: model.parentID).execute(target: self, success: { (response) in
                        self.listUserGuarantee.append(response.user)
                        group.leave()
                    }) { (error) in
                        
                    }
                }
                
                if model.parentID2 != "0000000000" {
                    
                    group.enter()
                    DetailUserAPI.init(userID: model.parentID2).execute(target: self, success: { (response) in
                        self.listUserManager.append(response.user)
                        group.leave()
                    }) { (error) in
                        
                    }
                }
                
            }
            */
            group.leave()
            group.notify(queue: DispatchQueue.main) {
                self.tableView.reloadData()
            }
            
        }) { (error) in
            
        }
        
        
    }
}

extension ListAccountController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let items = isSearching ? filteredResults : listAccount
        
        let model = items[indexPath.row]
        
        performSegue(withIdentifier: SegueIdentifier.Account.pushAccountDetail, sender: model)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case SegueIdentifier.Account.pushAccountDetail:
            if let model = sender as? ListAccountModel, let vc = segue.destination as? AccountDetailsController {
                vc.data = model
            }
        default:
            break
        }
    }
}


extension ListAccountController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return isSearching ? filteredResults.count : listAccount.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ListAccountCell.className, for: indexPath) as? ListAccountCell else {
            return UITableViewCell()
        }
        
        let items = isSearching ? filteredResults : listAccount
        
        let model = items[indexPath.row]
        
//        let userGuarantee = listUserGuarantee.first { $0.userID == model.parentID }
//
//        let userManager = listUserManager.first { $0.userID == model.parentID2 }
        
        cell.bindingData(model: model, userGuarantee: nil, userManager: nil)
    
        return cell
    }
}



// MARK: SEARCH

extension ListAccountController {
    
    private func findMatches(searchString: String = "") -> NSCompoundPredicate {
        
        var searchItemsPredicate: [NSPredicate] = []
        
        let titleExpression: NSExpression = NSExpression(forKeyPath: "username")
        let searchStringExpression = NSExpression(forConstantValue: searchString)
        
        let titleSearchComparisonPredicate = NSComparisonPredicate(leftExpression: titleExpression,
                                                                   rightExpression: searchStringExpression,
                                                                   modifier: .direct,
                                                                   type: .contains,
                                                                   options: [.caseInsensitive, .diacriticInsensitive])
        
        searchItemsPredicate.append(titleSearchComparisonPredicate)
        
        
        var finalCompoundPredicate: NSCompoundPredicate!
        
        finalCompoundPredicate = NSCompoundPredicate(orPredicateWithSubpredicates: searchItemsPredicate)
        
        return finalCompoundPredicate
    }
    
}

extension ListAccountController: UISearchResultsUpdating {
    
    func updateSearchResults(for searchController: UISearchController) {
        
        let searchResults = listAccount
        
        let strippedString = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        
        let searchItems = strippedString.components(separatedBy: " ") as [String]
        
        // Build all the "AND" expressions for each value in searchString.
        let andMatchPredicates: [NSPredicate] = searchItems.map { searchString in
            findMatches(searchString: searchString)
        }
        
        let finalCompoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: andMatchPredicates)
        
        filteredResults = searchResults.filter { finalCompoundPredicate.evaluate(with: $0) }
    }
    
}


extension ListAccountController: UISearchControllerDelegate {

    func didDismissSearchController(_ searchController: UISearchController) {
        isSearching = false
    }
    
    
    func willPresentSearchController(_ searchController: UISearchController) {
        
        isSearching = true
    }
}


extension ListAccountController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        updateSearchResults(for: searchController)
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
    }
}
