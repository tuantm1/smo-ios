//
//  ListAccountCell.swift
//  SapPortal
//
//  Created by LuongTiem on 4/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ListAccountCell: UITableViewCell {
    
    @IBOutlet weak var borderView: UIView!
    
    @IBOutlet weak var codeAccountLabel: UILabel!
    @IBOutlet weak var codeAccountContentLabel: UILabel!
    
    @IBOutlet weak var nameAccountLabel: UILabel!
    @IBOutlet weak var nameAccountContentLabel: UILabel!
    
    @IBOutlet weak var nameUserLabel: UILabel!
    @IBOutlet weak var nameUserContentLabel: UILabel!
    
    @IBOutlet weak var accountTypeLabel: UILabel!
    @IBOutlet weak var accountTypeContentLabel: UILabel!
    
    @IBOutlet weak var accountManagerLabel: UILabel!
    @IBOutlet weak var accountManagerContentLabel: UILabel!
    
    @IBOutlet weak var accountCreditLabel: UILabel!
    @IBOutlet weak var accountCreditContentLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        borderView.layer.cornerRadius = 10
        borderView.layer.masksToBounds = true
        borderView.layer.borderWidth = 0.5
        borderView.layer.borderColor = UIColor.lightGray.cgColor
    }

    
    func bindingData(model: ListAccountModel, userGuarantee: UserModel?, userManager: UserModel?) {
        
        codeAccountContentLabel.text = model.idUser
        nameAccountContentLabel.text = model.username
        nameUserContentLabel.text = model.descriptions
        accountTypeContentLabel.text = ListAccountModel.getAccountType(model: model)
        accountManagerContentLabel.text = userManager?.username
        accountCreditContentLabel.text = userGuarantee?.username
    }
    
    
    
}

extension ListAccountCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    
    private func resetAllValue() {
        codeAccountContentLabel.text = ""
        nameAccountContentLabel.text = ""
        nameUserContentLabel.text = ""
        accountTypeContentLabel.text = ""
        accountManagerContentLabel.text = ""
        accountCreditContentLabel.text = ""
    }
}
