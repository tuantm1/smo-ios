//
//  AccountDetailCell.swift
//  SapPortal
//
//  Created by LuongTiem on 5/4/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class AccountDetailCell: UITableViewCell {
    
    @IBOutlet weak var accountLabel: UILabel!
    @IBOutlet weak var accountContentLabel: UILabel!
    
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var passwordContentLabel: UILabel!
    
    @IBOutlet weak var nameUserLabel: UILabel!
    @IBOutlet weak var nameUserContentLabel: UILabel!
    
    @IBOutlet weak var groupAccountLabel: UILabel!
    @IBOutlet weak var groupAccountContentLabel: UILabel!
    
    @IBOutlet weak var accountTypeLabel: UILabel!
    @IBOutlet weak var accountTypeContentLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }

    
    func bindingData(model: UserModel, userGroup: UserGroupModel?) {
        
        accountContentLabel.text = model.username
        passwordContentLabel.text = "****"//model.password
        nameUserContentLabel.text = model.description
        groupAccountContentLabel.text = userGroup?.name
        accountTypeContentLabel.text = UserModel.getAccountType(model: model)
    }
    
   
}

extension AccountDetailCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    
    
    private func resetAllValue() {
        accountContentLabel.text = ""
        passwordContentLabel.text = ""
        nameUserContentLabel.text = ""
        groupAccountContentLabel.text = ""
        accountTypeContentLabel.text = ""
    }
}
