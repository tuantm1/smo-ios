//
//  AccountDetailsController.swift
//  SapPortal
//
//  Created by LuongTiem on 5/4/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class AccountDetailsController: BaseViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var data: ListAccountModel!
    
    private var accountDetailModel: UserDetailModel = UserDetailModel()
    
    private var listUserGroup: [UserGroupModel] = []
    
    private var listTitleHeader: [String] = ["THÔNG TIN TÀI KHOẢN", "DANH SÁCH TÀI KHOẢN ĐƯỢC BẢO LÃNH", "DANH SÁCH TÀI KHOẢN ĐƯỢC QUẢN LÝ"]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "THÔNG TIN KHÁCH HÀNG"
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 150
        tableView.tableFooterView = UIView()
        tableView.register(UINib(nibName: HeaderTitleView.className, bundle: nil), forCellReuseIdentifier: HeaderTitleView.className)
    
    }
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        fetchAllData()
        
    }
   
    
    override func fetchAllData() {
        
        let group = DispatchGroup()
        
        group.enter()
        GetUserDetailAPI.init(userID: data.idUser).execute(target: self, success: { (response) in
            self.accountDetailModel = response.user
            group.leave()
        }) { (error) in
            
            group.leave()
        }
        
        group.enter()
        GetUserGroupAPI.init().execute(target: self, success: { (response) in
            self.listUserGroup = response.listUserGroup
            group.leave()
            
        }) { (error) in
            group.leave()
        }
        
        
        group.notify(queue: DispatchQueue.main) {
            self.tableView.reloadData()
        }
    }
    
}

extension AccountDetailsController: UITableViewDelegate {
    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//
//        switch section {
//        case 1 where accountDetailModel.userU.isEmpty:
//            return ""
//        case 2 where accountDetailModel.userK.isEmpty:
//            return ""
//        default:
//            return listTitleHeader[section]
//        }
//    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        switch section {
        case 1 where accountDetailModel.userU.isEmpty:
            return 0.000001
        case 2 where accountDetailModel.userK.isEmpty:
            return 0.000001
        default:
            return 44
        }
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView: HeaderTitleView = HeaderTitleView.fromNib()
        
        let title = listTitleHeader[section]
        
        switch section {
        case 1 where accountDetailModel.userU.isEmpty:
            return nil
        case 2 where accountDetailModel.userK.isEmpty:
            return nil
        default:
            headerView.bindingData(title: title, background: #colorLiteral(red: 0, green: 0.3568627451, blue: 0.5882352941, alpha: 1), titleColor: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
            return headerView
        }
    }
}


extension AccountDetailsController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        if accountDetailModel.userU.isEmpty && accountDetailModel.userK.isEmpty {
            return 1
        }
        
        return 3
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        switch section {
        case 0:
            return 1
        case 1:
            return accountDetailModel.userU.count
        default:
            return accountDetailModel.userK.count
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.section {
        case 0:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: AccountDetailCell.className, for: indexPath) as? AccountDetailCell else {
                return UITableViewCell()
            }
            
            let model: UserModel = accountDetailModel.user
            let userGroup: UserGroupModel? = self.listUserGroup.first { $0.idGroup == model.idGR }
            
            cell.bindingData(model: model, userGroup: userGroup)
            
            return cell
        case 1:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: ListAccountGuaranteeCell.className, for: indexPath) as? ListAccountGuaranteeCell else {
                return UITableViewCell()
            }
            cell.bindingData(model: accountDetailModel.userU[indexPath.row])
            
            return cell
        default:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: ListAccountGuaranteeCell.className, for: indexPath) as? ListAccountGuaranteeCell else {
                return UITableViewCell()
            }
            cell.bindingData(model: accountDetailModel.userK[indexPath.row])
            
            return cell
        }
    }
}
