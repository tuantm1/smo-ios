//
//  ListAccountGuaranteeCell.swift
//  SapPortal
//
//  Created by LuongTiem on 5/4/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ListAccountGuaranteeCell: UITableViewCell {
    
    @IBOutlet weak var codeAccountLabel: UILabel!
    @IBOutlet weak var codeAccountContentLabel: UILabel!
    
    @IBOutlet weak var nameAccountLabel: UILabel!
    @IBOutlet weak var nameAccountContentLabel: UILabel!
    
    @IBOutlet weak var accountTypeLabel: UILabel!
    @IBOutlet weak var accountTypeContentLabel: UILabel!
    
    @IBOutlet weak var borderView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }
    
    
    func bindingData(model: UserModel) {
        codeAccountContentLabel.text = model.userID
        nameAccountContentLabel.text = model.username
        accountTypeContentLabel.text = UserModel.getAccountType(model: model)
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        borderView.layer.cornerRadius = 10
        borderView.layer.masksToBounds = true
        borderView.layer.borderWidth = 0.5
        borderView.layer.borderColor = UIColor.lightGray.cgColor
    }

}



extension ListAccountGuaranteeCell {
    
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    
    private func resetAllValue() {
        codeAccountContentLabel.text = ""
        nameAccountContentLabel.text = ""
        accountTypeContentLabel.text = ""
    }
}
