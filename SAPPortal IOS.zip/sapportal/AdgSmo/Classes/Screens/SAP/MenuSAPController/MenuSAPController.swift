//
//  MenuSAPController.swift
//  SapPortal
//
//  Created by LuongTiem on 4/23/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class MenuSAPController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    let listMenu: [MenuModel] = MenuManager.shared.menuSAP
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = UIStoryboardType.sap.title.uppercased()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.contentInset = UIEdgeInsets(top: 16, left: 0, bottom: 0, right: 0)
        collectionView.register(UINib(nibName: MenuOrderCollectionCell.className, bundle: nil),
                                forCellWithReuseIdentifier: MenuOrderCollectionCell.className)
        
        
        if listMenu.isEmpty {
            displayWarningLabel(message: "Tài khoản bị giới hạn quyền truy cập mục")
        }
        
    }

}


extension MenuSAPController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let model = listMenu[indexPath.row]
        
        let menuType: MenuType = MenuType.getMenuType(idMenu: model.idMenu)
        
        switch menuType {
        case .material:
            performSegue(withIdentifier: SegueIdentifier.MenuSAP.listItemSap, sender: model)
        case .customer:
            performSegue(withIdentifier: SegueIdentifier.MenuSAP.pushCustomerLiabilities, sender: model)
        case .condition:
            break
        default:
            break
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        switch segue.identifier {
        case SegueIdentifier.MenuSAP.listItemSap:
            if let model = sender as? MenuModel, let vc = segue.destination as? ListItemSapController {
                vc.menuModel = model
            }
        default:
            break
        }
    }
    
}


extension MenuSAPController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 8
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let height = max(100, collectionView.frame.height/4)
        
        return CGSize(width: collectionView.frame.width, height: height)
    }
    
}


extension MenuSAPController: UICollectionViewDataSource {
    

    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listMenu.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MenuOrderCollectionCell.className,
                                                      for: indexPath) as! MenuOrderCollectionCell
        cell.bindingData(name: listMenu[indexPath.row].description)
        cell.shadowView.backgroundColor = MenuManager.shared.randomColor(item: indexPath.row, totalItem: listMenu.count)
        return cell
    }
    
    
    
}
