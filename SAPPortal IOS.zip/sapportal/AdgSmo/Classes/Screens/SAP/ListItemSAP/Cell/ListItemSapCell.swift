//
//  ListItemSapCell.swift
//  SapPortal
//
//  Created by LuongTiem on 4/24/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ListItemSapCell: UITableViewCell {
    
    @IBOutlet weak var codeItemLabel: UILabel!
    @IBOutlet weak var codeItemContentLabel: UILabel!
    @IBOutlet weak var nameItemLabel: UILabel!
    @IBOutlet weak var borderView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }
    
    
    func bindingData(model: ItemSapModel) {
        codeItemLabel.text = "Mã vật tư"
        codeItemContentLabel.text = model.matnr
        nameItemLabel.customFontSize(firstString: "Tên vật tư:  ", secondString: model.maktg)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        borderView.layer.cornerRadius = 10
        borderView.layer.masksToBounds = true
        borderView.layer.borderWidth = 0.5
        borderView.layer.borderColor = UIColor.lightGray.cgColor
    }
    
}


extension ListItemSapCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    
    private func resetAllValue() {
        codeItemLabel.text = ""
        nameItemLabel.text = ""
    }
}
