//
//  ListItemSapController.swift
//  SapPortal
//
//  Created by LuongTiem on 4/24/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ListItemSapController: BaseViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    private var listItem: [ItemSapModel] = []
    
    private var filteredResults: [ItemSapModel] = [] {
        didSet {
            isSearching = true
        }
    }
    
    var menuModel: MenuModel!
    
    var isSearching: Bool = false {
        
        didSet {
            if tableView == nil { return }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    private let searchController = UISearchController(searchResultsController: nil)
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = menuModel.description
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = UIView()
        tableView.register(UINib(nibName: ListItemSapCell.className, bundle: nil), forCellReuseIdentifier: ListItemSapCell.className)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 80
        tableView.keyboardDismissMode = .onDrag
        
        searchController.delegate = self
        searchController.searchResultsUpdater = self
        searchController.searchBar.autocapitalizationType = .none
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.delegate = self // Monitor when the search button is tapped.
        
        definesPresentationContext = true
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
    
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        GetItemsSapAPI.init(userID: MenuManager.shared.userID).execute(target: self, success: { (response) in
            
            self.listItem = response.maras
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }) { (error) in
            
        }
    }


}


extension ListItemSapController: UITableViewDelegate {
    
    
}


extension ListItemSapController: UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isSearching ? filteredResults.count : listItem.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: ListItemSapCell.className, for: indexPath) as? ListItemSapCell else {
            return UITableViewCell()
        }
        
        let items = isSearching ? filteredResults : listItem
        let model = items[indexPath.row]
        
        cell.bindingData(model: model)
        
        return cell
    }
}


// MARK: SEARCH

extension ListItemSapController {
    
    private func findMatches(searchString: String = "") -> NSCompoundPredicate {
        
        var searchItemsPredicate: [NSPredicate] = []
        
        let titleExpression: NSExpression = NSExpression(forKeyPath: "maktg")
        let searchStringExpression = NSExpression(forConstantValue: searchString)
        
        let titleSearchComparisonPredicate = NSComparisonPredicate(leftExpression: titleExpression,
                                                                   rightExpression: searchStringExpression,
                                                                   modifier: .direct,
                                                                   type: .contains,
                                                                   options: [.caseInsensitive, .diacriticInsensitive])
        
        searchItemsPredicate.append(titleSearchComparisonPredicate)
        
        
        var finalCompoundPredicate: NSCompoundPredicate!
        
        finalCompoundPredicate = NSCompoundPredicate(orPredicateWithSubpredicates: searchItemsPredicate)
        
        return finalCompoundPredicate
    }
    
}

extension ListItemSapController: UISearchResultsUpdating {
    
    func updateSearchResults(for searchController: UISearchController) {
        
        let searchResults = listItem
        
        let strippedString = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        
        let searchItems = strippedString.components(separatedBy: " ") as [String]
        
        // Build all the "AND" expressions for each value in searchString.
        let andMatchPredicates: [NSPredicate] = searchItems.map { searchString in
            findMatches(searchString: searchString)
        }
        
        let finalCompoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: andMatchPredicates)
        
        filteredResults = searchResults.filter { finalCompoundPredicate.evaluate(with: $0) }
    }
    
}


extension ListItemSapController: UISearchControllerDelegate {

    func didDismissSearchController(_ searchController: UISearchController) {
        isSearching = false
    }
    
    
    func willPresentSearchController(_ searchController: UISearchController) {
        
        isSearching = true
    }
}


extension ListItemSapController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        updateSearchResults(for: searchController)
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
    }
}
