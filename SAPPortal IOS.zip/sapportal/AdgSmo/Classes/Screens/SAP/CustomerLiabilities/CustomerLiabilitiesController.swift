//
//  CustomerLiabilitiesController.swift
//  SapPortal
//
//  Created by LuongTiem on 6/2/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class CustomerLiabilitiesController: BaseViewController {
    
    @IBOutlet weak var tableview: UITableView!
    
    var menuModel: MenuModel!
    
    private var listCustomer: [CustomerLiabilitiesModel] = []
    
    private var filteredResults: [CustomerLiabilitiesModel] = [] {
        didSet {
            isSearching = true
        }
    }
    
    var isSearching: Bool = false {
        
        didSet {
            if tableview == nil { return }
            DispatchQueue.main.async {
                self.tableview.reloadData()
            }
        }
    }
    
    private let searchController = UISearchController(searchResultsController: nil)
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "DANH SÁCH KHÁCH HÀNG"
        
        tableview.delegate = self
        tableview.dataSource = self
        tableview.tableFooterView = UIView()
        tableview.register(UINib(nibName: CustomerLiabilitiesCell.className, bundle: nil), forCellReuseIdentifier: CustomerLiabilitiesCell.className)
        tableview.rowHeight = UITableView.automaticDimension
        tableview.estimatedRowHeight = 250
        tableview.keyboardDismissMode = .onDrag
        
        searchController.delegate = self
        searchController.searchResultsUpdater = self
        searchController.searchBar.autocapitalizationType = .none
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.delegate = self // Monitor when the search button is tapped.
        
        definesPresentationContext = true
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchAllData()
    }

    
    override func fetchAllData() {
        super.fetchAllData()
        
        CustomerLiabilitiesAPI.init(userID: MenuManager.shared.userID).execute(target: self, success: { (response) in
            
            self.listCustomer = response.customers
            
            DispatchQueue.main.async {
                self.tableview.reloadData()
            }
        }) { (error) in
            
        }
    }

}


extension CustomerLiabilitiesController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        let items = isSearching ? filteredResults : listCustomer
        
        performSegue(withIdentifier: SegueIdentifier.MenuSAP.pushDetailCustomerLiabilities, sender: items[indexPath.row])
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case SegueIdentifier.MenuSAP.pushDetailCustomerLiabilities:
            if let model = sender as? CustomerLiabilitiesModel, let vc = segue.destination as? CustomerLiabilitiesDetailController {
                vc.passData = model
            }
        default:
            break
        }
    }
    
}


extension CustomerLiabilitiesController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isSearching ? filteredResults.count : listCustomer.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: CustomerLiabilitiesCell.className, for: indexPath) as? CustomerLiabilitiesCell else {
            return UITableViewCell()
        }
        
        let items = isSearching ? filteredResults : listCustomer
        
        cell.bindingData(model: items[indexPath.row])
        
        return cell
    }
    
    
    
}


// MARK: SEARCH

extension CustomerLiabilitiesController {
    
    private func findMatches(searchString: String = "") -> NSCompoundPredicate {
        
        var searchItemsPredicate: [NSPredicate] = []
        
        let titleExpression: NSExpression = NSExpression(forKeyPath: "customerName")
        let searchStringExpression = NSExpression(forConstantValue: searchString)
        
        let titleSearchComparisonPredicate = NSComparisonPredicate(leftExpression: titleExpression,
                                                                   rightExpression: searchStringExpression,
                                                                   modifier: .direct,
                                                                   type: .contains,
                                                                   options: [.caseInsensitive, .diacriticInsensitive])
        
        searchItemsPredicate.append(titleSearchComparisonPredicate)
        
        
        var finalCompoundPredicate: NSCompoundPredicate!
        
        finalCompoundPredicate = NSCompoundPredicate(orPredicateWithSubpredicates: searchItemsPredicate)
        
        return finalCompoundPredicate
    }
    
}

extension CustomerLiabilitiesController: UISearchResultsUpdating {
    
    func updateSearchResults(for searchController: UISearchController) {
        
        let searchResults = listCustomer
        
        let strippedString = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        
        let searchItems = strippedString.components(separatedBy: " ") as [String]
        
        // Build all the "AND" expressions for each value in searchString.
        let andMatchPredicates: [NSPredicate] = searchItems.map { searchString in
            findMatches(searchString: searchString)
        }
        
        let finalCompoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: andMatchPredicates)
        
        filteredResults = searchResults.filter { finalCompoundPredicate.evaluate(with: $0) }
    }
    
}


extension CustomerLiabilitiesController: UISearchControllerDelegate {
    
    func didDismissSearchController(_ searchController: UISearchController) {
        isSearching = false
    }
    
    
    func willPresentSearchController(_ searchController: UISearchController) {
        
        isSearching = true
    }
}


extension CustomerLiabilitiesController: UISearchBarDelegate {
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        updateSearchResults(for: searchController)
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {

    }
}
