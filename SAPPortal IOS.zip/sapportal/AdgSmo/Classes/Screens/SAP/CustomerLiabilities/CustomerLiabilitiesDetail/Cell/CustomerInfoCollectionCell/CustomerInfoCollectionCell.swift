//
//  CustomerInfoCollectionCell.swift
//  SapPortal
//
//  Created by LuongTiem on 2/27/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class CustomerInfoCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var userCodeContentLabel: UILabel!
    @IBOutlet weak var nameUserContentLabel: UILabel!
    @IBOutlet weak var emailContentLabel: UILabel!
    @IBOutlet weak var faxContentLabel: UILabel!
    @IBOutlet weak var phoneContentLabel: UILabel!
    @IBOutlet weak var mobilePhoneContentLabel: UILabel!
    @IBOutlet weak var addressContentLabel: UILabel!
    @IBOutlet weak var paymentTermContentLabel: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        userCodeContentLabel.text = ""
        nameUserContentLabel.text = ""
        emailContentLabel.text = ""
        faxContentLabel.text = ""
        phoneContentLabel.text = ""
        mobilePhoneContentLabel.text = ""
        addressContentLabel.text = ""
        paymentTermContentLabel.text = ""
        
    }

    
    func bindingData(model: CustomerDetailModel) {
        
        userCodeContentLabel.customFontSize(firstString: "Mã khách hàng:    ", firstFont: UIFont.systemFont(ofSize: 15),
                                            secondString: model.kunnr, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        nameUserContentLabel.customFontSize(firstString: "Tên khách hàng:    ", firstFont: UIFont.systemFont(ofSize: 15),
                                            secondString: model.customerName, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        emailContentLabel.customFontSize(firstString: "Email:   ", firstFont: UIFont.systemFont(ofSize: 15),
                                         secondString: model.email, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        faxContentLabel.customFontSize(firstString: "Fax:   ", firstFont: UIFont.systemFont(ofSize: 15),
                                       secondString: model.faxNumber, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        phoneContentLabel.customFontSize(firstString: "Tel Phone:   ", firstFont: UIFont.systemFont(ofSize: 15),
                                         secondString: model.telNumber, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        mobilePhoneContentLabel.customFontSize(firstString: "Mobile Phone:   ", firstFont: UIFont.systemFont(ofSize: 15),
                                               secondString: model.mobileNumber, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        addressContentLabel.customFontSize(firstString: "Địa chỉ:   ", firstFont: UIFont.systemFont(ofSize: 15),
                                           secondString: model.address, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        paymentTermContentLabel.customFontSize(firstString: "Chính sách thanh toán:   ", firstFont: UIFont.systemFont(ofSize: 15),
                                               secondString: model.term, secondFont: UIFont.boldSystemFont(ofSize: 15))
    }
}
