//
//  CreditCell.swift
//  SapPortal
//
//  Created by LuongTiem on 6/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class CreditCell: UITableViewCell {
    
    @IBOutlet weak var businessLabel: UILabel!
    @IBOutlet weak var levelCreditLabel: UILabel!
    @IBOutlet weak var liabilitiesLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }

    
    func bindingData(creditModel: CreditModel) {
        
        businessLabel.customFontSize(firstString: "Ngành hàng:  ", firstFont: UIFont.systemFont(ofSize: 15),
                                     secondString: creditModel.division, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        levelCreditLabel.customFontSize(firstString: "Hạn mức (VNĐ):  ", firstFont: UIFont.systemFont(ofSize: 15),
                                        secondString: "\(creditModel.value)", secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        liabilitiesLabel.customFontSize(firstString: "Công nợ hiện tại (VNĐ):  ", firstFont: UIFont.systemFont(ofSize: 15),
                                        secondString: "\(creditModel.value1)", secondFont: UIFont.boldSystemFont(ofSize: 15))
    }
    
}

extension CreditCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
    }
    
    private func resetAllValue() {
        businessLabel.text = ""
        levelCreditLabel.text = ""
        liabilitiesLabel.text = ""
    }
}
