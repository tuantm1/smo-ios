//
//  CustomerLiabilitiesDetailController.swift
//  SapPortal
//
//  Created by LuongTiem on 6/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class CustomerLiabilitiesDetailController: BaseViewController {
    
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    
    let titles = ["Thông tin khách hàng", "Tín dụng & Công nợ"]
    
    var passData: CustomerLiabilitiesModel!
    
    private var customerDetailModel: CustomerDetailModel?
    
    private lazy var pageTitleView: PageTitleView = { [weak self] in
        let titleView = PageTitleView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50), titles: titles)
        titleView.delegate = self
        
        return titleView
        }()
    
    private var isForbidScrollDelegate : Bool = false
    
    private var startOffsetX : CGFloat = 0.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "THÔNG TIN CHI TIẾT"
        
        menuView.addSubview(pageTitleView)
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: CustomerInfoCollectionCell.className, bundle: nil), forCellWithReuseIdentifier: CustomerInfoCollectionCell.className)
        collectionView.register(UINib(nibName: CreditCollectionCell.className, bundle: nil), forCellWithReuseIdentifier: CreditCollectionCell.className)
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchAllData()
    }
    
    
    
    override func fetchAllData() {
        super.fetchAllData()
        
        GetCustomerDetailAPI.init(kunnr: passData.kunnr).execute(target: self, success: { response in
            
            self.customerDetailModel = response.customerDetailModel
            
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        }) { (error) in
            
        }
        
    }
    
    
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        
        isForbidScrollDelegate = false
        
        startOffsetX = scrollView.contentOffset.x
    }
    
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        if isForbidScrollDelegate { return }
        
        var progress : CGFloat = 0.0
        var sourceIndex : Int = 0
        var targetIndex : Int = 0
        
        let currentOffsetX = scrollView.contentOffset.x
        let scrollViewW = scrollView.frame.width
        
        if currentOffsetX > startOffsetX {
            
            progress = currentOffsetX / scrollViewW - floor(currentOffsetX / scrollViewW)
            
            sourceIndex = Int(currentOffsetX / scrollViewW)
            
            targetIndex = sourceIndex + 1
            if targetIndex >= titles.count {
                targetIndex = titles.count - 1
            }
            
            if currentOffsetX - startOffsetX == scrollViewW {
                progress = 1
                targetIndex = sourceIndex
            }
            
        } else {
            
            progress = 1 - (currentOffsetX / scrollViewW - floor(currentOffsetX / scrollViewW))
            
            targetIndex = Int(currentOffsetX / scrollViewW)
            
            sourceIndex = targetIndex + 1
            if sourceIndex >= titles.count {
                sourceIndex = titles.count - 1
            }
            
        }
        
        pageTitleView.setTitleWithProgress(progress: progress, sourceIndex: sourceIndex, targetIndex: targetIndex)
    }
    
}

extension CustomerLiabilitiesDetailController: PageTitleViewDelegate {
    
    func pageTitleView(titleView: PageTitleView, selectedIndex: Int) {
        
        isForbidScrollDelegate = true
        
        let offsetX = CGFloat(selectedIndex) * collectionView.frame.width
        collectionView.setContentOffset(CGPoint(x: offsetX, y: 0), animated: true)
    }
    
}

extension CustomerLiabilitiesDetailController: UICollectionViewDelegate {
    
    
}


extension CustomerLiabilitiesDetailController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: collectionView.bounds.width, height: collectionView.bounds.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}


extension CustomerLiabilitiesDetailController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return titles.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        switch indexPath.row {
        case 0:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CustomerInfoCollectionCell.className, for: indexPath) as! CustomerInfoCollectionCell
            
            if let model = customerDetailModel {
                cell.bindingData(model: model)
            }
            
            return cell
        default:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CreditCollectionCell.className, for: indexPath) as! CreditCollectionCell
            
            if let model = customerDetailModel {
                cell.bindingData(model: model)
            }

            return cell
        }
    }
}

