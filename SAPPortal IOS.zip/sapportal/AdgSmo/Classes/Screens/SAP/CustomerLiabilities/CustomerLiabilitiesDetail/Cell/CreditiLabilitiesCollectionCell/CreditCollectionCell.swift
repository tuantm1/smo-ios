//
//  CreditCollectionCell.swift
//  SapPortal
//
//  Created by LuongTiem on 2/27/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class CreditCollectionCell: UICollectionViewCell {

    @IBOutlet weak var tableview: UITableView!
    
    private var listCredit: [CreditModel] = []
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        tableview.delegate = self
        tableview.dataSource = self
        tableview.tableFooterView = UIView()
        tableview.register(UINib(nibName: CreditCell.className, bundle: nil), forCellReuseIdentifier: CreditCell.className)
    }
    
    
    func bindingData(model: CustomerDetailModel) {
        
        self.listCredit = model.creditModel
        
        DispatchQueue.main.async {
            self.tableview.reloadData()
        }
    }

}

extension CreditCollectionCell: UITableViewDelegate {
    
    
}


extension CreditCollectionCell: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listCredit.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: CreditCell.className, for: indexPath) as? CreditCell else {
            return UITableViewCell()
        }
        
        cell.bindingData(creditModel: listCredit[indexPath.row])
        
        return cell
    }
}
