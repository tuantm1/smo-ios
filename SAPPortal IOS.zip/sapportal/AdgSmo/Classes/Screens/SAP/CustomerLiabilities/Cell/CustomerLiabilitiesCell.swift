//
//  CustomerLiabilitiesCell.swift
//  SapPortal
//
//  Created by LuongTiem on 6/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class CustomerLiabilitiesCell: UITableViewCell {
    
    @IBOutlet weak var numberCustomerLabel: UILabel!
    @IBOutlet weak var numberCustomerContentLabel: UILabel!
    
    @IBOutlet weak var nameCustomerLabel: UILabel!
    
    @IBOutlet weak var taxLabel: UILabel!
    @IBOutlet weak var taxContentLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var emailContentLabel: UILabel!
    
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var phoneContentLabel: UILabel!
    
    @IBOutlet weak var addressLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
        resetAllValue()
    }

    
    func bindingData(model: CustomerLiabilitiesModel) {
        
        
        numberCustomerLabel.customFontSize(firstString: "Mã số khách hàng:  ", firstFont: UIFont.systemFont(ofSize: 15),
                                         secondString: model.kunnr, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        nameCustomerLabel.customFontSize(firstString: "Tên khách hàng:  ", firstFont: UIFont.systemFont(ofSize: 15),
                                         secondString: model.customerName, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        taxLabel.customFontSize(firstString: "Mã số thuế:  ", firstFont: UIFont.systemFont(ofSize: 15),
                                secondString: model.vatNumber, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        emailLabel.customFontSize(firstString: "Địa chỉ email:  ", firstFont: UIFont.systemFont(ofSize: 15),
                                  secondString: model.email, secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        phoneLabel.customFontSize(firstString: "Số điện thoại:  ", firstFont: UIFont.systemFont(ofSize: 15),
                                  secondString: displayPhoneNumber(model: model), secondFont: UIFont.boldSystemFont(ofSize: 15))
        
        addressLabel.customFontSize(firstString: "Địa chỉ:  ", firstFont: UIFont.systemFont(ofSize: 15),
                                    secondString: model.address, secondFont: UIFont.boldSystemFont(ofSize: 15))
    }
    
    
    private func displayPhoneNumber(model: CustomerLiabilitiesModel) -> String {
        
        if !model.sdt.isEmpty {
            return model.sdt
        }
        
        if !model.telNumber.isEmpty {
            return model.telNumber
        }
        
        if !model.faxNumber.isEmpty {
            return model.faxNumber
        }
        
        if !model.faxNumber.isEmpty {
            return model.faxNumber
        }
        
        
        return model.mobileNumber
    }
    
}

extension CustomerLiabilitiesCell {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        resetAllValue()
    }
    
    private func resetAllValue() {
        numberCustomerLabel.text = ""
        numberCustomerContentLabel.text = ""
        nameCustomerLabel.text = ""
        taxLabel.text = ""
        taxContentLabel.text = ""
        emailLabel.text = ""
        emailContentLabel.text = ""
        phoneLabel.text = ""
        phoneContentLabel.text = ""
        addressLabel.text = ""
    }
}
