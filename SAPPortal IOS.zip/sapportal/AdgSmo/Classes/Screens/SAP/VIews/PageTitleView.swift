//
//  PageTitleView.swift
//  SapPortal
//
//  Created by LuongTiem on 2/27/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

extension UIColor {
    
    var redValue: CGFloat {
        return CIColor(color: self).red
    }
    
    var greenValue: CGFloat {
        return CIColor(color: self).green
    }
    
    var blueValue: CGFloat {
        return CIColor(color: self).blue
    }
    
    var alphaValue: CGFloat{
        return CIColor(color: self).alpha
    }
}

private let scrollLineHeight: CGFloat = 2.0
//private let normalColor : (CGFloat, CGFloat, CGFloat) = (85, 85, 85)
//private let kSelectColor : (CGFloat, CGFloat, CGFloat) = (255, 128, 0)
private let normalColor: UIColor = #colorLiteral(red: 0.3333333333, green: 0.3333333333, blue: 0.3333333333, alpha: 1)
private let selectColor: UIColor = #colorLiteral(red: 1, green: 0.5019607843, blue: 0, alpha: 1)



protocol PageTitleViewDelegate {
    func pageTitleView(titleView: PageTitleView, selectedIndex: Int)
}

class PageTitleView: UIView {

    // comment favorites
    private var currentIndex: Int = 0
    
    private var titles: [String] = []
    
    var delegate: PageTitleViewDelegate?
    
    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.scrollsToTop = false
        scrollView.bounces = false
        return scrollView
    }()
    
    private lazy var listTitleLabel : [UILabel] = [UILabel]()
    
    private lazy var scrollLineView: UIView = {
        let scrollLine = UIView()
        scrollLine.backgroundColor = UIColor.orange
        
        return scrollLine
    }()
    
    
    // -- update new frame
    var updateFrame: CGRect = .zero {
        didSet {
            subviews.forEach { $0.removeFromSuperview() }
            setupUI()
        }
    }
    
    
    init(frame: CGRect, titles: [String]) {
        
        self.titles = titles
        
        super.init(frame: frame)
        
        setupUI()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
}


extension PageTitleView {
    
    private func setupUI() {
        
        addSubview(scrollView)
        scrollView.frame = bounds
        
        setupTitleLabel()
        setupBottomMenuAndScrollLine()
        
        let separatorLine = UIView()
        separatorLine.backgroundColor = UIColor.lightGray
        separatorLine.translatesAutoresizingMaskIntoConstraints = false
        addSubview(separatorLine)
        
        separatorLine.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        separatorLine.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        separatorLine.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        separatorLine.widthAnchor.constraint(equalToConstant: 0.5).isActive = true
    }
}

extension PageTitleView {
    
    private func setupTitleLabel() {
        
        let widthLabel: CGFloat = frame.width / CGFloat(titles.count)
        
        let heightLabel: CGFloat = frame.height - scrollLineHeight //--
        
        let positionY: CGFloat = 0.0
        
        titles.enumerated().forEach { (offset, title) in
            
            let label = UILabel()
            
            label.text = title
            label.tag = offset
            label.font = UIFont.systemFont(ofSize: 16)
            label.minimumScaleFactor = 0.5
            label.numberOfLines = 2
            label.textColor = normalColor
            label.textAlignment = .center
            
            let labelX = widthLabel * CGFloat(offset) // position X of label
            label.frame = CGRect(x: labelX, y: positionY, width: widthLabel, height: heightLabel)
            
            scrollView.addSubview(label)
            listTitleLabel.append(label)
            
            //-- action
            label.isUserInteractionEnabled = true
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(titleLabelAction(_:)))
            label.addGestureRecognizer(tapGesture)
        }
    }
    
    
    private func setupBottomMenuAndScrollLine() {
        
        let bottomLine = UIView()
        bottomLine.backgroundColor = .lightGray
        let heightLine: CGFloat = 0.5
        bottomLine.frame = CGRect(x: 0, y: frame.height - heightLine, width: frame.width, height: heightLine)
        addSubview(bottomLine)
        
        guard let firstLabel = listTitleLabel.first else {
            return
        }
        
        firstLabel.textColor = selectColor
        scrollView.addSubview(scrollLineView)
        scrollLineView.frame = CGRect(x: firstLabel.frame.origin.x,
                                  y: frame.height - scrollLineHeight,
                                  width: firstLabel.frame.width,
                                  height: scrollLineHeight)
    }
    
    
    func setTitleWithProgress(progress: CGFloat, sourceIndex: Int, targetIndex: Int) {
        
        let sourceLabel = listTitleLabel[sourceIndex]
        let targetLabel = listTitleLabel[targetIndex]
        
        let moveTotalX = targetLabel.frame.origin.x - sourceLabel.frame.origin.x
        let moveX = moveTotalX * progress
        scrollLineView.frame.origin.x = sourceLabel.frame.origin.x + moveX
        
        let colorDelta = (red: selectColor.redValue - normalColor.redValue,
                          green: selectColor.greenValue - normalColor.greenValue,
                          blue: selectColor.blueValue - normalColor.blueValue)
        
        sourceLabel.textColor = UIColor(red: selectColor.redValue - colorDelta.red * progress,
                                        green: selectColor.greenValue - colorDelta.green * progress,
                                        blue: selectColor.blueValue - colorDelta.blue * progress,
                                        alpha: 1)
        
        targetLabel.textColor = UIColor(red: normalColor.redValue + colorDelta.red * progress,
                                        green: normalColor.greenValue + colorDelta.green * progress,
                                        blue: normalColor.blueValue + colorDelta.blue * progress,
                                        alpha: 1)
    
        currentIndex = targetIndex
    }
}


// MARK: Action
extension PageTitleView {
    
    @objc private func titleLabelAction(_ tapGesture: UITapGestureRecognizer) {
        
        guard let currentLabel = tapGesture.view as? UILabel else {
            return
        }
        
        if currentLabel.tag == currentIndex { return }
        
        let oldLabel = listTitleLabel[currentIndex]
        
        // config color title label
        currentLabel.textColor = selectColor
        oldLabel.textColor = normalColor
        
        currentIndex = currentLabel.tag
        
        let scrollLinePosition = CGFloat(currentLabel.tag) * scrollLineView.frame.width
        UIView.animate(withDuration: 0.15) {
            self.scrollLineView.frame.origin.x = scrollLinePosition
        }
        
        delegate?.pageTitleView(titleView: self, selectedIndex: currentIndex)
    }
}
