//
//  TabBarController.swift
//  SapPortal
//
//  Created by LuongTiem on 2/26/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class TabBarController: UITabBarController {
    
//    private var tabBarType: [UIStoryboardType] = [.dashboard, .order, .sap, .delivery, .account]

    override func viewDidLoad() {
        super.viewDidLoad()
        delegate = self
        setupViewControllers()
        
    }

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if #available(iOS 13.0, *) {
            overrideUserInterfaceStyle  = .light
        } else {
            // Fallback on earlier versions
        }
        setNeedsStatusBarAppearanceUpdate()
                
        self.view.backgroundColor = UIColor.white
    }
    
    
    private func setupViewControllers() {
        
//        if MenuManager.shared.menuSAP.isEmpty && MenuManager.shared.menuOrder.isEmpty {
//            
//            let tabBarType: [UIStoryboardType] = [.dashboard, .delivery, .account]
//            
//            self.viewControllers = tabBarType.map { $0.rootVC }
//            
//            return
//        }
        
        var tabBarType: [UIStoryboardType] = [.dashboard]
        
        if !MenuManager.shared.menuOrder.isEmpty {
            tabBarType.append(.order)
        }
        
        if !MenuManager.shared.menuSAP.isEmpty {
            tabBarType.append(.sap)
        }
        
        tabBarType.append(contentsOf: [.delivery, .account])
        
        self.viewControllers = tabBarType.map { $0.rootVC }
    }
    
}

extension TabBarController: UITabBarControllerDelegate {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
