//
//  BaseViewController.swift
//  SapPortal
//
//  Created by LuongTiem on 5/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import SwiftEntryKit

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if #available(iOS 13.0, *) {
            overrideUserInterfaceStyle = .light
        } else {
            // Fallback on earlier versions
        }
        
//        customBackButton()
    }
    
    
    // -- this load all data base
    func fetchAllData() {
        
    }
    
    
    private func customBackButton() {
        let backButton = UIBarButtonItem(image: #imageLiteral(resourceName: "back"), style: .plain, target: navigationController, action: #selector(UINavigationController.popViewController(animated:)))
        navigationItem.leftBarButtonItem = backButton
        navigationController?.interactivePopGestureRecognizer?.delegate = self
    }

}

extension BaseViewController {
    
    
    /*
    func showRejectForm(model: OrderModel) {
        
        var attributes: EKAttributes = EKAttributes()
        attributes = .float
        attributes.displayMode = .light
        attributes.windowLevel = .normal
        attributes.position = .center
        attributes.displayDuration = .infinity
        attributes.entranceAnimation = .init(
            translate: .init(
                duration: 0.65,
                anchorPosition: .bottom,
                spring: .init(damping: 1, initialVelocity: 0)
            )
        )
        attributes.exitAnimation = .init(
            translate: .init(
                duration: 0.65,
                anchorPosition: .top,
                spring: .init(damping: 1, initialVelocity: 0)
            )
        )
        attributes.popBehavior = .animated(
            animation: .init(
                translate: .init(
                    duration: 0.65,
                    spring: .init(damping: 1, initialVelocity: 0)
                )
            )
        )
        attributes.entryInteraction = .absorbTouches
        attributes.screenInteraction = .dismiss
        attributes.entryBackground = .color(color: .standardBackground)
        attributes.screenBackground = .color(color: .dimmedLightBackground)
        attributes.border = .value(
            color: UIColor(white: 0.6, alpha: 1),
            width: 1
        )
        attributes.shadow = .active(
            with: .init(
                color: .black,
                opacity: 0.3,
                radius: 3
            )
        )
        attributes.scroll = .enabled(
            swipeable: false,
            pullbackAnimation: .jolt
        )
        attributes.statusBar = .light
        attributes.positionConstraints.keyboardRelation = .bind(
            offset: .init(
                bottom: 15,
                screenEdgeResistance: 0
            )
        )
        attributes.positionConstraints.maxSize = .init(
            width: .constant(value: UIScreen.main.minEdge),
            height: .intrinsic
        )
        
        let customView: RejectFormView = RejectFormView.fromNib()
        customView.layer.cornerRadius = 10
        customView.layer.masksToBounds = true
        customView.reasonRejectOrder = { reasonReject in
            SwiftEntryKit.dismiss()
            RejectOrderActionAPI.init(userID: model.idUser, orderID: model.idOrder,
                                      reasonReject: reasonReject).execute(target: self, success: { (response) in
                                        self.fetchAllData()

            }) { (error) in

            }
        }
        
        
        SwiftEntryKit.display(entry: customView, using: attributes)
    }
    */
}


extension BaseViewController: UIGestureRecognizerDelegate {
    
    
}
