//
//  SwitchDomainView.swift
//  SapPortal
//
//  Created by LuongTiem on 7/6/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class SwitchDomainView: UIView {
    
    @IBOutlet weak var severNameLabel: UILabel!
    @IBOutlet weak var severNameTextField: UITextField!
    
    @IBOutlet weak var domainLabel: UILabel!
    @IBOutlet weak var domainTextField: UITextField!
    
    @IBOutlet weak var confirmButton: RoundButton!
    
    
    private var isEnableConfirmButton: Bool = false {
        didSet {
            
            confirmButton.isEnabled = isEnableConfirmButton
            
            confirmButton.backgroundColor = isEnableConfirmButton ? UIColor.blue : UIColor.blue.withAlphaComponent(0.5)
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
        severNameTextField.delegate = self
        
        domainTextField.delegate = self
        
        isEnableConfirmButton = true
        
        if let domainName = self.domainTextField {
            domainName.text = SwitchDomainConfig.domainName
        }
        
        if let severName = self.severNameTextField {
            severName.text = SwitchDomainConfig.severName
        }
        
        backgroundColor = UIColor.white
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.layer.cornerRadius = 16
        self.layer.masksToBounds = true
        
        severNameTextField.addPadding(.both(8))
        severNameTextField.placeholderColor = UIColor(white: 0.5, alpha: 1)
        severNameTextField.layer.borderColor = #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
        severNameTextField.layer.borderWidth = 1
        severNameTextField.layer.masksToBounds = true
        severNameTextField.layer.cornerRadius = 8
        severNameTextField.textColor = UIColor.black
        
        domainTextField.addPadding(.both(8))
        domainTextField.placeholderColor = UIColor(white: 0.5, alpha: 1)
        domainTextField.layer.borderColor = #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
        domainTextField.layer.borderWidth = 1
        domainTextField.layer.masksToBounds = true
        domainTextField.layer.cornerRadius = 8
        domainTextField.textColor = UIColor.black
    }
    
    
    @IBAction func confirmAction(_ sender: Any) {
        
        let domainName = (domainTextField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        SwitchDomainConfig.domainName = domainName
        
        let severName = (severNameTextField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        SwitchDomainConfig.severName = severName
        
        
        AlertHelperKit.dismiss()
        
    }
    
}

extension SwitchDomainView: UITextFieldDelegate {
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
//        let domainName = (domainTextField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
//
//        let severName = (severNameTextField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
//
//
//        if severName.isEmpty && domainName.isEmpty {
//
//
//        }
//
//        isEnableConfirmButton = !(severName.isEmpty && domainName.isEmpty)
        
        return true
    }
    
}
