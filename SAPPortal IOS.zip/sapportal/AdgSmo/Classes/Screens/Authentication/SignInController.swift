//
//  SignInController.swift
//  SapPortal
//
//  Created by LuongTiem on 7/7/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class SignInController: UIViewController {
    
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userNameTextField: UITextField!
    
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var backImageView: UIImageView!
    @IBOutlet weak var descriptionTextView: UITextView!
    
    @IBOutlet weak var gradientView: UIView!
    
    @IBOutlet weak var signUpButton: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        userNameTextField.addPadding(UITextField.PaddingSide.left(10))
        userNameTextField.setBorder()
        userNameTextField.placeholder = "Nhập tên đăng nhập"
        userNameTextField.placeholderColor = UIColor(white: 0.5, alpha: 1)
        
        passwordTextField.addPadding(UITextField.PaddingSide.left(10))
        passwordTextField.setBorder()
        passwordTextField.placeholder = "Nhập mật khẩu"
        passwordTextField.placeholderColor = UIColor(white: 0.5, alpha: 1)
        
        descriptionTextView.text = ""
        descriptionTextView.layer.cornerRadius = 10
        descriptionTextView.layer.masksToBounds = true
        descriptionTextView.layer.borderColor = UIColor.white.cgColor
        descriptionTextView.layer.borderWidth = 0.8
        
        let backImage = #imageLiteral(resourceName: "back").withRenderingMode(.alwaysTemplate)
        backImageView.image = backImage
        backImageView.tintColor = UIColor.white
        
        let gradientLayer = self.view.layer.sublayers?.filter { ($0 as? CAGradientLayer) != nil }
        gradientLayer?.forEach { $0.removeFromSuperlayer() }
        
        view.setGradientBackground(colorOne: #colorLiteral(red: 0.4039215686, green: 0.537254902, blue: 0.7764705882, alpha: 1), colorTwo: #colorLiteral(red: 0.1882352941, green: 0.2431372549, blue: 0.5215686275, alpha: 1))
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if #available(iOS 13.0, *) {
            overrideUserInterfaceStyle  = .light
        } else {
           // Fallback on earlier versions
        }
    }
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        
    }

    
    @IBAction func backAction(_ sender: Any) {
        
        navigationController?.popViewController(animated: true)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
//        let gradientLayer = self.view.layer.sublayers?.filter { ($0 as? CAGradientLayer) != nil }
//        gradientLayer?.forEach { $0.removeFromSuperlayer() }
//        
//        self.gradientView.setGradientBackground(colorOne: #colorLiteral(red: 0.4039215686, green: 0.537254902, blue: 0.7764705882, alpha: 1), colorTwo: #colorLiteral(red: 0.1882352941, green: 0.2431372549, blue: 0.5215686275, alpha: 1))
    }
   
    @IBAction func signupAction(_ sender: Any) {
        
        var model: SignupModel = SignupModel()
        
        model.userName = userNameTextField.text ?? ""
        model.password = passwordTextField.text ?? ""
        model.descriptions = descriptionTextView.text ?? ""
        
        
        if model.userName.isEmpty || model.password.isEmpty {
            setupAlertViewController(message: "Vui lòng nhập tên đăng nhập và mật khẩu")
            return
        }
    
        SignupAPI.init(model: model).execute(target: self, success: { (response) in
            AlertHelperKit.showAlertController(title: "Thông báo", message: "Tạo tài khoản thành công", cancel: "Đồng ý", others: nil) { (alertAction, button) in
                self.navigationController?.popViewController(animated: true)
            }
            
        }) { (error) in
             self.setupAlertViewController(message: "Tạo tài khoản bị lỗi, vui lòng thử lại!")
        }
        
    }
    
    
    private func setupAlertViewController(message: String) {
        AlertHelperKit.showAlertController(title: "Thông báo", message: message, cancel: "Đồng ý", others: nil) { (alertAction, button) in
            return
        }
    }
    
}


extension SignInController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
