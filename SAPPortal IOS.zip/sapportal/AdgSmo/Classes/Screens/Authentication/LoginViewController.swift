//
//  LoginViewController.swift
//  SapPortal
//
//  Created by LuongTiem on 3/1/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class LoginViewController: BaseViewController {

    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var gradientView: UIView!
    
    @IBOutlet weak var settingButton: UIButton!
    
    @IBOutlet weak var signUpButton: UIButton!
    
    private var errorSignIn: Bool = false
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userNameTextField.addPadding(UITextField.PaddingSide.left(10))
        userNameTextField.setBorder()
        userNameTextField.placeholder = "Nhập tên đăng nhập"
        userNameTextField.placeholderColor = UIColor(white: 0.5, alpha: 1)
        
        passwordTextField.addPadding(UITextField.PaddingSide.left(10))
        passwordTextField.setBorder()
        passwordTextField.placeholder = "Nhập mật khẩu"
        passwordTextField.placeholderColor = UIColor(white: 0.5, alpha: 1)
        
        
        settingButton.setBackgroundImage(#imageLiteral(resourceName: "settings").withRenderingMode(.alwaysTemplate), for: .normal)
        settingButton.tintColor = UIColor.white
        settingButton.isHidden = true
        
        let signUpTitle = "Đăng Ký"
        
        let attributedString = NSMutableAttributedString(string: signUpTitle)
        
        attributedString.addAttributes([NSAttributedString.Key.underlineStyle : NSUnderlineStyle.single.rawValue,
                                        NSAttributedString.Key.foregroundColor: UIColor.white],
                                       range: NSRange(signUpTitle) ?? NSRange(location: 0, length: signUpTitle.count))
        

        signUpButton.setAttributedTitle(attributedString, for: .normal)
        
        let gradientLayer = self.view.layer.sublayers?.filter { ($0 as? CAGradientLayer) != nil }
        gradientLayer?.forEach { $0.removeFromSuperlayer() }
        
        view.setGradientBackground(colorOne: #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), colorTwo: #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1))

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let userName = UserDefaults.standard.string(forKey: "UserName") {
            userNameTextField.text = userName
        }
    }
    
    
    @IBAction func loginAction(_ sender: Any) {
        
        self.errorSignIn = false
                
        let model = LoginModel(username: userNameTextField.text ?? "",
                               password: passwordTextField.text ?? "")
        
//        let model = LoginModel(username: "ADONG", password: "ABC123456")
//        let model = LoginModel(username: "NTHOA", password: "ABC123456")
        
        if model.username.isEmpty || model.password.isEmpty {
            let alertVC = UIAlertController(title: "Thông báo", message: "Tên đăng nhập hoặc mật khẩu không đúng!", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            alertVC.addAction(okAction)
            if #available(iOS 13.0, *) {
                alertVC.overrideUserInterfaceStyle = .light
            } else {
                // Fallback on earlier versions
            }
            self.present(alertVC, animated: true, completion: nil)
            return
        }
        
        let group: DispatchGroup = DispatchGroup()
        
        // Fetch API 1
        APIUIIndicator.showIndicator()
        group.enter()
        LoginAPI.init(model: model).showIndicator(false).execute(target: self, success: { (response) in
            
            group.leave()
            
            MenuManager.shared.totalListMenu = response.authenticMenu.menu
            MenuManager.shared.userID = response.authenticMenu.idUser
            MenuManager.shared.response = response.returnResponse
            
            AppDataShare.shared.authenModel = response.authenticMenu
            
            // Fetch API 2
            group.enter()
            GetUserDetailAPI.init(userID: MenuManager.shared.userID).showIndicator(false).execute(target: self, success: { (response) in
                MenuManager.shared.userDetail = response.user
                AppDataShare.shared.userDetail = response.user
                group.leave()
            }) { (error) in
                self.errorSignIn = true
                group.leave()
            }
            
        }) { (err) in
            self.errorSignIn = true
            group.leave()
        }
        
        
        
        group.notify(queue: DispatchQueue.main) {
            
            APIUIIndicator.hideIndicator()
            
            if MenuManager.shared.totalListMenu.isEmpty || MenuManager.shared.userID == "0000000000" || self.errorSignIn == true {
                
                AlertHelperKit.showDefaultAlert(message: "Tên đăng nhập hoặc mật khẩu không đúng!") {
                    return
                }
                return
            }
            
            
            UIApplication.shared.windows.first?.rootViewController = UIStoryboard.load(.main)
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            UIApplication.shared.windows.first?.makeKey()
        }
        
    }
    
    
    @IBAction func settingAction(_ sender: Any) {
        
        let switchDomainView: SwitchDomainView = UIView.fromNib()
        
        AlertHelperKit.showSwiftEntryKit(customView: switchDomainView, isDisableTouchScreen: true)
    }
    
    
    @IBAction func signupAction(_ sender: Any) {
        
        performSegue(withIdentifier: SegueIdentifier.Authentication.showSignUp, sender: nil)
    }
    
    
}

extension LoginViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
}
