//
//  Configs.swift
//  SapPortal
//
//  Created by LuongTiem on 2/26/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import Alamofire
import UIKit

enum AccountType {
    
    case admin
    case user
    case fail
    
    
    static func getAccount(userName: String, password: String) -> AccountType {
        
        if userName == "tiemlv" && password == "1" {
            return user
        }
        
        if userName == "trieu" && password == "1" {
            return admin
        }
        
        return fail
    }
}


class AccountRoot {
    
    static let shared: AccountRoot = AccountRoot()
    
    var accountType: AccountType! = .fail
}



func convertRawText(params: Parameters) -> String {
    
    let paramString = params.map { "\"\($0.key)\":" + "\"\($0.value)\""}.joined(separator: ",")

    let result: String = "{" + paramString + "}"
    
    return result
    
}


struct SwitchDomainConfig {
    
    static var severName: String {
        
        get {
            #if DEBUG
            return UserDefaults.standard.string(forKey: "severName") ?? "adg-qas"
            #else
            return UserDefaults.standard.string(forKey: "severName") ?? "adg"
            #endif
        }
        
        set(newSeverName) {
            UserDefaults.standard.set(newSeverName, forKey: "severName")
        }
    }
    
    
    static var domainName: String {
        
        get {
            #if DEBUG
            return UserDefaults.standard.string(forKey: "domainName") ?? "http://103.21.148.147:8011"
            #else
            return UserDefaults.standard.string(forKey: "domainName") ?? "http://103.21.148.146:8000"
            #endif
        }
        
        set(newDomainName) {
            UserDefaults.standard.set(newDomainName, forKey: "domainName")
        }
    }
    
}


class AppDataShare {
    
    static let shared: AppDataShare = AppDataShare()
    
    init() { }
    
    
    var userDetail: UserDetailModel = UserDetailModel()
    
    var authenModel: AuthenticMenuModel = AuthenticMenuModel()
    
    
    
    var createOrderGroup: [CreateOrderDetailSectionHeader] = [
        CreateOrderDetailSectionHeader(title: "Quy Cách".uppercased(), groupID: "01", listCharacteristics: []),
        CreateOrderDetailSectionHeader(title: "Kích Thước".uppercased(), groupID: "02", listCharacteristics: []),
        CreateOrderDetailSectionHeader(title: "Độ cao lắp PC".uppercased(), groupID: "03", listCharacteristics: []),
        CreateOrderDetailSectionHeader(title: "Chiều dài Khung/Trục".uppercased(), groupID: "04", listCharacteristics: []),
        CreateOrderDetailSectionHeader(title: "Chiều dài Khung HKT".uppercased(), groupID: "05", listCharacteristics: []),
        CreateOrderDetailSectionHeader(title: "Trục cửa".uppercased(), groupID: "06", listCharacteristics: []),
        CreateOrderDetailSectionHeader(title: "Bộ tời".uppercased(), groupID: "07", listCharacteristics: []),
        CreateOrderDetailSectionHeader(title: "Ray".uppercased(), groupID: "08", listCharacteristics: []),
        CreateOrderDetailSectionHeader(title: "Giá đỡ".uppercased(), groupID: "09", listCharacteristics: [])
    ]
    
    
    enum CreateOrderKey {
        
        case modelCua
        
        case modelMausac
        
        case botoi
        
        case chonbotoi
        
        case thanhray
        
        case chonthanhray
        
        case width
        
        case height
        
        case loaicua
        
        case soluong
        
        case ktThanh
        
        case soThanh
        
        
        
        var atnam: String {
            switch self {
            case .chonbotoi:
                return "Z_BO_TOI_CLIENT"
            case .chonthanhray:
                return "Z_THANH_RAY_CLIENT"
            case .botoi:
                return "Z_MODEL_BT"
            case .thanhray:
                return "Z_RAY_TL0"
            case .modelCua:
                return "Z_MODEL_CUA"
            case .modelMausac:
                return "Z_MAU_SAC"
            case .width:
                return "Z_WIDTH"
            case .height:
                return "Z_HEIGHT"
            case .loaicua:
                return "Z_LOAI_CUA"
            case .soluong:
                return "Z_SO_LUONG"
            case .ktThanh:
                return "Z_KT_THANH"
            case .soThanh:
                return "Z_SO_THANH"
            }
        }
        
        var smbez: String {
            switch self {
            case .chonbotoi:
                return "Chọn bộ tời"
            case .chonthanhray:
                return "Chọn thanh ray"
            case .botoi:
                return "Loại bộ tời"
            case .thanhray:
                return "Loại ray"
            case .modelCua:
                return ""
            case .modelMausac:
                return ""
            case .width:
                return ""
            case .height:
                return ""
            case .loaicua:
                return ""
            case .soluong:
                return ""
            case .ktThanh:
                return ""
            case .soThanh:
                return ""
            }
        }
        
        
        static func checkListThanhRay(atnam: String) -> Bool {
            
            switch atnam {
            case "Z_RAY_GR", "Z_RAY_KT_SD", "Z_RAY_KT15", "Z_RAY_KT17", "Z_RAY_KT19", "Z_RAY_KT24", "Z_RAY_KHAC", "Z_RAY_TL_SD", "Z_RAY_TL0":
                return true
            default:
                return false
            }
        }
        
        var group: String {
            switch self {
            case .botoi:
                return "07"
            case .chonbotoi:
                return "07"
            case .thanhray:
                return "08"
            case .chonthanhray:
                return "08"
            case .modelCua:
                return "01"
            case .modelMausac:
                return "01"
            case .width:
                return ""
            case .height:
                return ""
            case .loaicua:
                return ""
            case .soluong:
                return ""
            case .ktThanh:
                return ""
            case .soThanh:
                return ""
            }
        }
    }
    
}
