//
//  MenuManager.swift
//  SapPortal
//
//  Created by LuongTiem on 4/22/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import UIKit

enum MenuType {
    
    case unknown
    case user
    case userGroup
    case configTemplate
    case customer
    case material
    
    
    case paymentTerm
    case condition
    case orderType
    
    case orderReturn
    case order
    
    case upload
    
    case credit
    case createUser
    case changePassword
    case authentication
    case createOrder
    case approve
    case createOrderReturn
    case createFix
    case createTemplate
    case createCredit
    
    
    static func getMenuType(idMenu: String) -> MenuType{
        
        switch idMenu {
        case "0000000001":
            return user
        case "0000000002":
            return userGroup
        case "0000000003":
            return configTemplate
        case  "0000000004":
            return customer
        case  "0000000005":
            return material
        case  "0000000006":
            return paymentTerm
        case  "0000000007":
            return condition
        case  "0000000008":
            return orderType
        case  "0000000009":
            return orderReturn
        case  "0000000010":
            return order
        case  "0000000011":
            return upload
        case  "0000000012":
            return credit
        case "0000000013":
            return createUser
        case "0000000014":
            return changePassword
        case "0000000015":
            return authentication
        case "0000000016":
            return createOrder
        case "0000000017":
            return approve
        case "0000000018":
            return createOrderReturn
        case "0000000019":
            return createFix
        case "0000000020":
            return createTemplate
        case "0000000021":
            return createCredit
        default:
            return unknown
        }
    }
}

class MenuManager {
    
    static let shared: MenuManager = MenuManager()
    
    var totalListMenu: [MenuModel] = [] {
        didSet {
            menuAccount = totalListMenu.filter { $0.status == "1" }.sorted(by: { (model1, model2) -> Bool in
                return Double(model1.zIndex) ?? 0 < Double(model2.zIndex) ?? 1
            })
            
            menuOrder = totalListMenu.filter { $0.status == "2"}.sorted(by: { (model1, model2) -> Bool in
                return Double(model1.zIndex) ?? 0 < Double(model2.zIndex) ?? 1
            })
            
            menuSAP = totalListMenu.filter { $0.status == "3" }.sorted(by: { (model1, model2) -> Bool in
                return Double(model1.zIndex) ?? 0 < Double(model2.zIndex) ?? 1
            })
        }
    }
    
    init() { }
    
    
    var menuAccount: [MenuModel] = [] {
        
        didSet {
            
        }
    }
    
    
    var menuOrder: [MenuModel] = []  {
        
        didSet {
            
            self.menuOrder = menuOrder.sorted(by: { (menu1, menu2) -> Bool in
                return menu1.zIndex < menu2.zIndex
            })
        }
    }
    
    
    var menuSAP: [MenuModel] = [] {
        
        didSet {
            
        }
    }
    
    
    var userID: String = ""
    
    
    var userDetail: UserDetailModel! = UserDetailModel() {
        didSet {
            UserDefaults.standard.setValue(userDetail.user.username, forKey: "UserName")
        }
    }
    
    var response: ReturnResponse = ReturnResponse()
    
    
    var loadLazyDashboard: [DashboardModel] = []

    
    
    func randomColor(item: Int, totalItem: Int) -> UIColor {
        
        let listColor: [UIColor] = [#colorLiteral(red: 0.4392156863, green: 0.6784313725, blue: 0.2745098039, alpha: 1), #colorLiteral(red: 0.9568627451, green: 0.6941176471, blue: 0.5137254902, alpha: 1), #colorLiteral(red: 0.6117647059, green: 0.768627451, blue: 0.9019607843, alpha: 1), #colorLiteral(red: 0.9411764706, green: 0.4, blue: 0.2588235294, alpha: 1), #colorLiteral(red: 0.9921568627, green: 0.7215686275, blue: 0.831372549, alpha: 1), #colorLiteral(red: 0.5019607843, green: 0.8901960784, blue: 0.4117647059, alpha: 1), #colorLiteral(red: 0.3882352941, green: 0.9215686275, blue: 0.8470588235, alpha: 1), #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1), #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1), #colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)]
        
        if totalItem > listColor.count {
            
            let indexRandom = totalItem % listColor.count
            
            return listColor[indexRandom]
        }
        
        return listColor[item]
    }
    
    
    
    // MARK: Config domain + sever
    
    var switchDomain: SwitchDomainConfig!
    
}



extension MenuManager {
    
     
}
