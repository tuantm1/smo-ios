//
//  AlertHelperKit.swift
//  SapPortal
//
//  Created by LuongTiem on 6/1/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import UIKit
import SwiftEntryKit

public typealias HandleAlertAction = (_ alertAction: UIAlertAction, _ index: Int) -> Void

class AlertHelperKit {
    
    
    
    
    
}


// MARK: SwiftEntryKit
extension AlertHelperKit {
    
    static func dismiss() {
        
        SwiftEntryKit.dismiss()
    }
    
    
    static func showSwiftEntryKit(customView: UIView, isDisableTouchScreen: Bool = false) {
        
        var attributes: EKAttributes = EKAttributes()
        attributes = .float
        attributes.displayMode = .dark
        attributes.windowLevel = .normal
        attributes.position = .center
        attributes.displayDuration = .infinity
        attributes.entranceAnimation = .init(
            translate: .init(
                duration: 0.65,
                anchorPosition: .bottom,
                spring: .init(damping: 1, initialVelocity: 0)
            )
        )
        attributes.exitAnimation = .init(
            translate: .init(
                duration: 0.65,
                anchorPosition: .automatic,
                spring: .init(damping: 1, initialVelocity: 0)
            )
        )
        attributes.popBehavior = .animated(
            animation: .init(
                translate: .init(
                    duration: 0.65,
                    spring: .init(damping: 1, initialVelocity: 0)
                )
            )
        )
        attributes.entryInteraction = .absorbTouches
        
        if !isDisableTouchScreen {
            attributes.screenInteraction = .dismiss
        }
        
        attributes.entryBackground = .color(color: .standardBackground)
        attributes.screenBackground = .color(color: .dimmedLightBackground)
        attributes.border = .value(
            color: UIColor(white: 0.6, alpha: 1),
            width: 1
        )
        attributes.shadow = .active(
            with: .init(
                color: .black,
                opacity: 0.3,
                radius: 3
            )
        )
        attributes.scroll = .enabled(
            swipeable: false,
            pullbackAnimation: .jolt
        )
        attributes.statusBar = .light
        attributes.positionConstraints.keyboardRelation = .bind(
            offset: .init(
                bottom: 15,
                screenEdgeResistance: 0
            )
        )
        attributes.positionConstraints.maxSize = .init(
            width: .constant(value: UIScreen.main.minEdge),
            height: .intrinsic
        )
        
        SwiftEntryKit.display(entry: customView, using: attributes)
    }
}

extension AlertHelperKit {
    
    static func showControllerEntryKit(controller: UIViewController, isDisableTouchScreen: Bool = false) {
        
        var attributes: EKAttributes = EKAttributes()
        attributes = .bottomFloat
        attributes.displayMode = .light
        attributes.displayDuration = .infinity
        attributes.screenBackground = .color(color: .dimmedLightBackground)
        attributes.entryBackground = .color(color: .white)
        attributes.screenInteraction = .dismiss
        attributes.entryInteraction = .absorbTouches
        attributes.scroll = .edgeCrossingDisabled(swipeable: true)
        attributes.entranceAnimation = .init(
            translate: .init(
                duration: 0.5,
                spring: .init(damping: 1, initialVelocity: 0)
            )
        )
        attributes.exitAnimation = .init(
            translate: .init(duration: 0.35)
        )
        attributes.popBehavior = .animated(
            animation: .init(
                translate: .init(duration: 0.35)
            )
        )
        attributes.shadow = .active(
            with: .init(
                color: .black,
                opacity: 0.3,
                radius: 6
            )
        )
        attributes.positionConstraints.size = .init(
            width: .fill,
            height: .ratio(value: 0.6)
        )
        attributes.positionConstraints.verticalOffset = 0
        attributes.positionConstraints.safeArea = .overridden
        attributes.statusBar = .dark
        attributes.roundCorners = .top(radius: 16)
        
        SwiftEntryKit.display(entry: controller, using: attributes)
    }
}

// MARK: Alert Default System
extension AlertHelperKit {
    
    @discardableResult
    static func showDefaultAlert(message: String, completion: (() -> Void)? = nil) -> UIAlertController {
        // Write your code to show your api error dialog, call completion when done
        // Example:
        let alertVC = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "Đồng ý", style: .cancel, handler: { _ in
            completion?()
        }))
        
        if #available(iOS 13.0, *) {
            alertVC.overrideUserInterfaceStyle = .light
        } else {
            // Fallback on earlier versions
        }
        
        if let topVC = UIApplication.topViewController() {
            if !(topVC is UIAlertController) {
                topVC.present(alertVC, animated: true, completion: nil)
            }
            else {
                self.dismiss(animated: false, completion: {
                    topVC.present(alertVC, animated: true, completion: nil)
                })
            }
        }
        return alertVC
    }
    
    @discardableResult
    public static func showAlertController(title: String?, message: String?, cancel: String?, others: [String]?, handleAction: HandleAlertAction?) -> UIAlertController {
        
        let alertVC = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        let actionCancel = UIAlertAction.init(title: cancel, style: .cancel) { (action) in
            guard let handleAction = handleAction else {
                return
            }
            handleAction(action, 0)
        }
        alertVC.addAction(actionCancel)
        
        if others != nil {
            for (index, title) in others!.enumerated() {
                let action = UIAlertAction.init(title: title, style: .default, handler: { (action) in
                    
                    if handleAction == nil {
                        return
                    }
                    handleAction!(action, index + 1)
                })
                alertVC.addAction(action)
            }
        }
        
        if #available(iOS 13.0, *) {
            alertVC.overrideUserInterfaceStyle = .light
        } else {
            // Fallback on earlier versions
        }
        
        if let topVC = UIApplication.topViewController() {
            if !(topVC is UIAlertController) {
                topVC.present(alertVC, animated: true, completion: nil)
            }
            else {
                self.dismiss(animated: false, completion: {
                    topVC.present(alertVC, animated: true, completion: nil)
                })
            }
        }
        
        return alertVC
    }
    
    
    public static func dismiss(animated: Bool, completion: (() -> Swift.Void)? = nil) {
        if let currentAlertVC = UIApplication.topViewController(),
            currentAlertVC is UIAlertController {
            currentAlertVC.dismiss(animated: animated, completion: {
                if completion != nil {
                    completion!()
                }
            })
        }
    }
    
}
