//
//  AuthenticMenuModel.swift
//  SapPortal
//
//  Created by LuongTiem on 4/21/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct AuthenticMenuModel {
    
    var idUser: String = ""
    
    var username: String = ""
    
    var idPeer: String = ""
    
    var usType: String = ""
    
    var menu: [MenuModel] = []
    
    
    init() {}
    
    init(json: JSON) {
        
        idUser = json["ID_USER"].string ?? ""
        username = json["USERNAME"].string ?? ""
        idPeer = json["ID_PEER"].string ?? ""
        usType = json["US_TYPE"].string ?? ""
        menu = json["MENU"].arrayValue.map { MenuModel(json: $0) }
    }
}


struct MenuModel {
    
    var idMapping: String = ""
    
    var idMenu: String = ""
    
    var name: String = ""
    
    var description: String = ""
    
    var status: String = ""
    
    var zIndex: String = ""
    
    var actions: [ActionModel] = []
    
    
    
    init(json: JSON) {
        
        idMapping = json["ID_MAPPING"].string ?? ""
        idMenu = json["ID_MENU"].string ?? ""
        name = json["NAME"].string ?? ""
        description = json["DESCRIPTION"].string ?? ""
        status = json["ZZSTATUS"].string ?? ""
        actions = json["ACTION"].arrayValue.map { ActionModel(json: $0) }
        zIndex = json["ZINDEX"].string ?? ""
    }
}


// MARK: Handler action menu

enum ActionPermissions {
    
    
    // -- Order Action
    enum ActionOrder {
        
        case getOrder
        case getDetailOrder
        case createOrder
        case updateOrder
        case deleteOrder
        case approveOrder
        
        var functionModule: String {
            switch self {
            case .getOrder:
                return "GET_ORDER"
            case .getDetailOrder:
                return "GET_DETAIL_ORDER"
            case .createOrder:
                return "CREATE_ORDER"
            case .updateOrder:
                return "UPDATE_ORDER"
            case .deleteOrder:
                return "DELETE_ORDER"
            case .approveOrder:
                return "APPROVE_ORDER"
            }
        }
    }
    
    
    // --
}


struct ActionModel {
    
    var idAction: String = ""
    
    var description: String = ""
    
    var functionModule: String = ""
    
    var status: String = ""
    
    
    init(json: JSON) {
        
        idAction = json["ID_ACTION"].string ?? ""
        description = json["DESCRIPTION"].string ?? ""
        functionModule = json["FUNCTIONMODULE"].string ?? ""
        status = json["ZZSTATUS"].string ?? ""
    }
}
