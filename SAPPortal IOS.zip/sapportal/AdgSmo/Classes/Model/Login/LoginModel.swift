//
//  LoginModel.swift
//  SapPortal
//
//  Created by LuongTiem on 4/19/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation

struct LoginModel {
    
    var username: String = "ADMIN"
    
    var password: String = "12"
    
    init(username: String, password: String) {
        self.username = username
        self.password = password
    }
}
