//
//  SignupModel.swift
//  SapPortal
//
//  Created by LuongTiem on 7/7/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct SignupModel {
    
    var userName: String = ""
    
    var password: String = ""
    
    var descriptions: String = ""
    
}
