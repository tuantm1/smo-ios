//
//  GetTempModel.swift
//  SapPortal
//
//  Created by LuongTiem on 7/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct GetTempModel {
    
    var idItem: String = ""
    
    var idUser: String = ""
    
    var idTemplate: String = ""
    
    var name: String = ""
    
    var dc: String = ""
    
    var note: String = ""
    
    var zReturn: String = ""
    
    var items: String = ""
    
    var division: String = ""
    
    var orderType: String = ""
    
    var zTerm: String = ""
    
    var nameShipTo: String = ""
    
    var divisionName: String = ""
    
    var idTempClone: String = ""
    
    
    init() { }
    
    
    init(json: JSON) {
        
        self.idItem = json["ID_ITEM"].string ?? ""
        self.idUser = json["ID_USER"].string ?? ""
        self.idTemplate = json["ID_TEMPLATE"].string ?? ""
        self.name = json["NAME"].string ?? ""
        self.dc = json["DC"].string ?? ""
        self.note = json["NOTE"].string ?? ""
        self.zReturn = json["Z_RETURN"].string ?? ""
        self.items = json["ITEMS"].string ?? ""
        self.division = json["DIVISION"].string ?? ""
        self.orderType = json["ORDER_TYPE"].string ?? ""
        self.zTerm = json["ZTERM"].string ?? ""
        self.nameShipTo = json["NAME_SHIPTO"].string ?? ""
        self.divisionName = json["DIVISION_NAME"].string ?? ""
        self.idTempClone = json["ID_TEMP_CLONE"].string ?? ""
    }
}
