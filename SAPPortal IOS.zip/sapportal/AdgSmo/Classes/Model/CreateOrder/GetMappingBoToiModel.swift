//
//  GetMappingBoToi.swift
//  SapPortal
//
//  Created by LuongTiem on 8/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct GetMappingBoToiModel {
    
    var matnr: String = ""
    
    var atnam: String = ""
    
    var value: String = ""
    
    var maktx: String = ""
    
    init() { }
    
    
    init(json: JSON) {
        self.matnr = json["MATNR"].string ?? ""
        self.atnam = json["ATNAM"].string ?? ""
        self.value = json["VALUE"].string ?? ""
        self.maktx = json["MAKTX"].string ?? ""
    }
}
