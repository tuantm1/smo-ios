//
//  GetCharacteristicModel.swift
//  SapPortal
//
//  Created by LuongTiem on 7/30/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct GetCharacteristicModel {
    
    var atnam: String = ""
    
    var smbez: String = ""
    
    var value1: [GetCharacteristicValue1Model] = []
    
    var value2: [GetCharacteristicValue2Model] = []
    
    var ausp1: String = ""
    
    
    init() {
        
    }
    
    
    
    init(json: JSON) {
        atnam = json["ATNAM"].string ?? ""
        smbez = json["SMBEZ"].string ?? ""
        value1 = json["VALUE1"].arrayValue.map { GetCharacteristicValue1Model(json: $0) }
        value2 = json["VALUE2"].arrayValue.map { GetCharacteristicValue2Model(json: $0)}
        ausp1 = json["AUSP1"].string ?? ""
    }
}


struct GetCharacteristicValue1Model {
    
    var dataType: String = ""
    
    var udefClass: String = ""
    
    var charnumber: String = ""
    
    var decplaces: String = ""
    
    var casesens: String = ""
    
    var displExp: String = ""
    
    var exponent: String = ""
    
    var templace: String = ""
    
    var negVals: String = ""
    
    var unit: String = ""
    
    var status: String = ""
    
    var group: String = ""
    
    var valassignm: String = ""
    
    var noEntry: String = ""
    
    var noDisplay: String = ""
    
    var entryREQ: String = ""
    
    var interv: String = ""
    
    var unformated: String = ""
    
    var propTemplate: String = ""
    
    var displVals: String = ""
    
    var additVals: String = ""
    
    var document: String = ""
    
    var docType: String = ""
    
    var docPart: String = ""
    
    var docVers: String = ""
    
    var authorityGroup: String = ""
    
    
    init() {
        
    }
    
    
    init(json: JSON) {
        
        dataType = json["DATATYPE"].string ?? ""
        udefClass = json["UDEF_CLASS"].string ?? ""
        charnumber = json["CHARNUMBER"].string ?? ""
        decplaces = json["DECPLACES"].string ?? ""
        casesens = json["CASESENS"].string ?? ""
        displExp = json["DISPL_EXP"].string ?? ""
        exponent = json["EXPONENT"].string ?? ""
        templace = json["TEMPLATE"].string ?? ""
        negVals = json["NEG_VALS"].string ?? ""
        unit = json["UNIT"].string ?? ""
        status = json["STATUS"].string ?? ""
        group = json["GROUP"].string ?? ""
        valassignm = json["VALASSIGNM"].string ?? ""
        noEntry = json["NO_ENTRY"].string ?? ""
        noDisplay = json["NO_DISPLAY"].string ?? ""
        entryREQ = json["ENTRY_REQ"].string ?? ""
        interv = json["INTERV"].string ?? ""
        unformated = json["UNFORMATED"].string ?? ""
        propTemplate = json["PROP_TEMPL"].string ?? ""
        displVals = json["DISPL_VALS"].string ?? ""
        additVals = json["ADDIT_VALS"].string ?? ""
        document = json["DOCUMENT"].string ?? ""
        docType = json["DOC_TYPE"].string ?? ""
        docPart = json["DOC_PART"].string ?? ""
        docVers = json["DOC_VERS"].string ?? ""
        authorityGroup = json["AUTHORITY_GROUP"].string ?? ""
    }
}


struct GetCharacteristicValue2Model {
    
    var language: String = ""
    
    var languageISO: String = ""
    
    var valDescr: String = ""
    
    var value: String = ""
    
    
    init() { }
    
    
    init(language: String, languageISO: String, valDescr: String, value: String) {
        self.language = language
        self.languageISO = languageISO
        self.valDescr = valDescr
        self.value = value
    }
    
    
    init(json: JSON) {
        self.language = json["LANGUAGE"].string ?? ""
        self.languageISO = json["LANGUAGE_ISO"].string ?? ""
        self.valDescr = json["VALDESCR"].string ?? ""
        self.value = json["VALUE"].string ?? ""
    }
}
