//
//  CreateOrderModel.swift
//  SapPortal
//
//  Created by LuongTiem on 7/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct SaleORGModel {
    
    var mandt: String = ""
    
    var spras: String = ""
    
    var vkorg: String = ""
    
    var vtext: String = ""
    
    
    init() { }
    
    
    init(json: JSON) {
        
        self.mandt = json["MANDT"].string ?? ""
        self.spras = json["SPRAS"].string ?? ""
        self.vkorg = json["VKORG"].string ?? ""
        self.vtext = json["VTEXT"].string ?? ""
    }
    
}
