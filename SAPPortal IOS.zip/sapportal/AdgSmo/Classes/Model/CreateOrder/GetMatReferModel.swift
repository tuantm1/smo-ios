//
//  GetMatReferModel.swift
//  SapPortal
//
//  Created by LuongTiem on 8/8/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct GetMatReferModel {
    
    var idMatnrRefer: String = ""
    
    var matnr: String = ""
    
    var value: String = ""
    
    var zmbez: String = ""
    
    
    init() { }
    
    
    init(json: JSON) {
        self.idMatnrRefer = json["ID_MATNR_REFER"].string ?? ""
        self.matnr = json["MATNR"].string ?? ""
        self.value = json["VALUE"].string ?? ""
        self.zmbez = json["ZMBEZ"].string ?? ""
    }
}
