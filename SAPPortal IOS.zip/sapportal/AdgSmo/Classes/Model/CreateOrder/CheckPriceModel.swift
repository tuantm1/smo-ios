//
//  CheckPriceModel.swift
//  SapPortal
//
//  Created by LuongTiem on 8/8/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct CheckPriceModel {
    
    var ck: Double = 0
    
    var etKONV: [ETKONV] = []
    
    var etVBap: [ETVBAP] = []
    
    var idOrder: String = ""
    
    var netValue: Double = 0
    
    var stdbl: Double = 0
    
    var tax: Double = 0
    
    var tgtdh: Double = 0
    
    var totalInquiry: Double = 0
    

    init() {}
    
    init(json: JSON) {
        
        self.ck = json["CK"].double ?? 0
        self.etKONV = json["ET_KONV"].arrayValue.map { ETKONV(json: $0) }
        self.etVBap = json["ET_VBAP"].arrayValue.map { ETVBAP(json: $0) }
        
        self.idOrder = json["ID_ORDER"].string ?? ""
        
        self.netValue = json["NET_VALUE"].double ?? 0
        self.stdbl = json["STDBL"].double ?? 0
        self.tax = json["TAX"].double ?? 0
        self.tgtdh = json["TGTDH"].double ?? 0
        self.totalInquiry = json["TOTAL_INQUIRY"].double ?? 0
    }
    
    
}


struct ETKONV {
    
    init(json: JSON) {
        
    }
}


struct ETVBAP {
    
    init(json: JSON) {
        
    }
}

