//
//  GetMappingThanhRayModel.swift
//  SapPortal
//
//  Created by LuongTiem on 8/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct GetMappingThanhRayModel {
    
    var matnr: String = ""
    
    var matnrRefer: String = ""
    
    var atnam: String = ""
    
    var value: String = ""
    
    var descriptions: String = ""
    
    
    init() {
        
    }
    
    
    init(json: JSON) {
        self.matnr = json["MATNR"].string ?? ""
        self.matnrRefer = json["MATNR_REFER"].string ?? ""
        self.atnam = json["ATNAM"].string ?? ""
        self.value = json["VALUE"].string ?? ""
        self.descriptions = json["DESCRIPTION"].string ?? ""
    }
}
