//
//  CreateOrderModel.swift
//  SapPortal
//
//  Created by LuongTiem on 8/9/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct CreateOrderConfirmModel {
    
    var idOrder: String = ""
    
    init() {
        
    }
    
    
    init(json: JSON) {
        self.idOrder = json["ID_ORDER"].string ?? ""
    }
}
