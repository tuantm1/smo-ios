//
//  GetDetailTempModel.swift
//  SapPortal
//
//  Created by LuongTiem on 7/30/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

class GetDetailTempModel {
    
    var idItem: String = ""
    
    var idUser: String = ""
    
    var idTemplate: String = ""
    
    var name: String = ""
    
    var dc: String = ""
    
    var note: String = ""
    
    var zReturn: String = ""
    
    var items: [ItemModelClient] = []
    
    var division: String = ""
    
    var orderType: String = ""
    
    var zTerm: String = ""
    
    var nameShipTo: String = ""
    
    var divisionName: String = ""
    
    var idTempClone: String = ""
    
    var eFlag: String = "" // kiem tra trong tieu chuan va ngoai tieu chuan
    
    
    init() {
        
    }
    
    
    init(json: JSON) {
        idItem = json["ID_ITEM"].string ?? ""
        idUser = json["ID_USER"].string ?? ""
        idTemplate = json["ID_TEMPLATE"].string ?? ""
        name = json["NAME"].string ?? ""
        dc = json["DC"].string ?? ""
        note = json["NOTE"].string ?? ""
        zReturn = json["Z_RETURN"].string ?? ""
        items = json["ITEMS"].arrayValue.map { ItemModelClient(json: $0) }
        division = json["DIVISION"].string ?? ""
        orderType = json["ORDER_TYPE"].string ?? ""
        zTerm = json["ZTERM"].string ?? ""
        nameShipTo = json["NAME_SHIPTO"].string ?? ""
        divisionName = json["DIVISION_NAME"].string ?? ""
        idTempClone = json["ID_TEMP_CLONE"].string ?? ""
    }
}
