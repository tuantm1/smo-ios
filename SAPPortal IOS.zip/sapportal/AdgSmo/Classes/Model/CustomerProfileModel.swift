//
//  CustomerProfileModel.swift
//  SapPortal
//
//  Created by LuongTiem on 2/27/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation

struct CustomerProfileModel {
    
    var id: Int?
    var name: String?
    var phone: String?
    var email: String?
}
