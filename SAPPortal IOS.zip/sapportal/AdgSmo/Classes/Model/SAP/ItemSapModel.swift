//
//  ItemSapModel.swift
//  SapPortal
//
//  Created by LuongTiem on 4/24/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

class ItemSapModel: NSObject {
    
    var matnr: String = ""
    
    @objc var maktg: String = ""
    
    var maktx: String = ""
    
    var meins: String = ""
    
    var matkl: String = ""
    
    var labor: String = ""
 
    
    override init() {
        super.init()
    }
    
    init(json: JSON) {
        matnr = json["MATNR"].string ?? ""
        maktg = json["MAKTG"].string ?? ""
        maktx = json["MAKTX"].string ?? ""
        meins = json["MEINS"].string ?? ""
        matkl = json["MATKL"].string ?? ""
        labor = json["LABOR"].string ?? ""
    }
}


