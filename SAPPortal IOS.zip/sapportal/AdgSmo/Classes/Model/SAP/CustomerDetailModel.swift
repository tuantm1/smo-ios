//
//  CustomerModel.swift
//  SapPortal
//
//  Created by LuongTiem on 6/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

class CustomerDetailModel: CustomerLiabilitiesModel {
    
    var creditModel: [CreditModel] = []
    
    var creditCustomModel: [CreditCustomerModel] = []
    
   
    override init() {
        super.init()
        
    }
    
    
    override init(json: JSON) {
        super.init(json: json)
        
        creditModel = json["CZREDIT"].arrayValue.map { CreditModel(json: $0) }
        
        creditCustomModel = json["ZCREDIT_CUS"].arrayValue.map { CreditCustomerModel(json: $0) }
    }
}


struct CreditModel {
    
    var division: String = ""
    
    var value: Double = 0
    
    var cs: String = ""
    
    var value1: Double = 0
    
    
    init(json: JSON) {
        
        division = json["DIVISION"].string ?? ""
        value = json["VALUE"].double ?? 0
        cs = json["CS"].string ?? ""
        value1 = json["VALUE1"].double ?? 0
    }
}


struct CreditCustomerModel {
    
    var amount: Double = 0
    
    var cs: String = ""
    
    
    init(json: JSON) {
        amount = json["Z_AMOUNT_L"].double ?? 0
        cs = json["CS"].string ?? ""
    }
}
