//
//  CustomerModel.swift
//  SapPortal
//
//  Created by LuongTiem on 4/25/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

class CustomerLiabilitiesModel: NSObject {
    
    var kunnr: String = ""
    
    @objc var customerName: String = ""
    
    var address: String = ""
    
    var vatNumber: String = ""
    
    var email: String = ""
    
    var sdt: String = ""
    
    var ktokd: String = ""
    
    var vkorg: String = ""
    
    var vtweg: String = ""
    
    var spart: String = ""
    
    var term: String = ""
    
    var mobileNumber: String = ""
    
    var telNumber: String = ""
    
    var faxNumber: String = ""
    
//    var credit:
    
//    var creditCus
    
    var vsart: String = ""
    
    var route: String = ""
    
    var city: String = ""
    
     
    
    
    override init() {
        super.init()
    }
    
    
    
    init(json: JSON) {
        kunnr = json["KUNNR"].string ?? ""
        customerName = json["CUSTOMER_NAME"].string ?? ""
        address = json["ADDRESS"].string ?? ""
        vatNumber = json["VAT_NUMBER"].string ?? ""
        email = json["EMAIL"].string ?? ""
        sdt = json["SDT"].string ?? ""
        ktokd = json["KTOKD"].string ?? ""
        vkorg = json["VKORG"].string ?? ""
        vtweg = json["VTWEG"].string ?? ""
        spart = json["SPART"].string ?? ""
        term = json["ZTERM"].string ?? ""
        mobileNumber = json["MOB_NUMBER"].string ?? ""
        telNumber = json["TEL_NUMBER"].string ?? ""
        faxNumber = json["FAX_NUMBER"].string ?? ""
//        credit = json["CZREDIT"].string ?? ""
//        creditCus = json["ZCREDIT_CUS"].string ?? ""
        vsart = json["VSART"].string ?? ""
        route = json["ROUTE"].string ?? ""
        city = json["CITY"].string ?? ""
    }
}
