//
//  BaseReturnResponse.swift
//  SapPortal
//
//  Created by LuongTiem on 4/21/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct ReturnResponse {
    
    var type: String = ""
    
    var id: String = ""
    
    var number: String = ""
    
    var message: String = ""
    
    var logNo: String = ""
    
    var logMSGNo: String = ""
    
    var measseV1: String = ""
    
    var measseV2: String = ""
    
    var measseV3: String = ""
    
    var measseV4: String = ""
    
    var parameter: String = ""
    
    var row: Int = 0
    
    var field: String = ""
    
    var system: String = ""
    
    var hasResponse: Bool = false /* variable check json parser success */
    
    init() { }
    
    
    
    init(json: JSON) {
        
        type = json["TYPE"].string ?? ""
        id = json["ID"].string ?? ""
        number = json["NUMBER"].string ?? ""
        message = json["MESSAGE"].string ?? ""
        logNo = json["LOG_NO"].string ?? ""
        logMSGNo = json["LOG_MSG_NO"].string ?? ""
        measseV1 = json["MESSAGE_V1"].string ?? ""
        measseV2 = json["MESSAGE_V2"].string ?? ""
        measseV3 = json["MESSAGE_V3"].string ?? ""
        measseV4 = json["MESSAGE_V4"].string ?? ""
        parameter = json["PARAMETER"].string ?? ""
        row = json["ROW"].int ?? 0
        field = json["FIELD"].string ?? ""
        system = json["SYSTEM"].string ?? ""
        
        hasResponse = true //
    }
    
    
}
