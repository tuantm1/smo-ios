//
//  ForgotPasswordModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

struct ForgotPasswordModel {
    
    var idUser: String = ""
    
    var userName: String = ""
    
    var password: String = ""
    
    var newPassword: String = ""
    
    var reNewPassword: String = ""
    
    
    
    func validateModel() -> String {
        
        if password.isEmpty || newPassword.isEmpty || reNewPassword.isEmpty {
            return "Vui lòng nhập đủ các trường"
        }
        
        if newPassword != self.reNewPassword {
            return "Trường mật khẩu mới và xác nhận mật khẩu mới không khớp nhau"
        }
        
        return ""
    }
    
    
    func rawText() -> String {
        
        var parameters: Parameters = [:]
        parameters["id_user"] = self.idUser
        parameters["username"] = self.userName
        parameters["password"] = self.password
        parameters["newPassword"] = self.newPassword
        parameters["reNewPassword"] = self.reNewPassword
        
        
        let user: String = convertRawText(params: parameters)
        
        let result: String = "{\"THEUSER\": \(user)}"
        
        return result
    }
}
