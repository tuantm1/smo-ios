//
//  UserDetailModel.swift
//  SapPortal
//
//  Created by LuongTiem on 4/22/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct UserDetailModel {
    
    var user: UserModel = UserModel()
    
    
    var userK: [UserModel] = []
    
    
    var userU: [UserModel] = []
    
    
    
    init() { }
    
    
    init(json: JSON) {
        
        user = UserModel(json: json["USER"])
        
        userK = json["USERS_K"].arrayValue.map { UserModel(json: $0) }
        
        userU = json["USERS_U"].arrayValue.map { UserModel(json: $0) }
        
    }
    
}


struct UserModel {
    
    var userID: String = ""
    
    var username: String = ""
    
    var password: String = ""
    
    var kunnr: String = ""
    
    var idGR: String = ""
    
    var parentID: String = ""
    
    var parentID2: String = ""
    
    var usType: String = ""
    
    var peerToPeer: String = ""
    
    var description: String = ""
    
    var parentName: String = ""
    
    
    init() { }
    
    
    init(json: JSON) {
        
        userID = json["ID_USER"].string ?? ""
        username = json["USERNAME"].string ?? ""
        password = json["PASSWORD"].string ?? ""
        kunnr = json["KUNNR"].string ?? ""
        idGR = json["ID_GR"].string ?? ""
        parentID = json["PARENT_ID"].string ?? ""
        parentID2 = json["PARENT_ID_2"].string ?? ""
        usType = json["US_TYPE"].string ?? ""
        peerToPeer = json["PEER_TO_PEER"].string ?? ""
        description = json["DESCRIPTION"].string ?? ""
        parentName = json["PARENT_NAME"].string ?? ""
        
    }
    
    
    static func getAccountType(model: UserModel) -> String {
        
        switch model.usType {
        case "K":
            return "Tài Khoản Kinh Doanh"
        case "U":
            return "Tài Khoản Bảo Lãnh"
        case "S":
            return "Tài Khoản Thường"
        default:
            return ""
        }
    }
}
