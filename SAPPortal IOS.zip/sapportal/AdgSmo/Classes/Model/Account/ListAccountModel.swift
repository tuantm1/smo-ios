//
//  ListAccountModel.swift
//  SapPortal
//
//  Created by LuongTiem on 4/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

class ListAccountModel: NSObject {
    
    var mandt: String = ""
    
    var idUser: String = ""
    
    @objc var username: String = ""
    
    var password: String = ""
    
    var parentID: String = ""
    
    var parentID2: String = ""
    
    var kunnr: String = ""
    
    var idGroup: String = ""
    
    var descriptions: String = ""
    
    var usSAP: String = ""
    
    var psSAP: String = ""
    
    var usType: String = ""
    
    var peerToPeer: String = ""
    
    var idPeer: String = ""
    
    
    override init() {
        super.init()
    }
    
    
    init(json: JSON) {
        mandt = json["MANDT"].string ?? ""
        idUser = json["ID_USER"].string ?? ""
        username = json["USERNAME"].string ?? ""
        password = json["PASSWORD"].string ?? ""
        parentID = json["PARENT_ID"].string ?? ""
        parentID2 = json["PARENT_ID_2"].string ?? ""
        kunnr = json["KUNNR"].string ?? ""
        idGroup = json["ID_GR"].string ?? ""
        descriptions = json["DESCRIPTION"].string ?? ""
        usSAP = json["US_SAP"].string ?? ""
        psSAP = json["PS_SAP"].string ?? ""
        usType = json["US_TYPE"].string ?? ""
        peerToPeer = json["PEER_TO_PEER"].string ?? ""
        idPeer = json["ID_PEER"].string ?? ""
    }
    
    
    static func getAccountType(model: ListAccountModel) -> String {
        
        switch model.usType {
        case "K":
            return "Tài Khoản Kinh Doanh"
        case "U":
            return "Tài Khoản Bảo Lãnh"
        case "S":
            return "Tài Khoản Thường"
        default:
            return ""
        }
    }
}

