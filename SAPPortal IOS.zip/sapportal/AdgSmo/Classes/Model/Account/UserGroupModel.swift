//
//  UserGroupModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/5/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct UserGroupModel {
    
    var idGroup: String = ""
    
    var name: String = ""
    
    var type: String = ""
    
    var status: String = ""
    
    var numberOfUser: String = ""
    
    
    init() {
        
    }
    
    
    
    init(json: JSON) {
        
        idGroup = json["ID_GR"].string ?? ""
        name = json["NAME"].string ?? ""
        type = json["TYPE"].string ?? ""
        status = json["ZZSTATUS"].string ?? ""
        numberOfUser = json["NUMBER_OF_USER"].string ?? ""
    }
}
