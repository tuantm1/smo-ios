//
//  DeliveryDetailModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct DeliveryDetailModel {
    
    var deliveryModel: DeliveryModel
    
    var headerModel: DeliveryHeaderModel
}
