//
//  DeliveryModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/21/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON


struct DeliveryModel {
    
    
    var des: String = ""
    
    var status: String = ""
    
    var header: [DeliveryHeaderModel] = []
    
    var item: [DeliveryItemModel] = []
    
    var update: [DeliveryUpdateModel] = []
    
    
    init() { }
    
    
    init(json: JSON) {
        des = json["E_DES"].string ?? ""
        status = json["E_STATUS"].string ?? ""
        header = json["TB_HEADER"].arrayValue.map { DeliveryHeaderModel(json: $0) }
        item = json["TB_ITEM"].arrayValue.map { DeliveryItemModel(json: $0) }
//        update = json["TB_UPDATE"].arrayValue.map { DeliveryUpdateModel(json: $0) }
    }
    
    
    func itemDelivery(saleOrder: String) -> [DeliveryItemModel] {
        
        let filterItem = self.item.filter { $0.saleOrder == saleOrder }
        
        return filterItem
    }
    
}


class DeliveryHeaderModel: NSObject {
    
    var spvc: String = ""
    
    var maxe: String = ""
    
    var machuyen: String = ""
    
    var sttGH: String = ""
    
    var ctXK: String = ""
    
    var saleOrder: String = ""
    
    var saleType: String = ""
    
    @objc var nguoiNH: String = ""
    
    var diachiGH1: String = ""
    
    var diachiGH2: String = ""
    
    var diachiGH3: String = ""
    
    var ddXNK: String = ""
    
    var motaXNK: String = ""
    
    var router: String = ""
    
    var routerMoTa: String = ""
    
    var loaiVC: String = ""
    
    var ngayGH: String = ""
    
    var timeGH: String = ""
    
    var laixe: String = ""
    
    var ttGiaoHang: String = ""
    
    var chiphiVC: Double = 0
    
    var chiphiLK: Double = 0
    
    var loaiTien: String = ""
    
    var loaiPhi: String = ""
    
    var kmStart: Double = 0
    
    var kmEnd: Double = 0
    
    override init() {
        super.init()
    }
    
    
    init(json: JSON) {
        
        spvc = json["SPVC"].string ?? ""
        maxe = json["MAXE"].string ?? ""
        machuyen = json["MACHUYEN"].string ?? ""
        sttGH = json["STT_GH"].string ?? ""
        ctXK = json["CT_XK"].string ?? ""
        saleOrder = json["SALE_ORDER"].string ?? ""
        saleType = json["SALE_TYPE"].string ?? ""
        nguoiNH = json["NGUOI_NH"].string ?? ""
        diachiGH1 = json["DIACHI_GH1"].string ?? ""
        diachiGH2 = json["DIACHI_GH2"].string ?? ""
        diachiGH3 = json["DIACHI_GH3"].string ?? ""
        ddXNK = json["DD_XNK"].string ?? ""
        motaXNK = json["MOTA_XNK"].string ?? ""
        router = json["ROUTER"].string ?? ""
        routerMoTa = json["ROUTE_MOTA"].string ?? ""
        loaiVC = json["LOAI_VC"].string ?? ""
        ngayGH = json["NGAY_GH"].string ?? ""
        timeGH = json["TIME_GH"].string ?? ""
        laixe = json["LAI_XE"].string ?? ""
        ttGiaoHang = json["TT_GIAOHANG"].string ?? ""
        chiphiVC = json["CHIPHI_VC"].double ?? 0
        chiphiLK = json["CHIPHI_LK"].double ?? 0
        loaiTien = json["LOAITIEN"].string ?? ""
        loaiPhi = json["ZZ_LOAIPHI"].string ?? ""
        kmStart = json["ZZ_KM_S"].double ?? 0
        kmEnd = json["ZZ_KM_E"].double ?? 0
    }
    
    
    func getAddress() -> String {
        
        if self.diachiGH1.isEmpty {
            
            if self.diachiGH2.isEmpty {
                return self.diachiGH3
            }
            
            return self.diachiGH2
            
        } else {
            return self.diachiGH1
        }
    }
    
}

struct DeliveryItemModel {
    
    var belnrPVC: String = ""
    
    var buzei: String = ""
    
    var saleOrder: String = ""
    
    var mathang: String = ""
    
    var motaMH: String = ""
    
    var luong: Double = 0
    
    var dvt: String = ""
    
    var chieuCao: Double = 0
    
    var chieuRong: Double = 0
    
    var dienTich: Double = 0
    
    var theTich: Double = 0
    
    var nhomHang: String = ""
    
    var motaNH: String = ""
    
    var loaiCua: String = ""
    
    var tl: String = ""
    
    var kt: String = ""
    
    var khung: String = ""
    
    var ray: String = ""
    
    var trucKT: String = ""
    
    var soBo: Double = 0
    
    var soBo2: Double = 0
    
    var loaiTien: String = ""
    
    
    
    
    init() { }
    
    
    
    init(json: JSON) {
        
        belnrPVC = json["ZZ_BELNR_PVC"].string ?? ""
        buzei = json["ZZ_BUZEI"].string ?? ""
        saleOrder = json["SALE_ORDER"].string ?? ""
        mathang = json["MATHANG"].string ?? ""
        motaMH = json["MOTA_MH"].string ?? ""
        luong = json["LUONG"].double ?? 0
        dvt = json["DVT"].string ?? ""
        chieuCao = json["CHIEU_CAO"].double ?? 0
        chieuRong = json["CHIEU_RONG"].double ?? 0
        dienTich = json["DIEN_TICH"].double ?? 0
        theTich = json["THE_TICH"].double ?? 0
        nhomHang = json["NHOM_HANG"].string ?? ""
        motaNH = json["MOTA_NH"].string ?? ""
        loaiCua = json["LOAI_CUA"].string ?? ""
        tl = json["TL"].string ?? ""
        kt = json["KT"].string ?? ""
        khung = json["KHUNG"].string ?? ""
        ray = json["RAY"].string ?? ""
        trucKT = json["TRUC_KT"].string ?? ""
        soBo = json["SO_BO"].double ?? 0
        soBo2 = json["SO_BO2"].double ?? 0
        loaiTien = json["LOAITIEN"].string ?? ""
        
        
    }
}


struct DeliveryUpdateModel {
    
    var spvc: String = ""
    
    var item: String = ""
    
    var ttGH: String = "3"
    
    var chiphi: String = ""
    
    var lydo: String = ""
    
    var feeType: String = ""
    
    var feeTypeDesc: String = ""
    
    var lat: String = ""
    
    var long: String = ""
    
    var kmStart: String = ""
    
    var kmEnd: String = ""
    
    func convertRawString() -> String {
        
        let raw = "{\"Spvc\": \"\(spvc)\", \"Item\": \"\(item)\", \"TT_GIAOHANG\":\"\(ttGH)\", \"CHI_PHI\" : \"\(chiphi)\", \"ZZ_DIACHI_GH3\" : \"\(lydo)\", \"ZZ_LOAIPHI\" : \"\(feeType)\", \"ZZ_LOAIPHI_DES\" : \"\(feeTypeDesc)\", \"ZZ_LOCATION_LAT\" : \"\(lat)\", \"ZZ_LOCATION_LONG\" : \"\(long)\", \"ZZ_KM_S\" : \"\(kmStart)\", \"ZZ_KM_E\" : \"\(kmEnd)\"}"
        
        return raw
    }
}
