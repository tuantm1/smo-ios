//
//  DeliveryGetImageModel.swift
//  SapPortal
//
//  Created by LuongTiem on 6/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//


import Foundation
import SwiftyJSON

struct DeliveryGetImageModel {
    
    var idOrder: String = ""
    
    var soNumber: String = ""
    
    var image: String = ""
    

    
    init() { }
    
    
    
    init(json: JSON) {
        
        idOrder = json["ID_ORDER"].string ?? ""
        
        soNumber = json["SO_NUMBER"].string ?? ""
        
        image = json["ZIMAGE"].string ?? ""
    }
}
