//
//  DashboardModel.swift
//  SapPortal
//
//  Created by LuongTiem on 6/14/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct DashboardModel {
    
    var text: String = ""
    
    var value: String = ""
    
    
    
    init() { }
    
    
    
    init(json: JSON) {
        
        text = json["TEXT"].string ?? ""
        
        value = json["VALUE"].string ?? ""
    }
}
