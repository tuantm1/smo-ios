//
//  MarasModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct MarasModel {
    
    var labor: String = ""
    
    var maktg: String = ""
    
    var maktx: String = ""
    
    var matkl: String = ""
    
    var matnr: String = ""
    
    var meins: String = ""
    
    var price: Double = 0
    
    var priceAFTax: Double = 0
    
    var zDKGH: String = "" // Dự kiến giao hàng
    
    var extwg: String = "" // Lay zType
    
    
    init() { }
    
    
    init(json: JSON) {
        labor = json["LABOR"].string ?? ""
        maktg = json["MAKTG"].string ?? ""
        maktx = json["MAKTX"].string ?? ""
        matkl = json["MATKL"].string ?? ""
        matnr = json["MATNR"].string ?? ""
        meins = json["MEINS"].string ?? ""
        
        price = json["ZPRICE"].double ?? 0
        priceAFTax = json["ZPRICE_AF_TAX"].double ?? 0
        zDKGH = json["ZDKGH"].string ?? ""
        extwg = json["EXTWG"].string ?? ""
        
    }
    
}

