//
//  OrderModel.swift
//  SapPortal
//
//  Created by LuongTiem on 4/21/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class OrderModel: NSObject {
    
    var idOrder: String = ""
    
    var idUser: String = ""
    
    @objc var name: String = ""
    
    var shiptoID: String = ""
    
    var note: String = ""
    
    var status: String = ""
    
    var date: String = ""
    
    var items: [ItemModel] = []
    
    var createBy: String = ""
    
    var idApprove: String = ""
    
    var createByName: String = ""
    
    var nameApprove: String = ""
        
    var auart: String = ""
        
    var kunnr: String = ""
        
    var zterm: String = ""
    
    @objc var nameShipTo: String = ""
    
    var today: String = ""
    
    var level: String = ""
    
    var dc: String = ""
    
    var division: String = ""
    
    var image: String = ""
    
    var orderType: String = ""
    
    var netValue: Double = 0
    
    
    var type: String = ""
    
    var address: String = ""
    
    var route: String = ""
    
    var vsart: String = ""
    
    var phoneNumber: String = ""
    
    var idU: String = ""
    
    var idK: String = ""
    
    var price: Double = 0
    
    var totalPrice: Double = 0
    
    var ck: Double = 0
    
    var creditValue: Double = 0
    
    var creditValueCustom: Double = 0
    
    var stbl: Double = 0
    
    var tax: Double = 0
    
    var statusBL: String = ""
    
    var stdbl: Double = 0
    
    var ztc: String = ""
    
    
    override init() {
        super.init()
    }
    
    
    
    
    
    init(json: JSON) {
        
        idOrder = json["ID_ORDER"].string ?? ""
        idUser = json["ID_USER"].string ?? ""
        name = json["NAME"].string ?? ""
        shiptoID = json["SHIPTO_ID"].string ?? ""
        note = json["NOTE"].string ?? ""
        status = json["STATUS"].string ?? ""
        date = json["Z_DATE"].string ?? ""
        items = json["ITEMS"].arrayValue.map { ItemModel(json: $0) }
        createBy = json["CREATE_BY"].string ?? ""
        idApprove = json["ID_APPROVE"].string ?? ""
        createByName = json["CREATE_BY_NAME"].string ?? ""
        nameApprove = json["NAME_APPROVE"].string ?? ""
        auart = json["AUART"].string ?? ""
        kunnr = json["KUNNR"].string ?? ""
        zterm = json["ZTERM"].string ?? ""
        nameShipTo = json["NAME_SHIPTO"].string ?? ""
        today = json["TODAY"].string ?? ""
        level = json["ZLEVEL"].string ?? ""
        dc = json["DC"].string ?? ""
        division = json["DIVISION"].string ?? ""
        image = json["ZIMAGE"].string ?? ""
        orderType = json["ORDER_TYPE"].string ?? ""
        netValue = json["NET_VALUE"].double ?? 0
        
        type = json["ZTYPE"].string ?? ""
        address = json["ADDRESS"].string ?? ""
        route = json["ROUTE"].string ?? ""
        vsart = json["VSART"].string ?? ""
        phoneNumber = json["PHONE_NUMBER"].string ?? ""
        idU = json["ID_U"].string ?? ""
        idK = json["ID_K"].string ?? ""
        price = json["ZPRICE"].double ?? 0
        totalPrice = json["TOTAL_PRICE"].double ?? 0
        ck = json["CK"].double ?? 0
        creditValue = json["CREDIT_VALUE"].double ?? 0
        creditValueCustom = json["CREDIT_VALUE_CUS"].double ?? 0
        stbl = json["STBL"].double ?? 0
        tax = json["TAX"].double ?? 0
        statusBL = json["STATUS_BL"].string ?? ""
        stdbl = json["STDBL"].double ?? 0
        
        ztc = json["ZTC"].string ?? ""
    }
    
    
    
    static func getStatusOrder(order: OrderModel) -> (title: String, color: UIColor) {
        
        switch order.status {
            
        case "P" where order.ztc == "0",
             "L" where order.ztc == "0":
            return ("Đã lưu".uppercased(), #colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1))
        case "P" where order.ztc == "2" :
            return ("Đã phê duyệt TC".uppercased(), #colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1))
        case "R":
            return ("Đã hủy".uppercased(), #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1))
        case "F":
            return ("Không Thành Công".uppercased(), #colorLiteral(red: 0.8078431373, green: 0.02745098039, blue: 0.3333333333, alpha: 1))
        case "C":
            return ("Vượt hạn mức tín dụng".uppercased(), #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1))
        case "T":
            return ("Chờ xử lý".uppercased(), #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1))
        case "B" where order.statusBL == "",
             "B" where order.statusBL == "X":
            return ("Chờ bảo lãnh".uppercased(), #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1))
        case "S":
            return ("Đặt Thành Công".uppercased(), #colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1))
        case "A":
            return ("Đã Duyệt".uppercased(), #colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1))
        default:
            return ("Không Thành Công".uppercased(), #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1))
        }
    }
    
    
    static func getStatusGuarantee(order: OrderModel) -> (title: String, color: UIColor) {
    
        switch order.statusBL {
        case "X" where order.status == "B", "X" where order.status == "S":
            return ("Đã bảo lãnh".uppercased(), #colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1))
        case "":
            return ("Chưa bảo lãnh".uppercased(), #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1))
        default:
            return ("Chưa bảo lãnh".uppercased(), #colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1))
        }
    }
    
    
    
    static func showHiddenAction(order: OrderModel, userID: String = AppDataShare.shared.userDetail.user.userID) -> Bool {
        
        if (order.idApprove == userID || order.idApprove == AppDataShare.shared.authenModel.idPeer) &&
            (order.status == "P" || order.status == "F" || order.status == "L" || order.status == "C")   {
            
            return true
        }
        
        return false
    }
    
    static func getTilteAction(orderModel: OrderModel, userID: String = AppDataShare.shared.userDetail.user.userID) -> String {
        
        switch orderModel.status {
        case "C":
            return "YC phê duyệt"
        default:
            return "gửi đơn hàng"
        }
    }
    
    
    static func getCheckCredit(orderModel: OrderModel) -> String? {
        switch orderModel.status {
        case "C":
            return "X"
        default:
            return "X"
        }
    }
    
    /*
    static func showHiddenAction(order: OrderModel, userID: String = MenuManager.shared.userID) -> Bool {
        
        // -< button Yêu cầu bảo lãnh --> hủy
        if order.idApprove == userID && (order.status == "C") {
            return true
        }
        
        return false
    }
     */
}


extension OrderModel {
    
    static func showHiddenGuaranteeAction(order: OrderModel, userID: String = AppDataShare.shared.userDetail.user.userID) -> Bool {
        
        switch order.statusBL {
        case "":
            return true
        default:
            return false
        }
    }
}



class ItemModel: NSObject {
    
    var idItem: String = ""
    
    var idHeader: String = ""
    
    var type: String = ""
    
    var matnr: String = ""
    
    @objc var name: String = ""
    
    var quantity: Double = 0
    
    var saleUnit: String = ""
    
    var zReturn: String = ""
    
    var characteristics: [CharacteristicModel] = []
    
    var thanhle: String = ""
    
    
    //---
    
    var height: Double = 0
    
    var width: Double = 0
    
    var zTerm: String = ""
    
    var price: Double = 0
    
    var idUser: String = ""
    
    
    override init() {
        super.init()
    }
    
    init(idItem: String, idHeader: String, quantity: Double, type: String, zReturn: String, idUser: String, matnr: String, name: String, saleUnit: String) {
        
        self.idItem = idItem
        self.idHeader = idHeader
        self.quantity = quantity
        self.type = type
        self.zReturn = zTerm
        self.idUser = idUser
        self.matnr = matnr
        self.name = name
        self.saleUnit = saleUnit
    }
    
    init(json: JSON) {
        
        idItem = json["ID_ITEM"].string ?? ""
        idHeader = json["ID_HEADER"].string ?? ""
        type = json["TYPE"].string ?? ""
        matnr = json["MATNR"].string ?? ""
        name = json["NAME"].string ?? ""
        quantity = json["QUANTITY"].double ?? 0
        saleUnit = json["SALE_UNIT"].string ?? ""
        zReturn = json["Z_RETURN"].string ?? ""
        characteristics = json["CHARACTERISTICS"].arrayValue.map { CharacteristicModel(json: $0)}
        
        thanhle = json["THANH_LE"].string ?? ""
        
    }
    
}

class ItemModelClient: ItemModel {
    
    var check: String = ""
    
    var zDKGH: String = ""
    
    var extwg: String = "" // Lay zType
    
    
    override init() {
        super.init()
    }
    
    
    override init(json: JSON) {
        super.init(json: json)
    }
    
    
    init(check: String, height: Double = 0, idHeader: String, idItem: String, idUser: String, matnr: String, name: String,
         quantity: Double, saleUnit: String, type: String, width: Double = 0, zReturn: String, zTerm: String) {
        super.init()
        self.check = check
        self.height = height
        self.idHeader = idHeader
        self.idItem = idItem
        self.idUser = idUser
        self.matnr = matnr
        self.name = name
        self.quantity = quantity
        self.saleUnit = saleUnit
        self.type = type
        self.width = width
        self.zReturn = zReturn
        self.zTerm = zTerm
    }
    
    
    func convertRawString() -> Parameters {
        
        var params: Parameters = [:]
        
        params["HEIGHT"] = self.height
        params["ID_HEADER"] = self.idHeader
        params["ID_ITEM"] = self.idItem
        params["MATNR"] = self.matnr
        params["NAME"] = self.name
        params["QUANTITY"] = self.quantity
        params["SALE_UNIT"] = self.saleUnit
        params["THANH_LE"] = self.thanhle
        params["TYPE"] = self.type
        params["WIDTH"] = self.width
        params["check"] = self.check
        params["id_user"] = self.idUser
        
        var charactericsParams: [Parameters] = []
        
        self.characteristics.forEach { (item) in
            charactericsParams.append(item.convertRawString())
        }
        
        params["CHARACTERISTICS"] = charactericsParams
        
        return params
    }
}


struct CharacteristicModel {
    
    var atnam: String = ""
    
    var smbez: String = ""
    
    var value: String = ""
    
    var type: String = ""
    
    var group: String = ""
    
    var sort: String = ""
    
    var filterValue: [GetCharacteristicValue2Model] = []
    
    var filterBoToi: [GetMappingBoToiModel] = []
    
    var filterThanhRay: [GetMappingThanhRayModel] = []
    
    var filterMatReferModel: [GetMatReferModel] = []
    
    var selectedIndex: Int = 0 // keep index selected item filter
    
    init() { }
    
    
    init(atnam: String, smbez: String, group: String, mappingBoToi: [GetMappingBoToiModel] = [], mappingThanhRay: [GetMappingThanhRayModel] = []) {
        self.atnam = atnam
        self.smbez = smbez
        self.group = group
        self.filterBoToi = mappingBoToi
        self.filterThanhRay = mappingThanhRay
    }
    
    
    init(atnam: String, smbez: String, value: String, group: String, sort: String, filterValue: [GetCharacteristicValue2Model] = []) {
        self.atnam = atnam
        self.smbez = smbez
        self.value = value
        self.group = group
        self.sort = sort
        self.filterValue = filterValue
    }
    
    
    init(json: JSON) {
        
        atnam = json["ATNAM"].string ?? ""
        smbez = json["SMBEZ"].string ?? ""
        value = json["VALUE"].string ?? ""
        type = json["ZTYPE"].string ?? ""
        group = json["ZGROUP"].string ?? ""
        sort = json["ZSORT"].string ?? ""
    }
    
    
    func convertRawString() -> Parameters {
        
        var params: Parameters = [:]
        
        params["ATNAM"] = self.atnam
        params["SMBEZ"] = self.smbez
        params["VALUE"] = self.value
        params["ZGROUP"] = self.group
        params["ZSORT"] = self.sort
        params["ZTYPE"] = self.type
        
        return params
    }
}
