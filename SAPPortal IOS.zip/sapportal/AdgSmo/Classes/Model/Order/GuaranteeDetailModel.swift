//
//  GuaranteeDetailModel.swift
//  SapPortal
//
//  Created by LuongTiem on 6/20/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

class GuaranteeDetailModel: ApproveSalesOrderCreditModel {
    
     
}
