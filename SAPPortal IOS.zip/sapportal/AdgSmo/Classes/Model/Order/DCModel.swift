//
//  DCModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct DCModel {
    
    var mandt: String = ""
    
    var spras: String = ""
    
    var vtext: String = ""
    
    var vtweg: String = ""
    
    
    init() { }
    
    
    init(json: JSON) {
        mandt = json["MANDT"].string ?? ""
        spras = json["SPRAS"].string ?? ""
        vtext = json["VTEXT"].string ?? ""
        vtweg = json["VTWEG"].string ?? ""
    }
}
