//
//  OrderDetailModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/6/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct OrderDetailModel {
    
    var idOrder: String = ""
    
    var idUser: String = ""
    
    var name: String = ""
    
    var shiptoID: String = ""
    
    var note: String = ""
    
    var status: String = ""
    
    var date: String = ""
    
    var item: [ItemModelClient] = []
    
    var createBy: String = ""
    
    var idApprove: String = ""
    
    var createByName: String = ""
    
    var nameApprove: String = ""
    
    var auart: String = ""
    
    var kunnr: String = ""
    
    var term: String = ""
    
    var today: String = ""
    
    var level: String = ""
    
    var dc: String = ""
    
    var division: String = ""
    
    var image: String = ""
    
    var orderType: String = ""
    
    var netValue: Double = 0
    
    var type: String = ""
    
    var address: String = ""
    
    var route: String = ""
    
    var vsart: String = ""
    
    var nameShipTo: String = ""
    
    var phoneNumber: String = ""
    
    var phoneEndUser: String = ""
    
    var idU: String = ""
    
    var idK: String = ""
    
    var price: Double = 0
    
    var totalPrice: Double = 0
    
    var ck: Double = 0
    
    var creditValue: Double = 0
    
    var creditValueCustom: Double = 0
    
    var stbl: Double = 0
    
    var tax: Double = 0
    
    var statusBL: String = ""
    
    var stdbl: Double = 0
    
    var totalInquiry: Double = 0
    
    var zntcxd: String = ""
    
    var zngayGH: String = ""
    
    var znguoiGH: String = ""
    
    var ztc: String = ""
    
    var time: String = ""
    
    var nameNN: String = ""
    
    var nameEndUser: String = ""
    
    var addressEndUser: String = ""
    
    
    init() { }
    
    
    
    init(json: JSON) {
        
        idOrder = json["ID_ORDER"].string ?? ""
        idUser = json["ID_USER"].string ?? ""
        name = json["NAME"].string ?? ""
        shiptoID = json["SHIPTO_ID"].string ?? ""
        note = json["NOTE"].string ?? ""
        status = json["STATUS"].string ?? ""
        date = json["Z_DATE"].string ?? ""
        item = json["ITEMS"].arrayValue.map { ItemModelClient(json: $0) }
        createBy = json["CREATE_BY"].string ?? ""
        idApprove = json["ID_APPROVE"].string ?? ""
        createByName = json["CREATE_BY_NAME"].string ?? ""
        nameApprove = json["NAME_APPROVE"].string ?? ""
        auart = json["AUART"].string ?? ""
        kunnr = json["KUNNR"].string ?? ""
        term = json["ZTERM"].string ?? ""
        today = json["TODAY"].string ?? ""
        level = json["ZLEVEL"].string ?? ""
        dc = json["DC"].string ?? ""
        division = json["DIVISION"].string ?? ""
        image = json["ZIMAGE"].string ?? ""
        orderType = json["ORDER_TYPE"].string ?? ""
        netValue = json["NET_VALUE"].double ?? 0
        type = json["ZTYPE"].string ?? ""
        address = json["ADDRESS"].string ?? ""
        route = json["ROUTE"].string ?? ""
        vsart = json["VSART"].string ?? ""
        nameShipTo = json["NAME_SHIPTO"].string ?? ""
        phoneNumber = json["PHONE_NUMBER"].string ?? ""
        idU = json["ID_U"].string ?? ""
        idK = json["ID_K"].string ?? ""
        price = json["ZPRICE"].double ?? 0
        totalPrice = json["TOTAL_PRICE"].double ?? 0
        ck = json["CK"].double ?? 0
        creditValue = json["CREDIT_VALUE"].double ?? 0
        creditValueCustom = json["CREDIT_VALUE_CUS"].double ?? 0
        stbl = json["STBL"].double ?? 0
        tax = json["TAX"].double ?? 0
        statusBL = json["STATUS_BL"].string ?? ""
        stdbl = json["STDBL"].double ?? 0
        totalInquiry = json["TOTAL_INQUIRY"].double ?? 0
        zntcxd = json["ZNTCXD"].string ?? ""
        zngayGH = json["ZNGAYGH"].string ?? ""
        znguoiGH = json["ZNGUOIGH"].string ?? ""
        phoneEndUser = json["SDT_KHC"].string ?? ""
        time = json["TG_DH"].string ?? ""
        nameNN = json["TEN_NNH"].string ?? ""
        nameEndUser = json["TEN_KHC"].string ?? ""
        addressEndUser = json["DC_KHC"].string ?? ""
        
        ztc = json["ZTC"].string ?? ""
    }
    
    
    static func getStatusOrder(model: OrderDetailModel) -> String {
        
        switch model.status {
            
        case "P" where model.ztc == "0",
             "L" where model.ztc == "0",
             "P" where model.ztc == "",
             "L" where model.ztc == "":
            return "Đã lưu"
        case "P" where model.ztc == "2" :
            return "Đã phê duyệt TC"
        case "R":
            return "Đã hủy"
        case "F":
            return "Không Thành Công"
        case "C":
            return "Vượt hạn mức tín dụng"
        case "T":
            return "Chờ xử lý"
        case "B" where model.statusBL == "",
             "B" where model.statusBL == "X":
            return "Chờ bảo lãnh"
        case "S":
            return "Đặt Thành Công"
        case "A":
            return "Đã Duyệt"
        default:
            return "Không Thành Công"
        }
    }
}
