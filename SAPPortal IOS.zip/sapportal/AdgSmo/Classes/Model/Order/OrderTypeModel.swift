//
//  OrderTypeModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct OrderTypeModel {
    
    var mandt: String = ""
    
    var spras: String = ""

    var auart: String = ""
    
    var bezei: String = ""
    
    
    init(json: JSON) {
        mandt = json["MANDT"].string ?? ""
        spras = json["SPRAS"].string ?? ""
        auart = json["AUART"].string ?? ""
        bezei = json["BEZEI"].string ?? ""
    }
}
