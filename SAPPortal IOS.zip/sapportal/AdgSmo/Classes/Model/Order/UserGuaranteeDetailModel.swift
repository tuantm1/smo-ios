//
//  UserGuaranteeDetailModel.swift
//  SapPortal
//
//  Created by LuongTiem on 6/20/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

struct UserGuaranteeDetailModel {
    
    var grade: String = ""
    
    var hmcl: Double = 0
    
    var parents: [UserGuaranteeParentModel] = []
    
    var user: UserModel = UserModel()
    
    var returnResponse = ReturnResponse()
    
    
    init() {
        
    }
    
    
    init(json: JSON) {
        
        grade = json["GRADE"].string ?? ""
        
        hmcl = json["HMCL"].double ?? 0
        
        parents = json["PARENTS"].arrayValue.map { UserGuaranteeParentModel(json: $0) }
        
        user = UserModel(json: json["USER"])
        
        returnResponse = ReturnResponse(json: json["RETURN"])
    }
    
    
    func convertRawString() -> Parameters {
        
        var params: Parameters = [:]
        params["grade"] = self.grade
        params["hmcl"] = self.hmcl
        
        var parentParams: [Parameters] = []
        
        self.parents.forEach { (model) in
            parentParams.append(model.convertRawString())
        }
        
        params["PARENTS"] = parentParams
        
        return params
    }
}


struct UserGuaranteeParentModel {
    
    var userID: String = ""
    
    var username: String = ""
    
    var password: String = ""
    
    var kunnr: String = ""
    
    var idGR: String = ""
    
    var parentID: String = ""
    
    var parentID2: String = ""
    
    var usType: String = ""
    
    var peerToPeer: String = ""
    
    var description: String = ""
    
    var parentName: String = ""
    
    
    
    init(json: JSON) {
        
        userID = json["ID_USER"].string ?? ""
        username = json["USERNAME"].string ?? ""
        password = json["PASSWORD"].string ?? ""
        kunnr = json["KUNNR"].string ?? ""
        idGR = json["ID_GR"].string ?? ""
        parentID = json["PARENT_ID"].string ?? ""
        parentID2 = json["PARENT_ID_2"].string ?? ""
        usType = json["US_TYPE"].string ?? ""
        peerToPeer = json["PEER_TO_PEER"].string ?? ""
        description = json["DESCRIPTION"].string ?? ""
        parentName = json["PARENT_NAME"].string ?? ""
        
    }
    
    
    func convertRawString() -> Parameters {
        
        var params: Parameters = [:]
        
        params["ID_USER"] = self.userID
        params["USERNAME"] = self.username
//        params["PASSWORD"] = self.password
        params["KUNNR"] = self.kunnr
        params["ID_GR"] = self.idGR
        params["PARENT_ID"] = self.parentID
        params["PARENT_ID_2"] = self.parentID2
        params["US_TYPE"] = self.usType
        params["PEER_TO_PEER"] = self.peerToPeer
        params["DESCRIPTION"] = self.description
        params["PARENT_NAME"] = self.parentName
        
        return params
    }
}
