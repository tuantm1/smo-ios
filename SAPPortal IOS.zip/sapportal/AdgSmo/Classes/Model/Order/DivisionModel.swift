//
//  DivisionModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct DivisionModel {
    
    var mandt: String = ""
    
    var spart: String = ""
    
    var spras: String = ""
    
    var vtext: String = ""
    
    
    init() { }
    
    
    init(json: JSON) {
        mandt = json["MANDT"].string ?? ""
        spart = json["SPART"].string ?? ""
        spras = json["SPRAS"].string ?? ""
        vtext = json["VTEXT"].string ?? ""
    }
}
