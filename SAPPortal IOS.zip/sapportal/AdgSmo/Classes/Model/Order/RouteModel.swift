//
//  RouteModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct RouteModel {
    
    var route: [DistrictModel] = []
    
    var t173t: [CityModel] = []
    
    
    init() {}
    
    
    init(json: JSON) {
        
        route = json["GT_ROUTE"].arrayValue.map { DistrictModel(json: $0) }
        
        t173t = json["GT_T173T"].arrayValue.map { CityModel(json: $0) }
    }
    
}


struct DistrictModel {
    
    var route: String = ""
    
    var bezei: String = ""
    
    var vsart: String = ""
    
    
    
    init(json: JSON) {
        route = json["ROUTE"].string ?? ""
        bezei = json["BEZEI"].string ?? ""
        vsart = json["VSART"].string ?? ""
    }
}


struct CityModel {
    
    var mandt: String = ""
    
    var spras: String = ""
    
    var vsart: String = ""
    
    var bezei: String = ""
    
    init(json: JSON) {
        mandt = json["MANDT"].string ?? ""
        spras = json["SPRAS"].string ?? ""
        vsart = json["VSART"].string ?? ""
        bezei = json["BEZEI"].string ?? ""
    }
    
}
