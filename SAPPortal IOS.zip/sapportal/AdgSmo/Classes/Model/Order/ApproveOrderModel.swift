//
//  ApproveOrderModel.swift
//  SapPortal
//
//  Created by LuongTiem on 4/28/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

class ApproveOrderModel: OrderModel {
    
}



class ApproveOrderActionModel {
    
    var field: String = ""
    
    var id: String = ""
    
    var logMessageNo: String = ""
    
    var logNo: String = ""
    
    var message: String = ""
    
    var messageV1: String = ""
    
    var messageV2: String = ""
    
    var messageV3: String = ""
    
    var messageV4: String = ""
    
    var number: String = ""
    
    var parameter: String = ""
    
    var row: Int = 0
    
    var system: String = ""
    
    var type: String = ""
    
    
    init(json: JSON) {
        field = json["FIELD"].string ?? ""
        id = json["ID"].string ?? ""
        logMessageNo = json["LOG_MSG_NO"].string ?? ""
        logNo = json["LOG_NO"].string ?? ""
        message = json["MESSAGE"].string ?? ""
        messageV1 = json["MESSAGE_V1"].string ?? ""
        messageV2 = json["MESSAGE_V2"].string ?? ""
        messageV3 = json["MESSAGE_V3"].string ?? ""
        messageV4 = json["MESSAGE_V4"].string ?? ""
        number = json["NUMBER"].string ?? ""
        parameter = json["PARAMETER"].string ?? ""
        row = json["ROW"].int ?? 0
        system = json["SYSTEM"].string ?? ""
        type = json["TYPE"].string ?? ""
    }
    
}
