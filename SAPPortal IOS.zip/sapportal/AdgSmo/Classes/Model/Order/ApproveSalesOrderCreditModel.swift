//
//  ApproveSalesOrderCreditModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/31/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

class ApproveSalesOrderCreditModel: NSObject {
    
    @objc var creditID: String = ""
    
    var requestID: String = ""
    
    var approveID: String = ""
    
    var orderID: String = ""
    
    var date: String = ""
    
    var price: Double = 0
    
    var day: String = ""
    
    var note: String = ""
    
    var stbl: Double = 0
    
    var status: String = ""
    
    
    override init() {
        super.init()
    }
    
    
    
    init(json: JSON) {
        creditID = json["ID_CREDIT"].string ?? ""
        requestID = json["ID_REQUEST"].string ?? ""
        approveID = json["ID_APPROVE"].string ?? ""
        orderID = json["ID_ORDER"].string ?? ""
        date = json["ZDATE"].string ?? ""
        price = json["ZPRICE"].double ?? 0
        day = json["ZDAY"].string ?? ""
        note = json["NOTE"].string ?? ""
        stbl = json["STBL"].double ?? 0
        status = json["STATUS"].string ?? ""
    }
    
    
    static func showHiddenApproveSalesOrderCreditAction(model: ApproveSalesOrderCreditModel, userID: String = MenuManager.shared.userID) -> Bool {
        
        if model.status == "1" || model.status == "2" {
            return false
        }
        
        return true
    }
    
    
    static func hiddenGuaranteeButton(model: ApproveSalesOrderCreditModel, userID: String = MenuManager.shared.userID) -> Bool {
        
        if model.approveID == userID {
            return false
        }
        
        return true
    }
    
}
