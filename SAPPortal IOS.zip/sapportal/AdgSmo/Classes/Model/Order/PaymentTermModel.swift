//
//  PaymentTermModel.swift
//  SapPortal
//
//  Created by LuongTiem on 5/13/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import SwiftyJSON

struct PaymentTermsModel {
    
    var mandt: String = ""
    
    var spras: String = ""
    
    var term: String = ""
    
    var text: String = ""
    
    
    init(json: JSON) {
        mandt = json["MANDT"].string ?? ""
        spras = json["SPRAS"].string ?? ""
        term = json["ZTERM"].string ?? ""
        text = json["VTEXT"].string ?? ""
    }
    
}
