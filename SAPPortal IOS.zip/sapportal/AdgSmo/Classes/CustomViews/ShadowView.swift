//
//  ShadowView.swift
//  SapPortal
//
//  Created by LuongTiem on 2/26/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class ShadowView: UIView {
    
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            self.layer.cornerRadius = cornerRadius
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        self.layer.masksToBounds = true
        
        self.setShadow(color: .darkGray, offSet: CGSize(width: 1.0, height: 5.0), opacity: 0.3, radius: 8.0)
    }

}
