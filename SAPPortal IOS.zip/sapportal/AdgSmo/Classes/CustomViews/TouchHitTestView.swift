//
//  TouchHitTestView.swift
//  SapPortal
//
//  Created by LuongTiem on 8/6/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class TouchHitTestView: UIView {
    
    
    var didSelectedView: (() -> Void)?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        if self.point(inside: point, with: event) {
            return super.hitTest(point, with: event)
        }
        guard isUserInteractionEnabled, !isHidden, alpha > 0 else {
            return nil
        }

        for subview in subviews.reversed() {
            let convertedPoint = subview.convert(point, from: self)
            if let hitView = subview.hitTest(convertedPoint, with: event) {
                return hitView
            }
        }
        return nil
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        didSelectedView?()
    }
}
