//
//  HeaderTitleView.swift
//  SapPortal
//
//  Created by LuongTiem on 5/12/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class HeaderTitleView: UITableViewHeaderFooterView {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var backgroundHeaderView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func bindingData(title: String, background: UIColor = .white, titleColor: UIColor = .black) {
        titleLabel.text = title
        titleLabel.textColor = titleColor
        backgroundHeaderView.backgroundColor = background
    }
    

}

extension HeaderTitleView {
    
    override func prepareForReuse() {
        super.prepareForReuse()
        titleLabel.text = ""
    }
}
