//
//  CalendarView.swift
//  SapPortal
//
//  Created by LuongTiem on 6/12/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit
import FSCalendar

class CalendarView: UIView {

    @IBOutlet weak private var calendar: FSCalendar!
    @IBOutlet weak var confirmButton: UIButton!
    
    
    private var updateDate: Date = Date()
    
    private var gregorian = Calendar(identifier: .gregorian)
    
    var didSelectDate: ((Date) -> Void)?
    
    var isChooseBeforeDate: Bool = true
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        confirmButton.layer.cornerRadius = 14
        confirmButton.layer.masksToBounds = true
        
        backgroundColor = .white
        
        configCalendar()
    }
    
    
    private func configCalendar() {
        
        calendar.delegate = self
        calendar.dataSource = self
        
        calendar.appearance.caseOptions = [.headerUsesUpperCase, .weekdayUsesSingleUpperCase]
        calendar.appearance.weekdayTextColor = UIColor.black
        calendar.appearance.headerTitleColor = UIColor.darkGray
        calendar.appearance.selectionColor = UIColor.red
        
        calendar.appearance.todayColor = UIColor.black
    }
    
    
    @IBAction func confirmAction(_ sender: Any) {
        
        didSelectDate?(updateDate)
    }
    
}


extension CalendarView: FSCalendarDelegate {
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
      
        if monthPosition == .previous || monthPosition == .next {
            calendar.setCurrentPage(date, animated: true)
            self.layoutIfNeeded()
        }
        
        updateDate = date.addingTimeInterval(TimeInterval(TimeZone.current.secondsFromGMT(for: date)))
    }
    
    func calendar(_ calendar: FSCalendar, shouldSelect date: Date, at monthPosition: FSCalendarMonthPosition) -> Bool {
        if date .compare(Date()) == .orderedAscending {
            return isChooseBeforeDate
        }
        else {
            return true
        }
    }
}


extension CalendarView: FSCalendarDataSource {
    
    
}

