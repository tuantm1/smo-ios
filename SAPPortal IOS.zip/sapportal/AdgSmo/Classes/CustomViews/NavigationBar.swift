//
//  NavigationBar.swift
//  SapPortal
//
//  Created by LuongTiem on 2/26/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

class NavigationBar: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
    
}
