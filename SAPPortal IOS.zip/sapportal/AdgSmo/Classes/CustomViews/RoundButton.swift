//
//  RoundButton.swift
//  PointHub
//
//  Created by ReasonLeveing on 8/16/19.
//  Copyright © 2019 ReasonLeveing. All rights reserved.
//

import UIKit

class RoundButton: UIButton {

    @IBInspectable var borderWidth: CGFloat {
        set {
            layer.borderWidth = newValue
        }
        get {
            return layer.borderWidth
        }
    }
    
    @IBInspectable var cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
        }
        get {
            return layer.cornerRadius
        }
    }
    
    @IBInspectable var borderColor: UIColor? {
        set {
            guard let uiColor = newValue else { return }
            layer.borderColor = uiColor.cgColor
        }
        get {
            guard let color = layer.borderColor else { return nil }
            return UIColor(cgColor: color)
        }
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupUI()
    }
    
}

extension RoundButton {
    
    private func setupUI() {
        
        cornerRadius = 10
        
//        backgroundColor = Constants.Color.backgroundButton
        
        self.setTitleColor(.white, for: .normal)
//        self.setTitleColor(UIColor(white: 0.7, alpha: 1), for: .highlighted)
    }
}
