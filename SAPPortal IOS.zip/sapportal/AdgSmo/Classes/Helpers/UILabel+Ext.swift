//
//  UILabel+Ext.swift
//  SapPortal
//
//  Created by LuongTiem on 4/25/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

extension UILabel {
    
    func customFontSize(firstString: String = "", firstFont: UIFont = UIFont.systemFont(ofSize: 14),
                        secondString: String = "", secondFont: UIFont = UIFont.boldSystemFont(ofSize: 16)) {
        
        let resultAttributes = NSMutableAttributedString()
        
        let firstAttributes = NSMutableAttributedString(string: firstString, attributes: [NSAttributedString.Key.font: firstFont])
        resultAttributes.append(firstAttributes)
        
        let secondAttributes = NSMutableAttributedString(string: secondString, attributes: [NSAttributedString.Key.font: secondFont])
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 2.0
        paragraphStyle.lineHeightMultiple = 1.15

        secondAttributes.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: NSRange(location: 0, length: secondString.count))
        resultAttributes.append(secondAttributes)
        
        self.attributedText = resultAttributes
    
    }
}
