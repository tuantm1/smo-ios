//
//  UIStoryboard+Ext.swift
//  SapPortal
//
//  Created by LuongTiem on 2/25/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import UIKit

// MARK: - SegueIdentifier
struct SegueIdentifier {
    
    
    struct Authentication {
        
        static let showSignUp = "showSignUp"
    }
    
    
    struct Main {
        
    }
    
    
    struct ApproveOrder {
        static let detailApproveOrder: String = "detailApproveOrder"
    }
    
    
    struct PlaceOrder {
        static let detailPlaceOrder: String = "detailPlaceOrder"
    }
    
    
    struct Account {
        static let customerDetail: String = "customerDetail"
        
        static let pushListAccount = "pushListAccount"
        
        static let pushAccountDetail = "pushAccountDetail"
        
        static let showForgotPassword = "showForgotPassword"
    }
    
    // -- new
    struct MenuOrder {
        
        static let pushOrderController = "pushOrderController"
        
        static let pushApproveCredit = "pushApproveCredit"
        
        static let pushApproveOrder = "pushApproveOrder"
        
        static let pushReturnOrder = "pushReturnOrder"
        
        static let pushApproveOrderDetail = "pushApproveOrderDetail"
        
        static let pushOrderDetail = "pushOrderDetail"
        
        static let pushGuaranteeListOrder = "pushGuaranteeListOrder"
        
        static let pushDetailApproveSaleOrderCredit = "pushDetailApproveSaleOrderCredit"
        
        static let pushCreateOrder = "pushCreateOrder"
        
        static let pushCreateOrderDetailController = "pushCreateOrderDetailController"
        
        static let pushCreateOrderInfoController = "pushCreateOrderInfoController"
        
        static let pushCreateGuaranteeOrderController = "pushCreateGuaranteeOrderController"
    }
    
    
    struct OrderDetail {
        
        static let showItemDetailController = "showItemDetailController"
        static let showItemDetailEdit = "showItemDetailEdit"
    }
    
    struct MenuSAP {
        static let listItemSap = "listItemSap"
        
        static let pushCustomerLiabilities = "pushCustomerLiabilities"
        
        static let pushDetailCustomerLiabilities = "pushDetailCustomerLiabilities"
    }
    
    
    struct MenuDelivery {
        
        static let showDeliveryDetail = "showDeliveryDetail"
        
        static let showReceiptPrint = "showReceiptPrint"
        
        static let showReceiptUpload = "showReceiptUpload"
    }
}

enum UIStoryboardType {
    
    case authentication
    case main
    case order
    case sap
    case account
    case delivery
    case dashboard
    
    var identifier: String {
        switch self {
        case .authentication:
            return "Authentication"
        case .main:
            return "Main"
        case .order:
            return "OrderStoryboard"
        case .sap:
            return "SAPStoryboard"
        case .account:
            return "Account"
        case .delivery:
            return "Delivery"
        case .dashboard:
            return "Dashboard"
        }
    }
    
    
    // MARK: Private Variables
    var title: String {
        switch self {
        case .authentication:
            return ""
        case .main:
            return ""
        case .order:
            return "QL Đơn hàng"
        case .sap:
            return "QL Dữ liệu"
        case .account:
            return "Tài khoản"
        case .delivery:
            return "Giao hàng"
        case .dashboard:
            return "Trang chủ"
        }
    }
    
    
    private var normalIcon: UIImage {
        switch self {
        case .authentication:
            return UIImage()
        case .main:
            return UIImage()
        case .order:
            return #imageLiteral(resourceName: "order")
        case .sap:
            return #imageLiteral(resourceName: "sap")
        case .account:
            return #imageLiteral(resourceName: "account")
        case .delivery:
            return #imageLiteral(resourceName: "delivery")
        case .dashboard:
            return #imageLiteral(resourceName: "home")
        }
    }
    
    
    private var selectedIcon: UIImage {
        switch self {
        case .authentication:
            return UIImage()
        case .main:
            return UIImage()
        case .order:
            return #imageLiteral(resourceName: "order_fill")
        case .sap:
            return #imageLiteral(resourceName: "sap_fill")
        case .account:
            return #imageLiteral(resourceName: "account_fill")
        case .delivery:
            return #imageLiteral(resourceName: "delivery_fill")
        case .dashboard:
            return #imageLiteral(resourceName: "home_fill")
        }
    }
    
    
    var rootVC: UIViewController {
        switch self {
        case .authentication:
            let navVC = UIStoryboard.load(.authentication)
            navVC.tabBarItem.title = title
            navVC.tabBarItem.image = normalIcon.withRenderingMode(.alwaysOriginal)
            navVC.tabBarItem.selectedImage = selectedIcon.withRenderingMode(.alwaysOriginal)
            return navVC
        case .main:
            let navVC = UIStoryboard.load(.main)
            navVC.tabBarItem.title = title
            navVC.tabBarItem.image = normalIcon.withRenderingMode(.alwaysOriginal)
            navVC.tabBarItem.selectedImage = selectedIcon.withRenderingMode(.alwaysOriginal)
            return navVC
        case .order:
            let navVC =  UIStoryboard.load(.order)
            navVC.tabBarItem.title = title
            navVC.tabBarItem.image = normalIcon.withRenderingMode(.alwaysOriginal)
            navVC.tabBarItem.selectedImage = selectedIcon.withRenderingMode(.alwaysOriginal)
            return navVC
        case .sap:
            let navVC =  UIStoryboard.load(.sap)
            navVC.tabBarItem.title = title
            navVC.tabBarItem.image = normalIcon.withRenderingMode(.alwaysOriginal)
            navVC.tabBarItem.selectedImage = selectedIcon.withRenderingMode(.alwaysOriginal)
            return navVC
        case .account:
            let navVC = UIStoryboard.load(.account)
            navVC.tabBarItem.title = title
            navVC.tabBarItem.image = normalIcon.withRenderingMode(.alwaysOriginal)
            navVC.tabBarItem.selectedImage = selectedIcon.withRenderingMode(.alwaysOriginal)
            return navVC
        case .delivery:
            let navVC = UIStoryboard.load(.delivery)
            navVC.tabBarItem.title = title
            navVC.tabBarItem.image = normalIcon.withRenderingMode(.alwaysOriginal)
            navVC.tabBarItem.selectedImage = selectedIcon.withRenderingMode(.alwaysOriginal)
            return navVC
        case .dashboard:
            let navVC = UIStoryboard.load(.dashboard)
            navVC.tabBarItem.title = title
            navVC.tabBarItem.image = normalIcon.withRenderingMode(.alwaysOriginal)
            navVC.tabBarItem.selectedImage = selectedIcon.withRenderingMode(.alwaysOriginal)
            return navVC
        }
    }
    
}

extension UIStoryboard {
    
    class func load(_ storyboard: UIStoryboardType) -> UIViewController {
        
        guard let result = UIStoryboard(name: storyboard.identifier, bundle: nil).instantiateInitialViewController() else {
            assertionFailure("Load fail storyboad !")
            return UIViewController()
        }
        
        return result
    }
}
