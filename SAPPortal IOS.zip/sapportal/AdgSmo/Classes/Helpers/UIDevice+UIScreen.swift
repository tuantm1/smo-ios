

import Foundation
import UIKit




// MARK: UIDevice
extension UIDevice {
    
    var isPad: Bool {
        return UIDevice.current.userInterfaceIdiom == .pad
    }
    
    var isPhone: Bool {
        return UIDevice.current.userInterfaceIdiom == .phone
    }
    
    var isIphoneXR: Bool {
        return UIDevice.current.isPhone && UIScreen.main.nativeBounds.height == 1792
    }
    
    var isFaceIDSupported: Bool {
        return UIDevice.current.isPhone && (UIDevice.current.isIphoneXR || UIScreen.main.nativeBounds.height >= 2436)
    }
    
    var isSimulator: Bool {
        let code = hardwareVersion
        return code == "i386" || code == "x86_64"
    }
}

extension UIDevice {
    
    private var hardwareVersion: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let versionCode = String(utf8String: NSString(bytes: &systemInfo.machine,
                                                      length: Int(_SYS_NAMELEN),
                                                      encoding: String.Encoding.ascii.rawValue)!.utf8String!)!
        return versionCode
    }
}




// MARK: UIScreen

extension UIScreen {
    
    class var width: CGFloat {
        return UIScreen.main.bounds.width
    }
    
    class var height: CGFloat {
        return UIScreen.main.bounds.height
    }
}

extension UIScreen {

    struct Ratio {
        
        static let BaseScreen: CGSize = CGSize(width: 375, height: 667) // define width, height base ratio
        
        static var width: CGFloat = UIScreen.main.bounds.width / UIScreen.Ratio.BaseScreen.width
        
        static let height: CGFloat = UIScreen.main.bounds.height / UIScreen.Ratio.BaseScreen.height
        
    }
}


// MARK: Support adjust ratio follow screen
extension CGFloat {
    
    var adjustedWidth: CGFloat {
        
        return self * UIScreen.Ratio.width
    }
    
    
    var adjustedHeight: CGFloat {
        
        return self * UIScreen.Ratio.height
    }
}


extension Double {
    
    var adjustedWidth: CGFloat {
        
        return CGFloat(self) * UIScreen.Ratio.width
    }
    
    
    var adjustedHeight: CGFloat {
        
        return CGFloat(self) * UIScreen.Ratio.height
    }
}


extension Int {
    
    var adjustedWidth: CGFloat {
        
        return CGFloat(self) * UIScreen.Ratio.width
    }
    
    
    var adjustedHeight: CGFloat {
        
        return CGFloat(self) * UIScreen.Ratio.height
    }
}
