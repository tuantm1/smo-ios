//
//  NSObject+Ext.swift
//  SapPortal
//
//  Created by LuongTiem on 2/26/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

protocol ClassNameProtocol {
    
    static var className: String { get }
    
    var className: String { get }
    
    static var nib: UINib { get }
}


extension ClassNameProtocol {
    
    static var className: String {
        return String(describing: self)
    }
    
    var className: String {
        return type(of: self).className
    }
    
    static var nib: UINib {
        return UINib(nibName: self.className, bundle: nil)
    }
}

extension NSObject: ClassNameProtocol { }


extension UIColor {
    static var random: UIColor {
        return UIColor(red: .random(in: 0...1),
                       green: .random(in: 0...1),
                       blue: .random(in: 0...1),
                       alpha: 1.0)
    }
}





// MARK: LANGUAGE 
private var langBundleKey = 0
private var firstTime = false

extension Bundle {
    private class BundleEx: Bundle {

        override func localizedString(forKey key: String, value: String?, table tableName: String?) -> String {
            guard let bundle = objc_getAssociatedObject(self, &langBundleKey) as? Bundle else {
                return super.localizedString(forKey: key, value: value, table: tableName)
            }
            return bundle.localizedString(forKey: key, value: value, table: tableName)
        }
    }

    class func setLanguage(lang: String) {
//        if !firstTime {
            object_setClass(Bundle.main, BundleEx.self)
            firstTime = true
//        }
        if let bundlePath = Bundle.main.path(forResource: lang, ofType: "lproj"),
            let bundle = Bundle(path: bundlePath) {
            objc_setAssociatedObject(Bundle.main, &langBundleKey,
                                     bundle, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
}
