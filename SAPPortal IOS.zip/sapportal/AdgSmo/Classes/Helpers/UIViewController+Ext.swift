//
//  UIViewController+Ext.swift
//  SapPortal
//
//  Created by LuongTiem on 6/15/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import UIKit

extension UIViewController {
    
    
    func displayWarningLabel(message: String) {
        
        let warningLabel = UILabel(frame: .zero)
        warningLabel.text = message
        warningLabel.textAlignment = .center
        warningLabel.font = UIFont.boldSystemFont(ofSize: 15)
        warningLabel.textColor = UIColor.darkGray
        
        warningLabel.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(warningLabel, aboveSubview: view.subviews.last ?? view)
        
        warningLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16).isActive = true
        warningLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16).isActive = true
        warningLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
}

extension UIAlertAction {
    
    var titleTextColor: UIColor? {
        get {
            return self.value(forKey: "titleTextColor") as? UIColor
        } set {
            self.setValue(newValue, forKey: "titleTextColor")
        }
    }
}
