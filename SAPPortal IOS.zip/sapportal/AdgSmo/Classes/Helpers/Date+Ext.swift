//
//  Date+Ext.swift
//  SapPortal
//
//  Created by LuongTiem on 6/3/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import UIKit


extension Date {
    
    static func getFormattedDate(string: String , formatter:String) -> String{
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"

        let dateFormatterPrint = DateFormatter()
        dateFormatterPrint.dateFormat = "MMM dd,yyyy"

        let date: Date? = dateFormatterGet.date(from: "2018-02-01T19:10:04+00:00")
        print("Date",dateFormatterPrint.string(from: date!)) // Feb 01,2018
        return dateFormatterPrint.string(from: date!);
    }
    
    
    var convertString: String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyyMMdd"
        let todaysDate = dateFormatter.string(from: self)
        
        print(todaysDate)
        
        return todaysDate
    }
    
    
    func convertString(formatter: String) -> String {
    
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = formatter
        let todaysDate = dateFormatter.string(from: self)
        
        return todaysDate
    }
    
    
    static func updateNewDate(dateString: String, increase: Int) -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.locale = Locale.current
        
        let date =  dateFormatter.date(from: dateString) ?? Date()
        
        let dateUpdate = Calendar.current.date(byAdding: .day, value: increase, to: date)
        
        return dateUpdate?.convertString(formatter: "dd/MM/yyyy") ?? dateString
    }
}
