//
//  UIScreen+Ext.swift
//  SapPortal
//
//  Created by LuongTiem on 5/10/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import UIKit
import SwiftEntryKit

extension UIScreen {
    
    var minEdge: CGFloat {
        return UIScreen.main.bounds.minEdge
    }
    
}

extension CGRect {
    
    var minEdge: CGFloat {
        return min(width, height)
    }
}


extension EKColor {
    
    static var dimmedLightBackground: EKColor {
        return EKColor(light: UIColor(white: 100.0/255.0, alpha: 0.3),
                       dark: UIColor(white: 0, alpha: 0.5))
    }
}
