//
//  UIImage+Ext.swift
//  SapPortal
//
//  Created by LuongTiem on 5/29/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import UIKit
import Kingfisher


extension UIImage {
    
    func resizeImage300Kb() -> UIImage {
        let qualities: [CGFloat] = [1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0.09, 0.07, 0.05, 0.03]
        for quality in qualities {
            let newData = self.jpegData(compressionQuality: quality)!
            let size = NSData(data: newData).length / 1024
            if size < 300 {
                return UIImage(data: newData)!
            }
        }
        return UIImage(data: self.jpegData(compressionQuality: 0.01)!)!
    }
    
    
    func resizeImage1024x1024() -> String {
        
        let resizeImage = self.kf.resize(to: CGSize(width: 1024, height: 1024), for: ContentMode.aspectFit)
        
        let base64Data = resizeImage.jpegData(compressionQuality: 0.01)
        
        return base64Data?.base64EncodedString() ?? ""
        
//        return ""
    }
    
   
}

