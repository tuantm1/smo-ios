//
//  Double+Ext.swift
//  SapPortal
//
//  Created by LuongTiem on 6/9/20.
//  Copyright © 2020 LuongTiem. All rights reserved.
//

import Foundation
import UIKit

extension Double {
    
    var toString: String {
        
        let formatter = NumberFormatter()
//        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 3
//        formatter.locale = Locale(identifier: "vi_VN")
//
        
        guard let result = formatter.string(from: self as NSNumber) else {
            return "\(self)"
        }
        
        return "\(result)"
    }
    
    
    var convertToCurrency: String {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        numberFormatter.maximumFractionDigits = 3
        numberFormatter.locale = Locale(identifier: "vi_VN")
        
        if let result = numberFormatter.string(from: NSNumber(value: self)) {
            return result
        }
        return "\(self)"
    }
}


extension String {
    
    var trimZeroCharacter: String {
         
        guard let trimCharacter = Int(self) else {
            return self
        }
        
        return "\(trimCharacter)"
    }
    
    var toDouble: Double {
        
        guard let result = NumberFormatter().number(from: self) else {
            return 0
        }
        
        return result.doubleValue
    }
    
    func indexOf(char: Character) -> Int? {
        return firstIndex(of: char)?.utf16Offset(in: self)
    }
}
